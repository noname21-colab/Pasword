#!/bin/bash

# ============================================
# Node.js 20 & PM2 Setup Script
# For Ubuntu/Debian VPS
# ============================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m'

echo ""
echo -e "${CYAN}=========================================${NC}"
echo -e "${CYAN}  Node.js 20 & PM2 Setup${NC}"
echo -e "${CYAN}=========================================${NC}"
echo ""

# Check if running as root or with sudo
if [ "$EUID" -ne 0 ]; then
    echo -e "${YELLOW}Note: Some commands may require sudo password${NC}"
fi

# ============================================
# System Update
# ============================================

echo -e "${MAGENTA}[1/3] Updating system...${NC}"
sudo apt update && sudo apt upgrade -y

# Install curl if not exists
if ! command -v curl &> /dev/null; then
    echo -e "${YELLOW}  Installing curl...${NC}"
    sudo apt install -y curl
fi

# ============================================
# Node.js 20
# ============================================

echo -e "${MAGENTA}[2/3] Installing Node.js 20...${NC}"

if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
elif [[ $(node -v | cut -d. -f1 | tr -d 'v') -lt 20 ]]; then
    echo -e "${YELLOW}  Node.js version too old, upgrading...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt install -y nodejs
else
    echo -e "${GREEN}  Node.js already installed${NC}"
fi

echo -e "${GREEN}  Node.js $(node -v)${NC}"
echo -e "${GREEN}  npm v$(npm -v)${NC}"

# ============================================
# PM2 Installation
# ============================================

echo -e "${MAGENTA}[3/3] Installing PM2...${NC}"

if ! command -v pm2 &> /dev/null; then
    sudo npm install -g pm2
    echo -e "${GREEN}  PM2 installed successfully${NC}"
else
    echo -e "${GREEN}  PM2 already installed (pm2 $(pm2 -v))${NC}"
fi

# Enable PM2 to start on boot
echo -e "${YELLOW}  Setting up PM2 startup script...${NC}"
sudo pm2 startup systemd -u $USER --hp $HOME 2>/dev/null || true

# ============================================
# COMPLETE
# ============================================

echo ""
echo -e "${GREEN}=========================================${NC}"
echo -e "${GREEN}  Setup Complete!${NC}"
echo -e "${GREEN}=========================================${NC}"
echo ""
echo -e "${CYAN}Installed:${NC}"
echo "  • Node.js $(node -v)"
echo "  • npm v$(npm -v)"
echo "  • PM2 $(pm2 -v 2>/dev/null || echo 'installed')"
echo ""
echo -e "${CYAN}Basic PM2 Commands:${NC}"
echo "  pm2 start app.js --name my-app    # Start app"
echo "  pm2 list                          # List all apps"
echo "  pm2 logs                          # View logs"
echo "  pm2 stop my-app                   # Stop app"
echo "  pm2 restart my-app                # Restart app"
echo "  pm2 delete my-app                 # Delete app"
echo "  pm2 save                          # Save current process list"
echo ""