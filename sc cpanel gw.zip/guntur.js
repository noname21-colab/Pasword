 /*
   #--- Credits Script by @gunturnaktido
   Telegram: https:/t.me/gunturnaktido

-- [ ! ] Dilarang keras hapus pesan
    Ada kendala? hubungi kontak diatas!
*/

const TelegramBot = require('node-telegram-bot-api');
const archiver = require('archiver');
const axios = require("axios");
const chalk = require("chalk");
const cron = require('node-cron');
const crypto = require('crypto');
const { Client } = require("ssh2");
const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const moment = require('moment-timezone');
const { NodeSSH } = require("node-ssh");
const os = require("os");
const path = require('path');
const qs = require("qs");
const readline = require("readline")
const ssh = new NodeSSH();

// database file
const settings = require("./settings/config.js")
const settingFile = path.resolve("./settings/config.js")

const bot = new TelegramBot(settings.token, { polling: true });

const {
    ownerId,
    domain,
    plta,
    pltc,
    domainV2,
    pltaV2,
    pltcV2,
    domainV3,
    pltaV3,
    pltcV3,
    domainV4,
    pltaV4,
    pltcV4,
    domainV5,
    pltaV5,
    pltcV5,
    eggs,
    loc,
    dev,
    panel,
    qris,
    pp,
    ppVid,
    bq,
    ebq,
    bqe,
    apiAtlantic,
    apiPakasir,
    pakasirProject
} = settings;

const startModule = require("./@gunturnaktido/start.js")

const { startBot } = startModule(
  bot,
  settings,
  ownerId,
  dev
)

const usersFile = path.resolve("./database/users")
const userDb = path.join(__dirname, "./database/users.json")
const roleFile = path.join(__dirname, "./database/roleBackup.json")

const menuFile = path.join(__dirname, "./database/menuconfig.json")
const productFile = path.join(__dirname, "./database/products.json")

const fileDir = path.resolve("./files")

global.subdomain = require("./lib/subdomain.js")
const subdoFile = path.join(__dirname, "./lib/subdomain.js")

const levelDb = path.join(__dirname, "database", "level.json")

const depositPending = "./database/pending_deposit.json"

// statement
const userStates = new Map();
const cekDomainState = new Map();
const subdoSession = new Map();
const addSubdoSession = new Map()
const pendingQris = new Map()
const depositSessions = new Map();
const addProdukSession = new Map();
  
async function initializeBot() {
  // Tidak perlu validasi, langsung jalan
  console.log("🗿🌹 Memulai bot...");

  await startingBot();
}
require("./menu/panel")(bot);
require("./menu/cvps")(bot);
require("./menu/install")(bot);
require("./menu/encrypt")(bot);

function onlyOwner(msg) {
  return msg.from && msg.from.id === ownerId
};

function isUser(role, id) {
  try {
    const file = path.join(usersFile, `${role}.json`);
    if (!fs.existsSync(file)) return false;

    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!Array.isArray(data)) return false;

    return data.includes(String(id));
  } catch {
    return false;
  }
}

function isCeo(id)  { return isUser("ceo", id); }
function isTk(id)  { return isUser("tk", id); }
function isOwner(id)  { return isUser("owner", id); }
function isPremium(id)  { return isUser("prem", id); }
function isPartner(id)  { return isUser("partner", id); }
function isReseller(id) { return isUser("ress", id); }

function getFile(role) {
  return path.join(usersFile, `${role}.json`);
}

function checkFile(file) {
  if (!fs.existsSync(usersFile)) fs.mkdirSync(usersFile, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]");
}

if (!fs.existsSync(path.dirname(levelDb))) {
  fs.mkdirSync(path.dirname(LEVEL_DB_PATH), { recursive: true })
}
if (!fs.existsSync(levelDb)) {
  fs.writeFileSync(levelDb, JSON.stringify({}, null, 2))
}

function loadLevelDb() {
  try {
    return JSON.parse(fs.readFileSync(levelDb, "utf8"))
  } catch {
    return {}
  }
}

function saveLevelDb(db) {
  fs.writeFileSync(levelDb, JSON.stringify(db, null, 2))
}

let userLevelDb = loadLevelDb()

const levelSteps = [3, 5, 8, 12, 17, 23, 30, 40, 55, 75]

function getNeedForLevel(level) {
  if (level <= levelSteps.length) return levelSteps[level - 1]
  const last = levelSteps[levelSteps.length - 1]
  return last + (level - levelSteps.length) * 25
}

function getUserStat(userId) {
  const key = String(userId)

  if (!userLevelDb[key]) {
    userLevelDb[key] = {
      level: 0,
      progress: 0,
      totalCommands: 0,
      totalChats: 0
    }
  }

  const st = userLevelDb[key]

  if (typeof st.level !== "number") st.level = 0
  if (typeof st.progress !== "number") st.progress = 0
  if (typeof st.totalCommands !== "number") st.totalCommands = 0
  if (typeof st.totalChats !== "number") st.totalChats = 0

  userLevelDb[key] = st
  saveLevelDb(userLevelDb)

  return st
}

function addExp(userId, exp, isCommand = false) {
  const st = getUserStat(userId)

  st.progress += exp
  if (isCommand) st.totalCommands += 1
  else st.totalChats += 1

  let leveledUp = false

  while (true) {
    const need = getNeedForLevel(st.level + 1)
    if (st.progress >= need) {
      st.progress -= need
      st.level += 1
      leveledUp = true
    } else break
  }

  userLevelDb[String(userId)] = st
  saveLevelDb(userLevelDb)

  return {
    leveledUp,
    level: st.level,
    progress: st.progress.toFixed(1),
    needNext: getNeedForLevel(st.level + 1),
    totalCmd: st.totalCommands,
    totalChat: st.totalChats
  }
}

bot.on("message", async (msg) => {
  const chatId = msg.chat?.id
  const chatUsername = msg.chat?.username
  const userId = msg.from?.id
  const text = (msg.text || "").trim()
  if (!chatId || !userId || !text) return

  let gained = 0
  let isCommand = false

  if (text.startsWith("/") && !/^\/(start|help)\b/i.test(text)) {
    gained = 1
    isCommand = true
  } 

  if (gained <= 0) return

  const r = addExp(userId, gained, isCommand)

  if (r.leveledUp) {
    const name = msg.from.first_name || "User"
    return bot.sendMessage(
      chatId,
      `${bq}🎉 <b>Selamat ${name}</b>!
Kamu naik ke <b>Level ${r.level}!</b>

⏳ Tahap ke level berikutnya:
<b>${r.progress}/${r.needNext}</b>

📊 <b>Statistik ${name}:</b>
Command: <b>${r.totalCmd}</b>${ebq}`,
      {
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id
      }
    )
  }
})

function getUsers() {
  return JSON.parse(fs.readFileSync(userDb))
}

function saveUser(userId) {
  const users = getUsers()

  if (!users.includes(userId)) {
    users.push(userId)
    fs.writeFileSync(userDb, JSON.stringify(users, null, 2))
  }

  return users.length
}

  // ram vps
  const totalRam = os.totalmem() / 1024 / 1024 / 1024
  const freeRam = os.freemem() / 1024 / 1024 / 1024
  const usedRam = totalRam - freeRam

  const vpsRamStr = `${usedRam.toFixed(2)} / ${totalRam.toFixed(2)} GB`
  
  // core vps
  const cpuInfo = os.cpus()
  const cpuCores = cpuInfo.length
  const cpuModel = cpuInfo[0].model
  
  const vpsCpuStr = `${cpuCores} Cores / ${cpuModel}`
  
  // runtime vps
  const vpsUptime = os.uptime();
  const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;
    
  // speed vps
  const start = Date.now()
  const latency = Date.now() - start
  const vpsNetStr = `Latency / Ping ${latency} ms`
  
  // runtime bot
  function getRuntimeBot() {
  if (!getRuntimeBot.startTime) {
    getRuntimeBot.startTime = Date.now()
  }

  let diff = Date.now() - getRuntimeBot.startTime

  let seconds = Math.floor(diff / 1000) % 60
  let minutes = Math.floor(diff / (1000 * 60)) % 60
  let hours = Math.floor(diff / (1000 * 60 * 60)) % 24
  let days = Math.floor(diff / (1000 * 60 * 60 * 24))

  let result = []
  if (days) result.push(days + "d")
  if (hours) result.push(hours + "h")
  if (minutes) result.push(minutes + "m")
  result.push(seconds + "s")

  return result.join(" ")
}

function rupiah(n) {
  return "Rp" + Number(n).toLocaleString("id-ID")
}

function addTransaction(tx) {
  const db = readTransactions()
  
  const exists = db.transactions.some(t => t.order_id === tx.order_id)
  if (exists) return false

  db.transactions.push({
    ...tx,
    created_at: tx.created_at || Date.now(),
    updated_at: Date.now()
  })

  saveTransactions(db)
  return true
}

function saveTransactions(db) {
    fs.writeFileSync("./database/transactions.json", JSON.stringify(db, null, 2))
}

function readTransactions() {
  try {
    return JSON.parse(fs.readFileSync("./database/transactions.json", "utf8"))
  } catch {
    return { transactions: [] }
  }
}

function getTransaction(orderId) {
  const db = readTransactions()
  return db.transactions.find(t => t.order_id === orderId) || null
}

function updateTransaction(orderId, updates) {
  const db = readTransactions()
  const idx = db.transactions.findIndex(t => t.order_id === orderId)
  if (idx === -1) return null

  db.transactions[idx] = {
    ...db.transactions[idx],
    ...updates,
    updated_at: Date.now()
  }

  saveTransactions(db)
  return db.transactions[idx]
}

function getUserPendingTransactions(userId) {
  const db = readTransactions()
  return db.transactions.filter(t =>
    t.user_id === userId &&
    t.status === "PENDING"
  )
}

function readJSON(path, def) {
  try {
    return JSON.parse(fs.readFileSync(path))
  } catch {
    return def
  }
}

function writeJSON(path, data) {
  fs.writeFileSync(path, JSON.stringify(data, null, 2))
}

function readDB(path, def) {
  try {
    return JSON.parse(fs.readFileSync(path))
  } catch {
    return def
  }
}

function saveDB(path, data) {
  fs.writeFileSync(path, JSON.stringify(data, null, 2))
}

function readSaldo() {
  try {
    return JSON.parse(fs.readFileSync("./database/saldo.json", "utf8"))
  } catch {
    return {}
  }
}

function saveSaldo(db) {
  fs.writeFileSync("./database/saldo.json", JSON.stringify(db, null, 2))
}

function getSaldoUser(userId) {
  const db = readSaldo()
  return db[userId] || null
}

function realSaldoUser(userId, username) {
  const db = readSaldo()

  if (!db[userId]) {
    db[userId] = {
      username: username || null,
      saldo: 0
    }
    saveSaldo(db)
  } else if (username && !db[userId].username) {
    db[userId].username = username
    saveSaldo(db)
  }

  return db[userId]
}

function addSaldoUser(userId, username, amount) {
  const db = readSaldo()

  if (!db[userId]) {
    db[userId] = {
      username: username || null,
      saldo: 0
    }
  }

  db[userId].saldo += amount
  saveSaldo(db)

  return db[userId]
}

function applySaldo(tx) {
  if (tx.paid === true) return

  const db = readSaldo()
  const userId = tx.user_id

  if (!db[userId]) {
    db[userId] = {
      username: null,
      saldo: 0
    }
  }

  db[userId].saldo += Number(tx.amount)
  saveSaldo(db)

  tx.paid = true
  tx.paid_at = Date.now()

  updateTransaction(tx.order_id, {
    paid: true,
    paid_at: tx.paid_at,
    saldo_added: true
  })
}

function editSaldoLog(log) {
  try {
    const logFile = "./database/log/edit_saldo_log.json";
    let logs = [];
    
    if (fs.existsSync(logFile)) {
      logs = JSON.parse(fs.readFileSync(logFile, "utf8"));
    }
    
    logs.push(log);
    
    fs.writeFileSync(logFile, JSON.stringify(logs, null, 2));
  } catch (error) {
    console.error("Error saving edit saldo log:", error);
  }
}

async function atlanticPost(url, data) {
  const res = await axios.post(url, qs.stringify(data), {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    timeout: 30000,
    validateStatus: () => true
  })
  return res.data
}

async function generatePlainQrPng(qrString) {
  const res = await axios.post(
    "https://api.qrserver.com/v1/create-qr-code/",
    null,
    {
      params: { size: "600x600", data: qrString },
      responseType: "arraybuffer"
    }
  )
  return Buffer.from(res.data)
}

function addUserSaldo(userId, amount, username = "-") {
  const users = readJSON("./database/saldo.json", {});
  const key = String(userId);

  if (!users[key]) {
    users[key] = { balance: 0, username };
  }

  // pastikan number
  users[key].balance = Number(users[key].balance || 0) + Number(amount || 0);
  if (username && username !== "-") users[key].username = username;

  writeJSON("./database/saldo.json", users);
  return users[key].balance;
}

async function processAtlanticDeposit(cb, sess) {
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const userId = String(cb.from.id);

  await safeDeleteMessage(bot, chatId, messageId);

  const orderId = `ATL-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  const fee = Math.ceil(sess.amount * 1.4 / 100 + 200);
  const totalBayar = sess.amount + fee;

  const order = {
    orderId,
    type: "DEPOSIT",
    userId,
    username: sess.username || null,
    chatId: sess.chatId,
    status: "PENDING_PAYMENT",
    amount: sess.amount,
    fee,
    totalBayar,
    method: "ATLANTIC_QRIS",
    createdAt: Date.now(),
    processingLock: false,
    delivered: false,
    payment: {
      provider: "ATLANTIC",
      amount: totalBayar
    }
  };

  addTransaction({
    order_id: orderId,
    user_id: userId,
    username: sess.username || null,
    amount: sess.amount,
    biaya_admin: fee,
    total_bayar: totalBayar,
    method: "QRIS Atlantic",
    status: "PENDING",
    created_at: Date.now(),
    meta: {
      type: "deposit",
      payment_provider: "atlantic",
      session_data: JSON.stringify(sess)
    }
  });
    
  const processMsg = await bot.sendMessage(
    chatId,
    `<b>⏳ Menyiapkan pembayaran...</b>\n<i>Mohon tunggu sebentar</i>`,
    {
      parse_mode: "HTML"
    }
  );

  try {
    const res = await axios.post(
      "https://atlantich2h.com/deposit/create",
      qs.stringify({
        api_key: apiAtlantic,
        reff_id: orderId,
        nominal: totalBayar,
        type: "ewallet",
        metode: "qrisfast"
      }),
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        timeout: 30000
      }
    );

    if (!res.data?.data?.qr_string) {
      throw new Error("QR string tidak ditemukan");
    }

    const atlanticId = res.data.data.id;
    const qrString = res.data.data.qr_string;

    const qrImage = await generatePlainQrPng(qrString);

    await safeDeleteMessage(bot, chatId, processMsg.message_id);

    const caption =
`${bq}<b>🧾 Transaksi QRIS Atlantic</b>${ebq}

🆔 <b>Order ID:</b> <code>${orderId}</code>

💰 <b>Nominal:</b> ${rupiah(sess.amount)}

💸 <b>Biaya Admin:</b> ${rupiah(fee)}
💳 <b>Total Bayar:</b> ${rupiah(totalBayar)}

${bq}<b>⏳ Masa Aktif:</b> 5 Menit${ebq}

${bq}🔍 <b>Cara Pembayaran:</b>
1. Buka e-wallet / m-banking
2. Pilih Scan QRIS
3. Scan QR di atas
4. Konfirmasi pembayaran${ebq}`;

    const sent = await bot.sendPhoto(chatId, qrImage, {
      caption,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "🔄 Cek Status", callback_data: `deposit_refresh_atlantic:${orderId}` },
            { text: "❌ Cancel", callback_data: `deposit_qris_cancel:${orderId}:${userId}` }
          ],
          [
            { text: "Contact", url: `https://t.me/${settings.dev}` }
          ]
        ]
      }
    });

    updateTransaction(orderId, {
      atlantic_id: atlanticId,
      qr_message_id: sent.message_id,
      status: "PENDING",
      refresh_count: 0
    });

    depositSessions.set(userId, {
      ...sess,
      orderId,
      atlanticId,
      method: "ATLANTIC",
      qrMessageId: sent.message_id,
      lastRefresh: Date.now()
    });

    startAtlanticPolling(orderId, atlanticId, userId, chatId);

  } catch (error) {
    console.error("Atlantic deposit error:", error);
    await safeDeleteMessage(bot, chatId, processMsg.message_id);
    await bot.sendMessage(
      chatId,
      `❌ <b>Gagal membuat QRIS</b>\n\n` +
      `Error: ${error.message || "Unknown error"}\n\n` +
      `Silahkan coba lagi.`,
      { 
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: `deposit_atlantic:${userId}` }]]
        }
      }
    );
  }
}

async function checkAtlanticPaymentStatus(orderId, chatId, userId, messageId) {
  try {

    const tx = getTransaction(orderId);
    if (!tx) {
      await bot.sendMessage(
        chatId,
        `❌ Transaksi tidak ditemukan\nOrder ID: <code>${orderId}</code>`,
        { parse_mode: "HTML" }
      );
      return;
    }

    await bot.editMessageCaption(
      `🔄 <b>Memeriksa status pembayaran...</b>\n\n` +
      `Order ID: <code>${orderId}</code>\n` +
      `Mohon tunggu...`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );

    const res = await axios.post(
      "https://atlantich2h.com/deposit/status",
      qs.stringify({
        api_key: apiAtlantic,
        id: tx.atlantic_id
      }),
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        timeout: 10000
      }
    );

    const data = res.data?.data;
    const status = data?.status?.toLowerCase();
    const amountPaid = data?.nominal || data?.amount;

    console.log(`[REFRESH] Status ${orderId}: ${status}`);

    // Update refresh count
    const currentRefresh = (tx.refresh_count || 0) + 1;
    updateTransaction(orderId, {
      refresh_count: currentRefresh,
      last_refresh: Date.now()
    });

    if (status === "success" || status === "paid") {
      
      await processSuccessfulPayment(orderId, tx, chatId, messageId, userId);
      
    } else if (status === "pending") {
      
      const timeElapsed = Math.floor((Date.now() - tx.created_at) / 1000);
      const minutes = Math.floor(timeElapsed / 60);
      const seconds = timeElapsed % 60;
      
      await bot.editMessageCaption(
        `${bq}🧾 <b>Transaksi Pending</b>${ebq}\n\n` +
        `🆔 <b>Order ID:</b> <code>${orderId}</code>\n\n` +
        `💰 <b>Total Bayar:</b> ${rupiah(tx.total_bayar)}\n` +
        `⏳ <b>Waktu:</b> ${minutes}m ${seconds}s\n\n` +
        `<blockquote>🔍 <b>Cara Pembayaran:</b></blockquote>\n` +
        `1. Pastikan sudah scan QR\n` +
        `2. Bayar sesuai harga ${rupiah(tx.total_bayar)}\n` +
        `3. Tunggu 1-2 menit setelah bayar\n` +
        `4. Klik Refresh dibawah lagi\n\n`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [
                { text: "🔄 Refresh", callback_data: `deposit_refresh_atlantic:${orderId}` },
                { text: "❌ Cancel", callback_data: `deposit_qris_cancel:${orderId}:${userId}` }
              ],
              [
                { text: "Contact", url: `https://t.me/${settings.dev}` }
              ]
            ]
          }
        }
      );
      
    } else if (status === "failed" || status === "canceled" || status === "expired") {
     
      await bot.editMessageCaption(
        `❌ <b>PEMBAYARAN ${status.toUpperCase()}</b>\n` +
        `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
        `Order ID: <code>${orderId}</code>\n` +
        `Status: ${status.toUpperCase()}\n` +
        `Alasan: ${data?.message || "Tidak diketahui"}\n\n` +
        `Silakan buat deposit baru.`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [[{ text: "💳 Deposit Baru", callback_data: `deposit_new_${userId}` }]]
          }
        }
      );
      
    } else {
      // Status tidak dikenali
      await bot.editMessageCaption(
        `⚠️ <b>STATUS TIDAK DIKENALI</b>\n\n` +
        `Order ID: <code>${orderId}</code>\n` +
        `Status: ${status || "unknown"}\n\n` +
        `Silakan hubungi admin.`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );
    }

  } catch (error) {
    console.error(`[REFRESH] Error cek status ${orderId}:`, error);
    
    await bot.editMessageCaption(
      `❌ <b>Gagal Cek Status</b>\n\n` +
      `Order ID: <code>${orderId}</code>\n` +
      `Error: ${error.message || "Unknown"}\n\n` +
      `Silakan coba lagi nanti.`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "🔄 Coba Lagi", callback_data: `deposit_refresh_atlantic:${orderId}` }]]
        }
      }
    );
  }
}

async function processSuccessfulPayment(orderId, tx, chatId, messageId, userId) {
  try {
    // Update transaction status
    updateTransaction(orderId, {
      status: "PAID",
      paid_at: Date.now(),
      payment_data: JSON.stringify({ success: true, timestamp: Date.now() })
    });

    // Tambah saldo user
    const saldoDb = readSaldo();
    if (!saldoDb[userId]) {
      saldoDb[userId] = {
        username: tx.username || null,
        saldo: 0
      };
    }
    
    saldoDb[userId].saldo += Number(tx.amount);
    saveSaldo(saldoDb);
    
    // Tandai sudah diproses
    updateTransaction(orderId, {
      paid: true,
      paid_at: Date.now(),
      saldo_added: true
    });

    // Update pesan QR dengan status berhasil
    await bot.editMessageCaption(
      `✅ <b>PEMBAYARAN BERHASIL!</b>\n` +
      `━━━━━━━━━━━━━━━━━━━━━━\n\n` +
      `🆔 <b>Order ID:</b> <code>${orderId}</code>\n` +
      `💰 <b>Nominal:</b> ${rupiah(tx.amount)}\n` +
      `💸 <b>Biaya Admin:</b> ${rupiah(tx.biaya_admin || 0)}\n` +
      `💳 <b>Total Bayar:</b> ${rupiah(tx.total_bayar || 0)}\n` +
      `📊 <b>Saldo Ditambahkan:</b> ${rupiah(tx.amount)}\n\n` +
      `🎉 <b>Saldo Anda telah otomatis ditambahkan!</b>\n` +
      `Gunakan <code>/ceksaldo</code> untuk verifikasi.`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "💰 Cek Saldo", callback_data: "check_balance" },
              { text: "💳 Deposit Lagi", callback_data: `deposit_new_${userId}` }
            ],
            [
              { text: "📞 Lapor Masalah", url: `https://t.me/${settings.dev}` }
            ]
          ]
        }
      }
    );

    // Hapus session
    depositSessions.delete(userId);
    
    // Kirim notifikasi ke owner
    await bot.sendMessage(
      ownerId,
      `💰 <b>DEPOSIT BERHASIL via REFRESH</b>\n\n` +
      `👤 User: @${tx.username || "unknown"}\n` +
      `🆔 ID: <code>${userId}</code>\n` +
      `📦 Order: <code>${orderId}</code>\n` +
      `💰 Nominal: ${rupiah(tx.amount)}\n` +
      `⏰ Waktu: ${new Date().toLocaleString("id-ID")}\n\n` +
      `✅ Saldo otomatis ditambahkan via manual refresh.`,
      { parse_mode: "HTML" }
    );

  } catch (error) {
    console.error(`[SUCCESS] Error process payment ${orderId}:`, error);
    await bot.sendMessage(
      chatId,
      `⚠️ <b>PEMBAYARAN DITERIMA TAPI ERROR</b>\n\n` +
      `Order ID: <code>${orderId}</code>\n` +
      `Status: Paid but processing error\n\n` +
      `Silakan hubungi admin untuk verifikasi manual.`,
      { parse_mode: "HTML" }
    );
  }
}

async function processPakasirDeposit(cb, sess) {
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const userId = String(cb.from.id);

  await safeDeleteMessage(bot, chatId, messageId);

  const orderId = `PAK-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  const fee = 0;
  const totalBayar = sess.amount;

  // Simpan transaction
  addTransaction({
    order_id: orderId,
    user_id: userId,
    username: sess.username || null,
    amount: sess.amount,
    biaya_admin: fee,
    total_bayar: totalBayar,
    method: "QRIS Pakasir",
    status: "PENDING",
    created_at: Date.now(),
    meta: {
      type: "deposit",
      payment_provider: "pakasir"
    }
  });

  await bot.sendMessage(
    chatId,
    `<b>⏳ Menyiapkan pembayaran...</b>\n<i>Mohon tunggu sebentar</i>`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "❌ Cancel", callback_data: `deposit_qris_cancel:${orderId}:${userId}` }]]
      }
    }
  );

  try {
    const res = await axios.get("https://app.pakasir.com/api/createqris", {
      params: {
        project: pakasirProject,
        amount: sess.amount,
        order_id: orderId,
        api_key: apiPakasir
      },
      timeout: 30000
    });

    const tx = res.data?.transaction || res.data?.data || res.data;
    const qrisUrl = tx?.qris_image || tx?.qris_url || tx?.qr_url || tx?.qr_image || tx?.payment_url || tx?.url;

    if (!qrisUrl) {
      throw new Error("QR URL tidak ditemukan");
    }

    // Hapus pesan proses
    await bot.deleteMessage(chatId, (await bot.getUpdates()).pop()?.message?.message_id).catch(() => {});

    const caption =
`💳 <b>QRIS PAYMENT - PAKASIR</b>\n` +
`━━━━━━━━━━━━━━━━━━━━━━\n\n` +
`🆔 <b>Order ID:</b> <code>${orderId}</code>\n` +
`💰 <b>Total Bayar:</b> ${rupiah(totalBayar)}\n\n` +
`<blockquote>Scan QR di atas untuk membayar.\nMasa aktif: 5 menit</blockquote>\n\n` +
`✅ Pembayaran akan diverifikasi otomatis.`;

    const sent = await bot.sendPhoto(chatId, qrisUrl, {
      caption,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "❌ Cancel", callback_data: `deposit_qris_cancel:${orderId}:${userId}` }]]
      }
    });

    // Simpan session
    depositSessions.set(userId, {
      ...sess,
      orderId,
      method: "PAKASIR",
      qrMessageId: sent.message_id
    });

    // Mulai polling Pakasir
    startPakasirPolling(orderId, userId, chatId);

  } catch (error) {
    console.error("Pakasir deposit error:", error);
    await bot.sendMessage(
      chatId,
      `❌ <b>Gagal membuat QRIS</b>\n\n` +
      `Error: ${error.message || "Unknown error"}`,
      { parse_mode: "HTML" }
    );
  }
}

function startAtlanticPolling(orderId, atlanticId, userId, chatId) {
  const interval = setInterval(async () => {
    try {
      const res = await axios.post(
        "https://atlantich2h.com/deposit/status",
        qs.stringify({
          api_key: apiAtlantic,
          id: atlanticId
        }),
        {
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          timeout: 10000
        }
      );

      const status = res.data?.data?.status?.toLowerCase();
      
      if (status === "success" || status === "paid") {
        clearInterval(interval);
        
        // Update transaction status
        updateTransaction(orderId, {
          status: "PAID",
          paid_at: Date.now()
        });

        // Tambah saldo user
        const tx = getTransaction(orderId);
        if (tx) {
          applySaldo(tx);
        }

        // Kirim notifikasi
        await bot.sendMessage(
          chatId,
          `✅ <b>PEMBAYARAN BERHASIL!</b>\n\n` +
          `🆔 Order ID: <code>${orderId}</code>\n` +
          `💰 Saldo ditambahkan: ${rupiah(tx?.amount || 0)}\n\n` +
          `Terima kasih telah melakukan deposit!`,
          { parse_mode: "HTML" }
        );

        // Hapus session
        depositSessions.delete(userId);

        // Hapus QR message jika masih ada
        const sess = depositSessions.get(userId);
        if (sess?.qrMessageId) {
          await bot.deleteMessage(chatId, sess.qrMessageId).catch(() => {});
        }
      }
    } catch (error) {
      console.error("Polling error:", error);
    }
  }, 5000); // Poll setiap 5 detik

  // Auto stop setelah 10 menit
  setTimeout(() => {
    clearInterval(interval);
  }, 10 * 60 * 1000);
}

function startPakasirPolling(orderId, userId, chatId) {
  const interval = setInterval(async () => {
    try {
      const res = await axios.post(
        "https://app.pakasir.com/api/transactionstatus",
        {
          project: pakasirProject,
          order_id: orderId,
          api_key: apiPakasir
        },
        {
          headers: { "Content-Type": "application/json" },
          timeout: 10000
        }
      );

      const status = res.data?.status?.toUpperCase();
      
      if (status === "PAID" || status === "SUCCESS") {
        clearInterval(interval);
        
        // Update transaction
        updateTransaction(orderId, {
          status: "PAID",
          paid_at: Date.now()
        });

        // Tambah saldo
        const tx = getTransaction(orderId);
        if (tx) {
          applySaldo(tx);
        }

        await bot.sendMessage(
          chatId,
          `✅ <b>PEMBAYARAN BERHASIL!</b>\n\n` +
          `🆔 Order ID: <code>${orderId}</code>\n` +
          `💰 Saldo ditambahkan: ${rupiah(tx?.amount || 0)}\n\n` +
          `Terima kasih telah melakukan deposit!`,
          { parse_mode: "HTML" }
        );

        depositSessions.delete(userId);
        
        const sess = depositSessions.get(userId);
        if (sess?.qrMessageId) {
          await bot.deleteMessage(chatId, sess.qrMessageId).catch(() => {});
        }
      }
    } catch (error) {
      console.error("Pakasir polling error:", error);
    }
  }, 5000);

  setTimeout(() => {
    clearInterval(interval);
  }, 10 * 60 * 1000);
}

bot.onText(/^\/start(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || null;
  const name = `${msg.from.first_name || ""} ${msg.from.last_name || ""}`.trim();
  const totalUser = saveUser(userId);
  
  const menuType = getMenuType();
  const media = menuType === "photo" ? settings.pp : settings.ppVid;
  
  const caption = `${bq}◜👋🏻◞ <b>Olaa User, @${username || "User"}</b>${ebq}
<b>Naeri</b>의 조수야 너를 도와줄 거야!

${bq}⤥ Username: @${username || "-"}
⤥ Version: 6.0.0
⤥ User ID: <code>${userId}</code>
${ebq}
${bq}Total Users ⤻ ${totalUser}
⤥ Runtime Bot: <b>${getRuntimeBot()}</b>
Type Module ⤻ JavaScript
${ebq}

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}⤥ /cekid
⤥ /idgroup
⤥ /ping ${ebq}
${bq}◜📡◞ <b>${vpsUptimeStr}</b>${ebq}
`;

  const replyMarkup = {
    inline_keyboard: [
      [
        { text: 'All Menu', callback_data: 'all_menu' },
        { text: 'Auto Order', callback_data: 'order_menu' }
      ],
      [
        { text: 'Buy Script', url: 'https://t.me/chgunturx' }
      ]
    ]
  };

  try {
    // Kirim menu
    if (menuType === "photo") {
      await bot.sendPhoto(chatId, media, {
        caption: caption,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        reply_markup: replyMarkup
      });
    } else {
      await bot.sendVideo(chatId, media, {
        caption: caption,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        reply_markup: replyMarkup
      });
    }

    // Kirim audio dari file MP3 lokal
    const fs = require('fs');
    const audioPath = './assets/welcome.mp3'; // Sesuaikan path file MP3 Anda
    
    // Cek apakah file ada
    if (fs.existsSync(audioPath)) {
      await bot.sendAudio(chatId, audioPath, {
        caption: `🎵 <b>Hallo ${username || "User"}</b>`,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        title: 'Hallo', // Judul lagu (opsional)
        performer: 'Hoshino Assistant' // Nama artis (opsional)
      });
    } else {
      console.warn(`Audio file not found: ${audioPath}`);
    }

  } catch (error) {
    console.error("Error sending menu:", error);
    
    if (menuType === "video") {
      await bot.sendPhoto(chatId, settings.pp, {
        caption: caption + `\n\n⚠️ <i>Video tidak dapat ditampilkan, fallback ke foto.</i>`,
        parse_mode: 'HTML',
        reply_to_message_id: msg.message_id,
        reply_markup: replyMarkup
      });
    }
  }
});

bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const totalUser = saveUser(q.from.id);

  if (
  data === "all_menu" ||
  data === "order_menu" ||
  data === "product_menu" ||
  data === "vipies_menu" ||
  data === "panel_menu" ||
  data === "vps_menu" ||
  data === "owner_menu" ||
  data === "encrypt_menu" ||
  data === "enc_menu" ||
  data === "protect_menu" ||
  data === "protect1_menu" ||
  data === "protect2_menu" ||
  data === "public_menu" ||
  data === "private_menu" ||
  data === "back_menu"
) {
    try {
      await bot.answerCallbackQuery(q.id, { text: "📋 Menampilkan Menu...", show_alert: false })
    } catch (_) {}

    const editTarget = q.message?.chat?.id && q.message?.message_id
      ? { chat_id: q.message.chat.id, message_id: q.message.message_id }
      : { inline_message_id: q.inline_message_id }

    if (!editTarget.chat_id && !editTarget.inline_message_id) return

    const chatId = q.message?.chat?.id;
    const messageId = q.message?.message_id;
    
      if (q.data === 'all_menu') {
      const text =
`${bq}◜👋🏻◞ <b>Olaa User, @${q.from.username}</b>${ebq}
<b>Naeri</b>의 조수야 너를 도와줄 거야!

${bq}⤥ Username: @${q.from.username}
⤥ Version: 6.0.0
⤥ User ID: <code>${q.from.id}</code>
${ebq}

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect${ebq}
${bq}<b>Total Users</b> ⤻ ${totalUser}${ebq}`

      const markup = {
        inline_keyboard: [
          [
            { text: '1', callback_data: 'panel_menu' },
            { text: '2', callback_data: 'vps_menu' },
            { text: '3', callback_data: 'owner_menu' },
            { text: '4', callback_data: 'encrypt_menu' },
            { text: '5', callback_data: 'protect_menu' }
          ],
          [{ text: 'Menu Utama', callback_data: 'back_menu' }]
        ]
      }

      try {
        await bot.editMessageCaption(text, { ...editTarget, parse_mode: 'HTML', reply_markup: markup })
      } catch (e) {
        const msg = String(e?.message || e)
        if (
          msg.includes("message to edit not found") ||
          msg.includes("message can't be edited") ||
          msg.includes("MESSAGE_ID_INVALID") ||
          msg.includes("message identifier is not specified")
        ) {
          if (q.message?.chat?.id) {
            await bot.sendMessage(q.message.chat.id, text, { parse_mode: 'HTML', reply_markup: markup })
          }
          return
        }
        if (msg.includes("message is not modified")) return
        throw e
      }
    }

      if (q.data === "order_menu") {
      const text =
`${bq}— ◜📑◞ <b>Status Order</b>${ebq}
⤥ /riwayatdeposit
⤥ /listdeposit
⤥ /totaldeposit
⤥ /cekdeposit

${bq}— ◜💳◞ <b>Topup Saldo</b>${ebq}
⤥ /deposit

${bq}— ◜👤◞ <b>Admin Access</b>${ebq}
⤥ /addsaldo
⤥ /editsaldo
⤥ /ceksaldo
⤥ /addproduk
⤥ /delproduk`

      const markup = {
        inline_keyboard: [
          [{ text: "📂 Buy Script", callback_data: "product_menu" }],
          [
            { text: "Kembali", callback_data: "back_menu" }
          ]
        ]
      }

      try {
        await bot.editMessageCaption(text, { ...editTarget, parse_mode: "HTML", reply_markup: markup })
      } catch (e) {
        const msg = String(e?.message || e)
        if (
          msg.includes("message to edit not found") ||
          msg.includes("message can't be edited") ||
          msg.includes("MESSAGE_ID_INVALID") ||
          msg.includes("message identifier is not specified")
        ) {
          if (q.message?.chat?.id) {
            await bot.sendMessage(q.message.chat.id, text, { parse_mode: "HTML", reply_markup: markup })
          }
          return
        }
        if (msg.includes("message is not modified")) return
        throw e
      }
    }

      if (q.data === "product_menu") {
      const userId = q.from.id
      const username = q.from.username || "-"

      const products = readJSON("./database/products.json", { products: [] }).products

      const saldoDb = readJSON("./database/saldo.json", {})
      const saldoUser = saldoDb[userId]
      const saldo = saldoUser ? saldoUser.saldo : 0

      const trxDb = readJSON("./database/transactions.json", { transactions: [] })
      const totalTrx = trxDb.transactions.filter(t => t.user_id === userId).length

      const inline_keyboard = [
        ...products.map(p => [
          { text: `${p.name} - ${rupiah(p.price)}`, callback_data: `order_${p.id}` }
        ]),
        [{ text: "⬅ Kembali", callback_data: "order_menu" }]
      ]

      const text =
`— ◜📂◞ <b>Script Selling</b>
${bq}⤥ Semua script disini memiliki garansi. Jika terjadi error pada script, segera hubungi developer @gunturnaktido.${ebq}

— ◜👤◞  <b>User Information</b>
${bq}⤥ <b>Username:</b> @${username}
⤥ <b>Saldo:</b> ${rupiah(saldo)}
⤥ <b>Total Transaksi:</b> ${totalTrx}${ebq}

${bq}<b>Choose the Script:</b>${ebq}`

      const markup = { inline_keyboard }

      try {
        await bot.editMessageCaption(text, { ...editTarget, parse_mode: "HTML", reply_markup: markup })
      } catch (e) {
        const msg = String(e?.message || e)
        if (
          msg.includes("message to edit not found") ||
          msg.includes("message can't be edited") ||
          msg.includes("MESSAGE_ID_INVALID") ||
          msg.includes("message identifier is not specified")
        ) {
          if (q.message?.chat?.id) {
            await bot.sendMessage(q.message.chat.id, text, { parse_mode: "HTML", reply_markup: markup })
          }
          return
        }
        if (msg.includes("message is not modified")) return
        throw e
      }
    }
      
      /*if (q.data === "vps_menu") {
    const chatId = q.message.chat.id
    const userId = q.from.id
    const messageId = q.message.message_id

    const username = q.from.username || "-"
    const saldoDb = readJSON("./database/saldo.json", {})
    const saldoUser = saldoDb[userId]
    const saldo = saldoUser ? saldoUser.saldo : 0

    const trxDb = readJSON("./database/transactions.json", { transactions: [] })
    const totalTrx = trxDb.transactions.filter(t => t.user_id === userId).length
    
    const text =
`— ◜📡◞ <b>Hosting Selling</b>
${bq}⤥ Semua VPS disini memiliki garansi. Jika terjadi masalah pada VPS, segera hubungi developer @gunturnaktido.${ebq}

— ◜👤◞  <b>User Information</b>
${bq}⤥ <b>Username:</b> @${username}
⤥ <b>Saldo:</b> ${rupiah(saldo)}
⤥ <b>Total Transaksi:</b> ${totalTrx}${ebq}

${bq}1️⃣ <b>VPS Lower</b>${ebq}
⤥ Garansi: 7 Hari
⤥ Replace: 1x
⤥ Harga Mulai: <b>Rp8.000</b>

${bq}2️⃣ <b>VPS Medium</b>${ebq}
⤥ Garansi: 15 Hari
⤥ Replace: 2x
⤥ Harga Mulai: <b>Rp20.000</b>

${bq}3️⃣ <b>VPS High</b>${ebq}
⤥ Garansi: 30 Hari
⤥ Replace: 3x
⤥ Harga Mulai: <b>Rp25.000</b>

${bq}<b>Choose the Category:</b>${ebq}`

    const markup = {
      inline_keyboard: [
        [{ text: "1️⃣", callback_data: "vps_pkg_low" },
        { text: "2️⃣", callback_data: "vps_pkg_medium" },
        { text: "3️⃣", callback_data: "vps_pkg_high" }],
        [{ text: "Kembali", callback_data: "order_menu" }]
      ]
    }

    try {
      await bot.editMessageCaption(text, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: markup
      })
    } catch (e) {
      const msg = String(e?.message || e)
      if (msg.includes("message is not modified")) return
      if (msg.includes("message to edit not found") || msg.includes("message can't be edited")) {
        await bot.sendMessage(chatId, text, { parse_mode: "HTML", reply_markup: markup })
        return
      }
      throw e
    }
  }*/

      if (q.data === 'panel_menu') {
        await bot.editMessageCaption(
`${bq}— ◜📡◞ <b>Hosting Menu </b>${ebq}
⤥ /server
⤥ /serverp

${bq}<b>Choose the Server:</b>${ebq}

╭──✧ ɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ ✧
│ ⤥ /install
│ ⤥ /installv2
╰─────────⧽

╭──✧ ᴜɴɪɴꜱᴛᴀʟʟ ᴍᴇɴᴜ ✧
│ ⤥ /uninstall
╰─────────⧽

╭──✧ ꜱᴜʙᴅᴏᴍᴀɪɴ ✧
│ ⤥ /addsubdo
│ ⤥ /listsubdo
│ ⤥ /subdo
│ ⤥ /cleardns
│ ⤥ /cekdomain
╰─────────⧽

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel •
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [        
              [
                { text: 'Public', callback_data: 'public_menu' },
                { text: 'Private', callback_data: 'private_menu' }
              ],
              [
                { text: '2', callback_data: 'vps_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '4', callback_data: 'encrypt_menu' },
                { text: '5', callback_data: 'protect_menu' } 
              ],
              [
                { text: '<<', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'public_menu') {
        await bot.editMessageCaption(
`${bq}╭──✧ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ✧
│ ⤥ Server : 1.0.0
│ ⤥ Type : Public
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /addpublic
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ ✧
│ ⤥ /listsrv
│ ⤥ /listsrvoff
│ ⤥ /listusr
│ ⤥ /listadmin
│ ⤥ /deladm
│ ⤥ /delusroff
│ ⤥ /delsrv
│ ⤥ /delsrvoff
│ ⤥ /totalserver
│ ⤥ /cadp
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /1gb-/10gb
│ ⤥ /unli
╰────────────⧽
${ebq}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [        
              [
                { text: '<<', callback_data: 'panel_menu' },
                { text: 'Private', callback_data: 'private_menu' }
              ],
              [
                { text: 'Menu Utama', callback_data: 'back_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'private_menu') {
  const userId = String(q.from.id)
  const privateFile = getFile("private")
  let privData = []
  try {
    checkFile(privateFile)
    const raw = JSON.parse(fs.readFileSync(privateFile, "utf8"))
    privData = Array.isArray(raw) ? raw.map(String) : []
  } catch {
    privData = []
  }

  if (!privData.includes(userId)) {
    return bot.answerCallbackQuery(q.id, { text: "❌ Khusus User Private", show_alert: true })
  }

  await bot.editMessageCaption(
`${bq}╭──✧ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ✧
│ ⤥ Server : 1.0.0
│ ⤥ Type : Private
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /addprivate
│ ⤥ /delprivate
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ ✧
│ ⤥ /srvlist
│ ⤥ /srvofflist
│ ⤥ /adminlist
│ ⤥ /admdel
│ ⤥ /usroffdel
│ ⤥ /srvdel
│ ⤥ /srvoffdel
│ ⤥ /totalsrv
│ ⤥ /cadmin
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /1gbp-/10gbp
│ ⤥ /cunli
╰────────────⧽
${ebq}`,
    {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Public", callback_data: "public_menu" },
            { text: "<<", callback_data: "panel_menu" }
          ],
          [
            { text: "Menu Utama", callback_data: "back_menu" }
          ]
        ]
      }
    }
  )
}
        
      if (q.data === 'vps_menu') {
        await bot.editMessageCaption(
`${bq}— ◜🛰️◞ <b>Control VPS </b>${ebq}
⤥ /rebuild
⤥ /createvps
⤥ /statusdo
⤥ /listvps
⤥ /delvps

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS •
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '4', callback_data: 'encrypt_menu' },
                { text: '5', callback_data: 'protect_menu' } 
              ],
              [
                { text: '<<', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'owner_menu') {
        await bot.editMessageCaption(
`${bq}— ◜👤◞ <b>Owner Access </b>${ebq}
⤥ /broadcast
⤥ /backup
⤥ /restart
⤥ /setting
⤥ /setmenu

${bq}— ◜📑◞ <b>Database Control </b>${ebq}
⤥ /listdb
⤥ /deldb
⤥ /clear
⤥ /restore

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner •
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '2', callback_data: 'vps_menu' },
                { text: '4', callback_data: 'encrypt_menu' },
                { text: '5', callback_data: 'protect_menu' } 
              ],
              [
                { text: '<<', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'encrypt_menu') {
        await bot.editMessageCaption(
`${bq}— ◜🔐◞ <b>Encrypt Menu </b>${ebq}
╭──✧ ᴅᴇᴏʙꜰᴜꜱᴄᴀᴛᴇ ᴍᴇɴᴜ ✧
│ ⤥ /deobfuscate
╰────────────⧽

╭──✧ ᴇɴᴄʀʏᴘᴛᴇᴅ ʙᴀꜱɪᴄ ✧
│ ⤥ /enc low/medium/high
│ ⤥ /enceval low/medium/high
│ ⤥ /enclocked 1-365
│ ⤥ /encx
│ ⤥ /encstrong
│ ⤥ /encbig
╰────────────⧽

╭──✧ ᴇɴᴄʀʏᴘᴛᴇᴅ ᴘʀᴇᴍɪᴜᴍ ✧
│ ⤥ /encultra
│ ⤥ /encmax
│ ⤥ /encquantum
│ ⤥ /encnova
│ ⤥ /encnebula
│ ⤥ /encsiu
│ ⤥ /encchina
│ ⤥ /encarab
│ ⤥ /encjapan
│ ⤥ /encjapxab
│ ⤥ /encnew
│ ⤥ /encinvis
│ ⤥ /invishard
│ ⤥ /encstealth
│ ⤥ /customenc
╰────────────⧽

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt •
5 ⤥ Menu Protect${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '2', callback_data: 'vps_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '5', callback_data: 'protect_menu' } 
              ],
              [
                { text: '<<', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'protect_menu') {
        await bot.editMessageCaption(
`${bq}— ◜🔒◞ <b>Menu Protect</b>${ebq}
⤥ /loginvps
⤥ /logoutvps

${bq}<b>Choose Type</b>${ebq}
<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect •${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [        
              [
                { text: 'V1 (1-7)', callback_data: 'protect1_menu' },
                { text: 'V2 (8-14)', callback_data: 'protect2_menu' }
              ],
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '2', callback_data: 'vps_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '4', callback_data: 'encrypt_menu' } 
              ],
              [
                { text: '<<', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'protect1_menu') {
        await bot.editMessageCaption(
`${bq}— ◜🛡️◞ <b>Menu Protect</b>${ebq}
⤥ /installprotect1
⤥ /installprotect2
⤥ /installprotect3
⤥ /installprotect4
⤥ /installprotect5
⤥ /installprotect6
⤥ /installprotect7

${bq}<b>Choose with Option</b>${ebq}
<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect •${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                { text: '<<', callback_data: 'protect_menu' },
                { text: 'V2 (8-14)', callback_data: 'protect2_menu' }
              ],
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '2', callback_data: 'vps_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '4', callback_data: 'encrypt_menu' } 
              ],
              [
                { text: 'Menu Utama', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'protect2_menu') {
        await bot.editMessageCaption(
`${bq}— ◜🛡️◞ <b>Menu Protect V2 </b>${ebq}
⤥ /installprotect8
⤥ /installprotect9
⤥ /installprotect10
⤥ /installprotect11
⤥ /installprotect12
⤥ /installprotect13
⤥ /installprotect14

${bq}<b>Choose with Option</b>${ebq}
<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}1 ⤥ Menu Panel
2 ⤥ Menu VPS
3 ⤥ Menu Owner 
4 ⤥ Menu Encrypt
5 ⤥ Menu Protect •${ebq}
${bq}Total Users ⤻ ${totalUser}${ebq}
`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: 'HTML',
          reply_to_message_id: q.message_id,
          reply_markup: {
            inline_keyboard: [
              [
                { text: 'V1 (1-7)', callback_data: 'protect1_menu' }
              ],
              [
                { text: '1', callback_data: 'panel_menu' },
                { text: '2', callback_data: 'vps_menu' },
                { text: '3', callback_data: 'owner_menu' },
                { text: '4', callback_data: 'encrypt_menu' } 
              ],
              [
                { text: 'Menu Utama', callback_data: 'all_menu' }
              ]
            ]
          }
        })
      }
        
      if (q.data === 'back_menu') {
  const totalUser = saveUser(q.from.id);
  const chatId = q.message.chat.id;
  const messageId = q.message.message_id;
  
  const caption = `${bq}◜👋🏻◞  Olaa User, @${q.from.username}${ebq}
<b>Naeri</b>의 조수야 너를 도와줄 거야!

${bq}⤥ Username: @${q.from.username}
⤥ Version: 6.0.0
⤥ User ID: <code>${q.from.id}</code>
${ebq}
${bq}Total Users ⤻ ${totalUser}
⤥ Runtime Bot: <b>${getRuntimeBot()}</b>
Type Module ⤻ JavaScript
${ebq}

<code>◜📋◞ 메뉴를 선택하세요:</code>
${bqe}⤥ /cekid
⤥ /idgroup
⤥ /ping${ebq}
${bq}◜📡◞ <b>${vpsUptimeStr}</b>${ebq}
`;

  const markup = {
    inline_keyboard: [
      [
        { text: 'All Menu', callback_data: 'all_menu' },
        { text: 'Auto Order', callback_data: 'order_menu' }
      ],
      [
        { text: 'Buy Script', url: 'https://t.me/chgunturx' }
      ]
    ]
  };

  try {
    await bot.editMessageCaption(caption, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: 'HTML',
      reply_markup: markup
    });
  } catch (error) {
    const newMessage = await bot.sendMessage(chatId, caption, {
      parse_mode: 'HTML',
      reply_markup: markup
    });
   
    try {
      await bot.deleteMessage(chatId, messageId);
    } catch (e) {}
  }
}
  }
})

function loadMenuConfig() {
  try {
    const data = readJSON(menuFile, { menuType: "photo" });
    return data;
  } catch (e) {
    return { menuType: "photo" };
  }
}

function saveMenuConfig(config) {
  writeJSON(menuFile, config);
}

function getMenuType() {
  const config = loadMenuConfig();
  return config.menuType || "photo";
}

function setMenuType(type) {
  const validTypes = ["photo", "video"];
  if (!validTypes.includes(type)) {
    return false;
  }
  
  const config = loadMenuConfig();
  config.menuType = type;
  saveMenuConfig(config);
  return true;
}

bot.onText(/^\/setmenu(?:\s+(\w+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const type = match[1]?.toLowerCase();

  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      chatId,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    );
  }

  if (!type) {
    return bot.sendMessage(
      chatId,
      `${bq}<b>ℹ Contoh Penggunaan</b>${ebq}\n` +
      `<code>/setmenu pp</code> - Menu pake foto\n` +
      `<code>/setmenu ppvid</code> - Menu pake video\n\n` +
      `${bq}Type Menu: <b>${getMenuType() === "photo" ? "Foto" : "Video"}</b>${ebq}`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  if (type === "pp") {
    const success = setMenuType("photo");
    if (success) {
      return bot.sendMessage(
        chatId,
        `✅ Menu berhasil diubah: <b>Foto</b>\n`,
        { parse_mode: "HTML", reply_to_message_id: msg.message_id }
      );
    }
  } else if (type === "ppvid") {
    const success = setMenuType("video");
    if (success) {
      return bot.sendMessage(
        chatId,
        `✅ Menu berhasil diubah: <b>Video</b>\n`,
        { parse_mode: "HTML", reply_to_message_id: msg.message_id }
      );
    }
  } else {
    return bot.sendMessage(
      chatId,
      `❌ Pilihan tidak valid!\n` +
      `Gunakan: <code>/setmenu pp</code> atau <code>/setmenu ppvid</code>`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  return bot.sendMessage(
    chatId,
    `❌ Gagal mengubah pengaturan menu.`,
    { reply_to_message_id: msg.message_id }
  );
});

bot.onText(/^\/progress$/i, async (msg) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  const st = getUserStat(userId)

  const nextNeed = getNeedForLevel(st.level + 1)
  const prog = Number(st.progress || 0)
  const pct = nextNeed > 0 ? Math.min(100, (prog / nextNeed) * 100) : 0

  return bot.sendMessage(
    chatId,
    `${bq}📈 <b>Statistik Level</b>
${msg.from.first_name || "Unknown"}

⭐ Level Sekarang: <b>${st.level}</b>

⏳ <b>Tahap ke level:</b>
<b>${prog.toFixed(1)}/${nextNeed}</b> (${pct.toFixed(1)}%)

📊 <b>Statistik User:</b>
Command: <b>${Number(st.totalCommands || 0)}</b>${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id
    }
  )
})


bot.onText(/^\/ceksaldo$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const username = msg.from.username || null;

  realSaldoUser(userId, username);

  const pendingTxs = getUserPendingTransactions(userId);
  
  if (pendingTxs.length > 0) {
    await bot.sendMessage(
      chatId,
      `⏳ <i>Memeriksa transaksi...</i>\n`,
      { 
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id 
      }
    );

    let updatedCount = 0;
    
    for (const tx of pendingTxs) {
      try {
        if (tx.method === "QRIS Atlantic" && tx.atlantic_id) {
          const res = await axios.post(
            "https://atlantich2h.com/deposit/status",
            qs.stringify({
              api_key: apiAtlantic,
              id: tx.atlantic_id
            }),
            {
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              timeout: 10000
            }
          );

          const data = res.data?.data;
          const status = data?.status?.toLowerCase();

          if (status === "success" || status === "paid") {
            updateTransaction(tx.order_id, {
              status: "PAID",
              paid_at: Date.now(),
              payment_data: JSON.stringify(data)
            });

            const saldoDb = readSaldo();
            if (!saldoDb[userId]) {
              saldoDb[userId] = {
                username: tx.username || null,
                saldo: 0
              };
            }
            
            saldoDb[userId].saldo += Number(tx.amount);
            saveSaldo(saldoDb);
            
            updateTransaction(tx.order_id, {
              paid: true,
              paid_at: Date.now(),
              saldo_added: true
            });
            
            updatedCount++;
          }
        } else if (tx.method === "QRIS Pakasir") {
          const res = await axios.post(
            "https://app.pakasir.com/api/transactionstatus",
            {
              project: pakasirProject,
              order_id: tx.order_id,
              api_key: apiPakasir
            },
            {
              headers: { "Content-Type": "application/json" },
              timeout: 10000
            }
          );

          const status = res.data?.status?.toUpperCase();

          if (status === "PAID" || status === "SUCCESS") {
            updateTransaction(tx.order_id, {
              status: "PAID",
              paid_at: Date.now()
            });

            const saldoDb = readSaldo();
            if (!saldoDb[userId]) {
              saldoDb[userId] = {
                username: tx.username || null,
                saldo: 0
              };
            }
            
            saldoDb[userId].saldo += Number(tx.amount);
            saveSaldo(saldoDb);
            
            updateTransaction(tx.order_id, {
              paid: true,
              paid_at: Date.now(),
              saldo_added: true
            });
            
            updatedCount++;
          }
        }
      } catch (error) {
        console.error(`[CEKSALDO] Error cek pending ${tx.order_id}:`, error.message);
      }
    }

    if (updatedCount > 0) {
      await bot.sendMessage(
        chatId,
        `✅ <b>${updatedCount} transaksi berhasil diproses!</b>\n` +
        `Saldo telah otomatis ditambahkan.`,
        { parse_mode: "HTML" }
      );
    }
  }

  const saldoData = realSaldoUser(userId, username);
  const saldoAmount = saldoData.saldo || 0;

  const allPending = getUserPendingTransactions(userId);
  const pendingCount = allPending.length;
  const pendingTotal = allPending.reduce((sum, tx) => sum + (tx.amount || 0), 0);

  const message = 
    `💰 <b>Saldo Aktif Anda</b>

${rupiah(saldoAmount)}

<i>Silahkan deposit untuk order.</i>`;

  return bot.sendMessage(
    chatId,
    message,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💳 Top Up", callback_data: "topup_saldo" }
          ]
        ]
      }
    }
  );
});

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const data = cb.data;
  const userId = String(cb.from.id);

  if (data === "refresh_saldo") {
    await bot.answerCallbackQuery(cb.id, {
      text: "🔄 Memperbarui saldo...",
      show_alert: false
    });

    const username = cb.from.username || null;
    realSaldoUser(userId, username);

    const pendingTxs = getUserPendingTransactions(userId);
    
    let updatedCount = 0;
    
    for (const tx of pendingTxs) {
      try {
        if (tx.method === "QRIS Atlantic" && tx.atlantic_id) {
          const res = await axios.post(
            "https://atlantich2h.com/deposit/status",
            qs.stringify({
              api_key: apiAtlantic,
              id: tx.atlantic_id
            }),
            {
              headers: { "Content-Type": "application/x-www-form-urlencoded" },
              timeout: 10000
            }
          );

          const data = res.data?.data;
          const status = data?.status?.toLowerCase();

          if (status === "success" || status === "paid") {
            updateTransaction(tx.order_id, {
              status: "PAID",
              paid_at: Date.now(),
              payment_data: JSON.stringify(data)
            });

            const saldoDb = readSaldo();
            if (!saldoDb[userId]) {
              saldoDb[userId] = {
                username: tx.username || null,
                saldo: 0
              };
            }
            
            saldoDb[userId].saldo += Number(tx.amount);
            saveSaldo(saldoDb);
            
            updateTransaction(tx.order_id, {
              paid: true,
              paid_at: Date.now(),
              saldo_added: true
            });
            
            updatedCount++;
          }
        } else if (tx.method === "QRIS Pakasir") {
          const res = await axios.post(
            "https://app.pakasir.com/api/transactionstatus",
            {
              project: pakasirProject,
              order_id: tx.order_id,
              api_key: apiPakasir
            },
            {
              headers: { "Content-Type": "application/json" },
              timeout: 10000
            }
          );

          const status = res.data?.status?.toUpperCase();

          if (status === "PAID" || status === "SUCCESS") {
            updateTransaction(tx.order_id, {
              status: "PAID",
              paid_at: Date.now()
            });

            const saldoDb = readSaldo();
            if (!saldoDb[userId]) {
              saldoDb[userId] = {
                username: tx.username || null,
                saldo: 0
              };
            }
            
            saldoDb[userId].saldo += Number(tx.amount);
            saveSaldo(saldoDb);
            
            updateTransaction(tx.order_id, {
              paid: true,
              paid_at: Date.now(),
              saldo_added: true
            });
            
            updatedCount++;
          }
        }
      } catch (error) {
        console.error(`[REFRESH] Error cek pending ${tx.order_id}:`, error.message);
      }
    }

    const saldoData = realSaldoUser(userId, username);
    const saldoAmount = saldoData.saldo || 0;

    const allPending = getUserPendingTransactions(userId);
    const pendingCount = allPending.length;
    const pendingTotal = allPending.reduce((sum, tx) => sum + (tx.amount || 0), 0);

    let statusMessage = "";
    if (updatedCount > 0) {
      statusMessage = `✅ <b>${updatedCount} transaksi berhasil diproses!</b>\n\n`;
    }

    const message = 
      statusMessage +
      `💰 <b>Saldo Aktif Anda</b>

${rupiah(saldoAmount)}

<i>Silahkan deposit untuk order.</i>`;

    await bot.editMessageText(
      message,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "💳 Top Up", callback_data: "topup_saldo" }],
            [{ text: "🔄 Refresh Saldo", callback_data: "refresh_saldo" }
            ]
          ]
        }
      }
    );
  }
    
  if (data === "topup_saldo") {
    await bot.answerCallbackQuery(cb.id, {
      text: "💳 Membuka menu deposit",
      show_alert: false
    });

    await bot.editMessageText(
      `💳 <b>Cara Top Up Saldo</b>

<b>Otomatis via QRIS All Payment:</b>
<code>/deposit NOMINAL</code>

${bq}ℹ <b>Contoh Penggunaan:</b>
• <code>/deposit 10000</code> – Top up Rp10.000
• <code>/deposit 50000</code> – Top up Rp50.000${ebq}

<b>Minimum deposit:</b> Rp 1,000
<b>Biaya admin:</b> 0,7%+200 dari nominal

📞 <b>Transfer Manual (No Fee)</b>
Hubungi admin jika butuh bantuan
@${settings.dev}`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "⬅ Kembali", callback_data: "refresh_saldo" },
            ],
          ]
        }
      }
    );
  }
});

bot.onText(/^\/addsaldo\s+(\d+)\s+(\d+)$/i, async (msg, match) => {
  const chatId = msg.chat.id

  if (msg.from.id !== 5833239531) {
    return bot.sendMessage(chatId, "❌ Khusus Owner")
  }

  const targetId = parseInt(match[1])
  const amount = parseInt(match[2])

  if (amount <= 0) {
    return bot.sendMessage(chatId, "❌ Nominal tidak valid")
  }

  const user = addSaldoUser(targetId, null, amount)

  bot.sendMessage(
    chatId,
    `✅ Saldo berhasil ditambahkan

🆔 User ID: ${targetId}
💰 Nominal: ${rupiah(amount)}
💳 Saldo Sekarang: ${rupiah(user.saldo)}`
  )

  bot.sendMessage(
    8224141460,
    `🔔 UPDATE SALDO

🆔 User ID: ${targetId}
➕ ${rupiah(amount)}
💳 Total: ${rupiah(user.saldo)}`
  )
})

bot.onText(/^\/editsaldo(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (userId !== ownerId) {
    return bot.sendMessage(chatId, `❌ @${settings.dev} Only!`, {
      reply_to_message_id: msg.message_id
    });
  }

  let targetId = match[1];
  let targetUsername = null;
  let targetName = null;

  if (!targetId && msg.reply_to_message?.from) {
    const repliedUser = msg.reply_to_message.from;
    targetId = String(repliedUser.id);
    targetUsername = repliedUser.username || null;
    targetName = `${repliedUser.first_name || ""} ${repliedUser.last_name || ""}`.trim();
  }

  if (!targetId) {
    return bot.sendMessage(
      chatId,
      "❌ Format: /editsaldo <user_id>\nAtau reply pesan user dengan /editsaldo",
      { reply_to_message_id: msg.message_id }
    );
  }

  const saldoDb = readSaldo();

  if (!saldoDb[targetId]) {
    saldoDb[targetId] = {
      username: targetUsername,
      saldo: 0
    };
    saveSaldo(saldoDb);
  }

  const currentData = saldoDb[targetId];
  const currentSaldo = currentData.saldo ?? 0;
  const finalUsername = currentData.username ?? targetUsername;

  userStates[userId] = {
    step: "editsaldo_waiting_amount",
    targetUserId: targetId,
    currentSaldo,
    username: finalUsername,
    replyToMessage: msg.reply_to_message ? {
      message_id: msg.reply_to_message.message_id,
      user_info: {
        id: targetId,
        username: targetUsername,
        name: targetName
      }
    } : null
  };

  const usernameText = finalUsername ? `@${finalUsername}` : "-";

  return bot.sendMessage(
    chatId,
    `📑 <b>Saldo User Edited</b>

👤 Username: ${usernameText}
🆔 ID: <code>${targetId}</code>

💰 <b>Saldo Aktif:</b> ${rupiah(currentSaldo)}
${bq}<b>Kirim nominal saldo baru:</b>
• Contoh: <code>50000</code> untuk set Rp 50,000
• Contoh: <code>-10000</code> untuk kurangi Rp 10,000
• Contoh: <code>0</code> untuk reset ke nol${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: "❌ Batal", callback_data: "cancel_editsaldo" }]
        ]
      }
    }
  );
});

bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;
  
  if (userId !== ownerId) return;
  if (!text || text.startsWith("/")) return;
  
  const state = userStates[userId];
  if (!state || state.step !== "editsaldo_waiting_amount") return;
  
  const targetUserId = state.targetUserId;
  const currentSaldo = state.currentSaldo;
  const targetUsername = state.username;
  
  let newAmount;
  
  try {
    newAmount = parseFloat(text.replace(/[^\d\-.]/g, ""));
    if (isNaN(newAmount)) throw new Error("Format angka tidak valid");
  } catch (error) {
    delete userStates[userId];
    return bot.sendMessage(
      chatId,
      "❌ Format tidak valid. Harap kirim angka.\n" +
      "Contoh: 50000 atau -10000",
      { reply_to_message_id: msg.message_id }
    );
  }
  
  delete userStates[userId];
  
  const saldoDb = readSaldo();
  
  if (!saldoDb[targetUserId]) {
    saldoDb[targetUserId] = {
      username: targetUsername,
      saldo: 0
    };
  }
  
  const oldSaldo = saldoDb[targetUserId].saldo || 0;
  saldoDb[targetUserId].saldo = newAmount;
  saveSaldo(saldoDb);
  
  const difference = newAmount - oldSaldo;
  const differenceText = difference >= 0 
    ? `+${rupiah(difference)}` 
    : `${rupiah(difference)}`;
  
  const logEntry = {
    action: "EDIT_SALDO",
    target_user_id: targetUserId,
    target_username: targetUsername,
    old_saldo: oldSaldo,
    new_saldo: newAmount,
    difference: difference,
    edited_by: userId,
    edited_by_username: msg.from.username,
    edited_at: Date.now()
  };
  
  editSaldoLog(logEntry);
  
  await bot.sendMessage(
    chatId,
    `✅ <b>Saldo Berhasil Update</b>

👤 Username: ${targetUsername || "-"}
🆔 ID: <code>${targetUserId}</code>

${bq}ℹ️ <b>Statistik:</b>
• Saldo Lama: ${rupiah(oldSaldo)}
• Saldo Baru: ${rupiah(newAmount)}
• Selisih: ${differenceText}${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id
    }
  );
  
  try {
    await bot.sendMessage(
      targetUserId,
      `🏦 <b>UPDATE SALDO</b>

Saldo Anda telah diupdate oleh admin.

${bq}ℹ️ <b>Statistik:</b>
• Saldo Lama: ${rupiah(oldSaldo)}
• Saldo Baru: ${rupiah(newAmount)}
• Perubahan: ${differenceText}${ebq}

/ceksaldo untuk verifikasi saldo.`,
      { parse_mode: "HTML" }
    );
  } catch (error) {
    await bot.sendMessage(
      chatId,
      `⚠️ Tidak bisa mengirim notifikasi ke user.\n` +
      `Mungkin user belum start bot.`,
      { reply_to_message_id: msg.message_id }
    );
  }
});

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const data = cb.data;
  const userId = cb.from.id;
  
  if (userId !== ownerId) return;
  
  if (data === "cancel_editsaldo") {
    await bot.answerCallbackQuery(cb.id, {
      text: "❌ Edit saldo dibatalkan",
      show_alert: false
    });
    
    delete userStates[userId];
    
    await bot.editMessageText(
      "❌ Edit saldo dibatalkan.",
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );
  }
});

bot.onText(/^\/deposit(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  // TANPA NOMINAL
  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `💳 <b>Cara Top Up Saldo</b>

<b>Otomatis via QRIS All Payment:</b>
<code>/deposit NOMINAL</code>

${bq}ℹ <b>Contoh:</b>
• /deposit 10000
• /deposit 50000${ebq}

<b>Minimum:</b> Rp1.000
<b>Admin:</b> 0,7% + 200

<b>📌 Manual (No Fee)</b>
Pilih <b>QRIS Manual</b> setelah input nominal`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    );
  }

  const amount = parseInt(match[1], 10);
  if (!amount || amount < 1000) {
    return bot.sendMessage(chatId, "❌ Minimal deposit Rp1.000");
  }

  depositSessions.set(userId, {
    userId,
    amount,
    username: msg.from.username || null,
    chatId,
    createdAt: Date.now()
  });

  return bot.sendPhoto(chatId, qris, {
    caption: `<b>💳 Metode QRIS Deposit</b>
Total Bayar: ${rupiah(amount)}

${bq}<b>🔍 Syarat Deposit</b>${ebq}
• Saldo mencukupi
• Transfer via Bank/Wallet
• Batas waktu 5 menit`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "QRIS Atlantic", callback_data: `deposit_atlantic:${userId}` },
            { text: "QRIS Pakasir", callback_data: `deposit_pakasir:${userId}` }
          ],
          [
            { text: "QRIS Manual", callback_data: `deposit_manual:${userId}` }
          ],
        ]
      }
    }
  );
});

bot.on("callback_query", async (cb) => {
  const data = cb.data || "";
  if (!data.startsWith("deposit_")) return;

  const chatId = cb.message.chat.id;
  const userId = String(cb.from.id);

  await bot.answerCallbackQuery(cb.id).catch(() => {});

  // CANCEL
  if (data.startsWith("deposit_cancel:")) {
    const target = data.split(":")[1];
    if (target !== userId) {
      return bot.answerCallbackQuery(cb.id, { text: "❌ Bukan deposit kamu", show_alert: true });
    }

    depositSessions.delete(userId);
    await safeDeleteMessage(bot, chatId, cb.message.message_id);
    return bot.sendMessage(chatId, "❌ Deposit dibatalkan");
  }

  const sess = depositSessions.get(userId);
  if (!sess) {
    return bot.answerCallbackQuery(cb.id, { text: "❌ Session expired", show_alert: true });
  }

  if (data.startsWith("deposit_atlantic:")) {
    return processAtlanticDeposit(cb, sess);
  }

  if (data.startsWith("deposit_pakasir:")) {
    return processPakasirDeposit(cb, sess);
  }

  if (data.startsWith("deposit_manual:")) {
    return createDepositManual(cb, sess);
  }
});

bot.on("message", async (msg) => {
  if (!msg.photo) return;

  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const pending = readJSON(depositPending, {});
  const trx = pending[String(userId)];

  if (!trx || trx.status !== "WAITING_PAYMENT") return;

  if (Date.now() > trx.expired_at) {
    delete pending[String(userId)];
    writeJSON(depositPending, pending);
    return bot.sendMessage(chatId, "❌ Deposit expired.");
  }

  const fileId = msg.photo.at(-1).file_id;

  const sentToOwner = await bot.sendPhoto(ownerId, fileId, {
    caption:
      `<b>🧾 Konfirmasi Deposit</b>\n\n` +
      `👤 User: <code>${trx.user_id}</code> (${trx.username || "-"})\n` +
      `🆔 Order ID:\n<code>${trx.order_id}</code>\n\n` +
      `💰 Nominal: ${rupiah(trx.amount)}`,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[
        { text: "Setujui", callback_data: `dep_ok:${trx.order_id}:${trx.user_id}` },
        { text: "Tolak", callback_data: `dep_no:${trx.order_id}:${trx.user_id}` }
      ]]
    }
  });

  trx.proof = fileId;
  trx.owner_message_id = sentToOwner.message_id;
  trx.owner_chat_id = ownerId;

  pending[String(userId)] = trx;
  writeJSON(depositPending, pending);

  return bot.sendMessage(
    chatId,
    `✅ <i>Bukti transfer diterima! Silahkan menunggu verifikasi owner.</i>`,
    { parse_mode: "HTML" }
  );
});

bot.on("callback_query", async (cq) => {
  if (!cq.data.startsWith("dep_")) return;
  if (cq.from.id !== ownerId) return;

  await bot.answerCallbackQuery(cq.id).catch(() => {});

  const [act, orderId, userId] = cq.data.split(":");
  const pending = readJSON(depositPending, {});
  const trx = pending[userId];
  if (!trx || trx.order_id !== orderId) return;

  if (act === "dep_ok") {
    realSaldoUser(userId, trx.username);
    applySaldo({
      order_id: trx.order_id,
      user_id: userId,
      amount: trx.amount,
      paid: trx.paid === true
    });

    trx.status = "PAID";
    trx.paid = true;
    writeJSON(depositPending, pending);

    const saldo = getSaldoUser(userId)?.saldo || 0;

    await bot.sendMessage(trx.chatId,
      `✅ <b>Saldo Deposit disetujui</b>\n\n🆔 Order ID:\n<code>${trx.order_id}</code>\n\n➕ Saldo masuk: ${rupiah(trx.amount)}\n🏦 Saldo sekarang: ${rupiah(saldo)}`,
      { parse_mode: "HTML" }
    );
      
    try {
    await bot.deleteMessage(trx.owner_chat_id, trx.owner_message_id);
  } catch {}

  return;
  }

  if (act === "dep_no") {
    trx.status = "REJECTED";
    writeJSON(depositPending, pending);

    await bot.sendMessage(trx.chatId,
      `❌ <b>Saldo Deposit ditolak!</b>\n🆔 Order ID:\n<code>${trx.order_id}</code>\n\n<i>Silahkan kirim bukti yang valid.</i>`,
      { parse_mode: "HTML" }
    );
      
    try {
    await bot.deleteMessage(trx.owner_chat_id, trx.owner_message_id);
  } catch {}

  return;
  }
});


bot.on("callback_query", async (cb) => {
  if (!cb.data.startsWith("deposit_qris_cancel:")) return;
  
  await bot.answerCallbackQuery(cb.id).catch(() => {});
  
  const parts = cb.data.split(":");
  const orderId = parts[1];
  const userId = parts[2];
  
  if (String(cb.from.id) !== userId) {
    return bot.answerCallbackQuery(cb.id, {
      text: "❌ Bukan deposit Anda",
      show_alert: true
    });
  }

  // Update transaction status
  updateTransaction(orderId, {
    status: "CANCELLED",
    cancelled_at: Date.now()
  });

  // Hapus session
  depositSessions.delete(userId);

  // Hapus QR message
  await bot.deleteMessage(cb.message.chat.id, cb.message.message_id).catch(() => {});

  await bot.sendMessage(
    cb.message.chat.id,
    `❌ Deposit dibatalkan\nOrder ID: <code>${orderId}</code>`,
    { parse_mode: "HTML" }
  );
});

async function safeDeleteMessage(bot, chatId, messageId) {
  try {
    await bot.deleteMessage(chatId, messageId);
  } catch (error) {
  }
}

function randomCode(length) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function buildDepositCaption({ orderId, amount, total, expired, method }) {
  return `${bq}<b>🧾 Transaksi ${method}</b>${ebq}

🆔 <b>Order ID:</b> <code>${orderId}</code>

💰 <b>Nominal:</b> ${rupiah(amount)}
💳 <b>Total Bayar:</b> ${rupiah(total)}

${bq}<b>⏳ Expired:</b> ${expired}${ebq}

${bq}🔍 <b>Cara Pembayaran:</b>${ebq}
1. Buka e-wallet / m-banking
2. Pilih Scan QRIS
3. Scan QR di atas
4. Konfirmasi pembayaran`
}

function genOrderId(prefix = "DP") {
  return `${prefix}${Date.now()}${Math.floor(Math.random() * 999)}`
}

async function createDepositManual(cq, sess) {
  const chatId = cq.message.chat.id
  const userId = sess.userId
  const username = sess.username ? `@${sess.username}` : "-"

  const orderId = genOrderId("DPM-")
  const expiredAt = Date.now() + 5 * 60 * 1000
  const expiredText = new Date(expiredAt).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  })

  const pending = readJSON(depositPending, {})
  pending[String(userId)] = {
    order_id: orderId,
    user_id: userId,
    username,
    chatId,
    amount: sess.amount,
    total: sess.amount,
    method: "QRIS MANUAL",
    status: "WAITING_PAYMENT",
    created_at: Date.now(),
    expired_at: expiredAt,
    paid: false
  }
  writeJSON(depositPending, pending)

  const caption = `${bq}🧾 <b>Tagihan QRIS Manual</b>

🆔 <b>Order ID:</b> <code>${orderId}</code>

💳 <b>Payment Dana:</b> <code>${settings.noDana}</code>
a/n <b>${settings.namaDana}</b>

💰 <b>Total Bayar:</b> ${rupiah(sess.amount)}

<i>Silahkan scan QRIS diatas sesuai nominal dan kirim foto bukti transfer.</i>
${ebq}`

  const sent = await bot.sendPhoto(chatId, qris, {
    caption,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "Batal Deposit", callback_data: `cancel_deposit_manual:${userId}` }]]
    }
  })

  depositSessions.set(chatId, {
    ...sess,
    messageId: sent.message_id,
    orderId,
    method: "QRIS MANUAL"
  })

  return sent
}

bot.on("callback_query", async (cq) => {
  const data = cq.data || ""
  if (!data.startsWith("cancel_deposit_manual:")) return

  const chatId = cq.message.chat.id
  const userId = cq.from.id
  const targetId = String(data.split(":")[1] || "")

  await bot.answerCallbackQuery(cq.id).catch(() => {})

  if (String(userId) !== targetId) {
    return bot.answerCallbackQuery(cq.id, { text: "❌ Bukan deposit kamu", show_alert: true }).catch(() => {})
  }

  const pending = readJSON(depositPending, {})
  if (pending[targetId]) {
    delete pending[targetId]
    writeJSON(depositPending, pending)
  }

  const sess = depositSessions.get(chatId)
  if (sess && sess.userId === userId) depositSessions.delete(chatId)

  try {
    await bot.deleteMessage(chatId, cq.message.message_id)
  } catch {}
})

async function createDepositPakasir(cq, sess) {
  const chatId = cq.message.chat.id

  try {
    const orderId = `DP${Date.now()}${Math.floor(Math.random() * 999)}`

    const res = await axios.get("https://app.pakasir.com/api/createqris", {
      params: {
        project: pakasirProject,
        order_id: orderId,
        amount: sess.amount,
        api_key: apiPakasir
      }
    })

    const tx = res.data?.transaction || res.data?.data || res.data

    const qrisUrl =
      tx?.qris_image ||
      tx?.qris_url ||
      tx?.qr_url ||
      tx?.qr_image ||
      tx?.payment_url ||
      tx?.url

    const expiredRaw =
      tx?.expired_at ||
      tx?.expired ||
      tx?.expire ||
      tx?.expiration

    const expired = formatWIBFull(expiredRaw) !== "-" ? formatWIBFull(expiredRaw) : "± 5 Menit"

    if (!qrisUrl) {
      return bot.sendMessage(chatId, "❌ QR Pakasir tidak ditemukan dari response API.", {
        reply_to_message_id: cq.message.message_id
      })
    }

    const caption = buildDepositCaption({
      orderId,
      amount: sess.amount,
      total: sess.amount,
      expired,
      method: "QRIS Pakasir"
    })

    const sent = await bot.sendPhoto(chatId, qrisUrl, {
      caption,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[{ text: "Batal Deposit", callback_data: "cancel_deposit" }]]
      }
    })

    depositSessions.set(chatId, {
      ...sess,
      messageId: sent.message_id,
      orderId,
      method: "QRIS Pakasir"
    })

    addTransaction({
      order_id: orderId,
      user_id: cq.from.id,
      username: cq.from.username || null,
      amount: sess.amount,
      total_bayar: sess.amount,
      method: "QRIS Pakasir",
      status: "PENDING",
      created_at: Date.now()
    })

    notifyOwnerDeposit({
      username: cq.from.username,
      user_id: cq.from.id,
      nominal: sess.amount
    })
  } catch (err) {
    console.log(err?.response?.data || err)
    return bot.sendMessage(chatId, "❌ Gagal membuat QRIS Pakasir.", {
      reply_to_message_id: cq.message.message_id
    })
  }
}

function buildDepositCaption({
  orderId,
  amount,
  total,
  expired,
  method
}) {
  const fee = total - amount;
  
  return `${bq}<b>🧾 Transaksi ${method}</b>${ebq}

🆔 <b>Order ID:</b> <code>${orderId}</code>

💰 <b>Nominal:</b> ${rupiah(amount)}
💸 <b>Biaya Admin:</b> ${rupiah(fee)}
💳 <b>Total Bayar:</b> ${rupiah(total)}

${bq}<b>⏳ Expired:</b> ${expired}${ebq}

${bq}🔍 <b>Cara Pembayaran:</b>${ebq}
1. Buka e-wallet / m-banking
2. Pilih Scan QRIS
3. Scan QR di atas
4. Konfirmasi pembayaran`
}

async function createDepositPakasir(cq, sess) {
  const chatId = cq.message.chat.id

  try {
    const orderId = `DP${Date.now()}${Math.floor(Math.random() * 999)}`

    const res = await axios.get("https://app.pakasir.com/api/createqris", {
      params: {
        project: pakasirProject,
        amount: sess.amount,
        order_id: orderId,
        api_key: apiPakasir
      }
    })

    const tx = res.data?.transaction || res.data?.data || res.data

    const qrisUrl =
      tx?.qris_image ||
      tx?.qris_url ||
      tx?.qr_url ||
      tx?.qr_image ||
      tx?.payment_url ||
      tx?.url

    if (!qrisUrl) {
      return bot.sendMessage(chatId, "❌ QR Pakasir tidak ditemukan dari response API.")
    }

    const fee = Math.ceil(sess.amount * 1 / 100);
    const total = sess.amount + fee;

    const db = readTransactions()
    db.transactions.push({
      user_id: sess.userId,
      username: sess.username || "-",
      order_id: orderId,
      method: "PAKASIR",
      amount: sess.amount,
      biaya_admin: fee,
      total_bayar: total,
      status: "PENDING",
      created_at: Date.now()
    })
    writeJSON("./database/transactions.json", db)

    await bot.sendPhoto(chatId, qrisUrl, {
      caption:
`${bq}<b>🧾 Transaksi QRIS (Pakasir)</b>${ebq}

🆔 <b>Order ID:</b> <code>${orderId}</code>

💰 <b>Nominal:</b> ${rupiah(sess.amount)}
💸 <b>Biaya Admin:</b> ${rupiah(fee)}
💳 <b>Total Bayar:</b> ${rupiah(total)}

⏳ <b>Status:</b> PENDING

Kirim bukti pembayaran atau cek status:
<code>/cekdeposit ${orderId}</code>`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Cek Status", callback_data: `cekdep_${orderId}` }]
        ]
      }
    })

    depositSessions.delete(chatId)
  } catch (err) {
    console.log(err?.response?.data || err)
    return bot.sendMessage(chatId, "❌ Gagal membuat QRIS Pakasir.")
  }
}

async function createDepositAtlantic(cq, sess) {
  const chatId = cq.message.chat.id
  const amount = sess.amount
  const fee = Math.ceil(amount * 1.4 / 100 + 200)
  const total = amount + fee
  const orderId = `ATL-${Date.now()}`

  const res = await axios.post(
    "https://atlantich2h.com/deposit/create",
    qs.stringify({
      api_key: config.apiAtlantic,
      reff_id: orderId,
      nominal: total,
      type: "ewallet",
      metode: "qrisfast"
    }),
    { headers: { "Content-Type": "application/x-www-form-urlencoded" } }
  )

  const info = res.data.data
  const qrImage = await generatePlainQrPng(info.qr_string)

  const sent = await bot.sendPhoto(chatId, qrImage, {
    caption: buildDepositCaption({
      orderId,
      amount,
      total,
      expired: "± 5 Menit",
      method: "QRIS Atlantic"
    }),
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [[{ text: "Batal Deposit", callback_data: "cancel_deposit" }]]
    }
  })

  depositSessions.set(chatId, {
    ...sess,
    messageId: sent.message_id,
    orderId,
    atlanticId: info.id,
    method: "QRIS Atlantic"
  })

  addTransaction({
    order_id: orderId,
    user_id: cq.from.id,
    username: cq.from.username || null,
    amount,
    biaya_admin: fee,
    total_bayar: total,
    method: "QRIS Atlantic",
    status: "PENDING",
    created_at: Date.now()
  })

  notifyOwnerDeposit({
    username: cq.from.username,
    user_id: cq.from.id,
    nominal: total,
    biaya_admin: fee
  })
}

bot.onText(/^\/riwayatdeposit$/i, async (msg) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  const db = readTransactions()
  const list = db.transactions.filter(t => t.user_id === userId)

  if (list.length === 0) {
    return bot.sendMessage(chatId, "📭 Belum ada riwayat deposit.")
  }

  let text = `${bq}<b>📜 Riwayat Deposit User</b>${ebq}\n\n`

  list.slice(-10).reverse().forEach((t, i) => {
    text += `${bq}${i + 1}️⃣ <code>${t.order_id}</code>${ebq}\n`
    text += `💳 ${t.method}\n`
    text += `💰 ${rupiah(t.total_bayar)}\n`
    text += `📊 ${t.status}\n`
    text += `📆 ${formatWIBFull(t.created_at)}\n\n`
  })

  bot.sendMessage(chatId, text, { reply_to_message_id: msg.message_id, parse_mode: "HTML" })
})

bot.onText(/^\/listdeposit(?:\s+(pending|paid|cancelled))?$/i, async (msg, match) => {
  const chatId = msg.chat.id

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
`${bq}<b>ℹ Contoh Penggunaan</b>${ebq}
<code>/listdeposit pending</code>
<code>/listdeposit paid</code>
<code>/listdeposit cancelled</code>`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    )
  }
    
  const status = match[1].toUpperCase()
  const db = readTransactions()
  const list = db.transactions.filter(t => t.status === status)

  if (list.length === 0) {
    return bot.sendMessage(chatId, `📭 Tidak ada transaksi ${status}`)
  }

  let text = `${bq}<b>📋 User List Deposit (${status})</b>${ebq}\n\n`

  list.slice(-15).reverse().forEach((t, i) => {
    text += `${bq}${i + 1}️⃣ <code>${t.order_id}</code>${ebq}\n`
    text += `👤 @${t.username || "unknown"}\n`
    text += `💰 ${rupiah(t.total_bayar)}\n`
    text += `📆 ${formatWIBFull(t.created_at)}\n\n`
  })

  bot.sendMessage(chatId, text, { parse_mode: "HTML" })
})

bot.onText(/^\/totaldeposit(?:\s+@?(\w+)(?:\s+(paid|pending|cancelled))?)?$/i, async (msg, match) => {
  const chatId = msg.chat.id

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
`${bq}<b>ℹ Contoh Penggunaan</b>${ebq}
<code>/totaldeposit @username</code>
<code>/totaldeposit @username paid</code>
<code>/totaldeposit @username pending</code>
<code>/totaldeposit @username cancelled</code>`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    )
  }

  const username = match[1].toLowerCase()
  const status = (match[2] || "paid").toUpperCase()

  const db = readTransactions()
  const list = db.transactions.filter(t =>
    t.username &&
    t.username.toLowerCase() === username &&
    t.status === status
  )

  if (list.length === 0) {
    return bot.sendMessage(chatId, `📭 Tidak ada deposit ${status} untuk @${username}`)
  }

  const total = list.reduce((a, b) => a + b.total_bayar, 0)

  bot.sendMessage(
    chatId,
`${bq}<b>🧾 Total Deposit User</b>${ebq}
👤 Username: @${username}
⏳ Status: ${status}
💰 Nominal: ${rupiah(total)}`,
    { parse_mode: "HTML" }
  )
})

bot.onText(/^\/cekdeposit(?:\s+(\S+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const orderId = match[1]
  
  if (!match[1]) {
    return bot.sendMessage(
      chatId,
`${bq}<b>ℹ Contoh Penggunaan</b>${ebq}
<code>/cekdeposit ORDER_ID</code>
<code>/cekdeposit PKSR-123456</code>`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    )
  }

  const db = readTransactions()
  const trx = db.transactions.find(t => t.order_id === orderId)

  if (!trx) {
    return bot.sendMessage(chatId, "❌ Order ID tidak ditemukan.")
  }

  try {
    const res = await axios.get(
      "https://app.pakasir.com/api/transactiondetail",
      {
        params: {
          project: pakasirProject,
          order_id: orderId,
          amount: trx.amount,
          api_key: apiPakasir
        }
      }
    )

    const tx = res.data.transaction

    if (!tx) {
      return bot.sendMessage(chatId, "❌ Data transaksi tidak valid.")
    }

    let status = tx.status.toUpperCase()

    if (tx.status === "completed") {
      updateTransaction(orderId, {
        status: "PAID",
        completed_at: tx.completed_at
      })
      status = "PAID"
    }

    return bot.sendMessage(
      chatId,
      `${bq}<b>🧾 Transaksi Detail</b>${ebq}

🆔 <b>Order ID:</b> <code>${orderId}</code>

💳 <b>Metode:</b> ${tx.payment_method}
💰 <b>Nominal:</b> ${rupiah(tx.amount)}
⏳ <b>Status:</b> ${status}

${bq}📆 <b>Waktu:</b> ${tx.completed_at ? formatWIBFull(tx.completed_at) : "-"}${ebq}`,
      { reply_to_message_id: msg.message_id, parse_mode: "HTML" }
    )

  } catch (err) {
    console.log(err?.response?.data || err)
    return bot.sendMessage(chatId, "❌ Gagal cek status transaksi.")
  }
})

if (!fs.existsSync(fileDir)) fs.mkdirSync(fileDir, { recursive: true });

function readProductsDb() {
  try {
    const raw = fs.readFileSync(productFile, "utf8");
    const json = JSON.parse(raw || "{}");
    if (!json.products || !Array.isArray(json.products)) json.products = [];
    return json;
  } catch {
    return { products: [] };
  }
}

function writeProductsDb(db) {
  fs.writeFileSync(productFile, JSON.stringify(db, null, 2));
}

function sanitizeId(str) {
  return String(str)
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_")
    .replace(/[^a-z0-9_\-]/g, "");
}

async function downloadFile(fileId, destPath) {
  const file = await bot.getFile(fileId);
  const fileUrl = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;
  const res = await axios.get(fileUrl, { responseType: "stream" });
  await new Promise((resolve, reject) => {
    const w = fs.createWriteStream(destPath);
    res.data.pipe(w);
    w.on("finish", resolve);
    w.on("error", reject);
  });
  return destPath;
}

async function produkOrder(q) {
  const userId = q.from.id
  const productId = q.data.replace("order_", "")

  const db = readJSON("./database/products.json", { products: [] })
  const products = Array.isArray(db) ? db : (db.products || [])
  const product = products.find(p => String(p.id) === String(productId))

  if (!product) {
    await bot.answerCallbackQuery(q.id, {
      text: "❌ Produk tidak ditemukan / sudah dihapus",
      show_alert: true
    })
    return
  }

  const saldoDb = readJSON("./database/saldo.json", {})
  const saldo = saldoDb[String(userId)]?.saldo || 0

  await bot.editMessageCaption(
`◜🛒◞ <b>Konfirmasi Pembayaran</b>

⤥ Script: <b>${product.name}</b>
⤥ Nominal: <b>${rupiah(product.price)}</b>

${bq}<b>Silahkan pilih Metode Pembayaran:</b>${ebq}`,
    {
      chat_id: q.message.chat.id,
      message_id: q.message.message_id,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💰 Saldo", callback_data: `confirm_${product.id}` },
            { text: "📲 QRIS", callback_data: `qris_${product.id}` }
          ],
          [{ text: "Kembali", callback_data: "product_menu" }]
        ]
      }
    }
  )
}

async function produkConfirm(q) {
  const chatId = q.message.chat.id
  const messageId = q.message.message_id
  const userId = q.from.id
  const username = q.from.username ? `@${q.from.username}` : "-"
  const productId = q.data.replace("confirm_", "")

  const products = readJSON("./database/products.json", { products: [] }).products
  const product = products.find(p => String(p.id) === String(productId))

  const saldoDb = readJSON("./database/saldo.json", {})
  if (!saldoDb[userId] || saldoDb[userId].saldo < product.price) {
    await bot.answerCallbackQuery(q.id, { text: "❌ Saldo tidak mencukupi", show_alert: true })
    return
  }

  saldoDb[userId].saldo -= product.price
  writeJSON("./database/saldo.json", saldoDb)

  const trxDb = readJSON("./database/transactions.json", { transactions: [] })
  trxDb.transactions.push({
    user_id: userId,
    username,
    product_id: product.id,
    product_name: product.name,
    price: product.price,
    status: "SUCCESS",
    time: Date.now()
  })
  writeJSON("./database/transactions.json", trxDb)

  try { await bot.deleteMessage(chatId, messageId) } catch {}

  await bot.sendMessage(
    chatId,
`◜✅◞ <b>Transaksi Berhasil!</b>
Script segera dikirim otomatis

${bq}⤥ Script: <b>${product.name}</b>
⤥ Harga: <b>${rupiah(product.price)}</b>
⤥ Tanggal: <b>${new Date().toLocaleDateString("id-ID", {
  day: "2-digit",
  month: "long",
  year: "numeric"
})}</b>
${ebq}`,
    {
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Contact", url: "https://t.me/gunturnaktido" },
            { text: "Channel", url: "https://t.me/gunturnaktido" }
          ]
        ]
      }
    }
  )

  try {
    await bot.sendDocument(chatId, product.file, {
      caption: `${bq}📦 <b>${product.name}</b>${ebq}`,
      parse_mode: "HTML"
    })
  } catch {
    await bot.sendMessage(chatId, "⚠️ File gagal dikirim, hubungi admin", { parse_mode: "HTML" })
  }

  try {
    await bot.sendMessage(
      "@gunturnaktido",
`${bq}◜🛒◞ <b>Naeri Store Updated</b>

⤥ Username: ${username}
⤥ User ID: <code>${userId}</code>

⤥ Method: Via Saldo
⤥ Script: ${product.name}
⤥ Nominal: ${rupiah(product.price)}

🗓️ Tanggal: ${new Date().toLocaleDateString("id-ID", {
  day: "2-digit",
  month: "long",
  year: "numeric"
})}${ebq}`,
      {
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Buy Script", url: "https://t.me/naeriast_bot" },
              { text: "Support", url: "https://t.me/gunturnaktido" }
            ]
          ]
        }
      }
    )
  } catch {}
}

bot.onText(/^\/addproduk$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (userId !== ownerId) {
    return bot.sendMessage(chatId, "❌ Khusus Owner.", { parse_mode: "HTML" });
  }

  addProdukSession[userId] = { step: "id" };
  return bot.sendMessage(
    chatId,
    `🧾 <b>Konfirmasi Produk</b>\n\nKirim <b>ID Produk:</b>\n(Contoh: <code>script_naeri_update</code>)`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/^\/delproduk$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (userId !== ownerId) {
    return bot.sendMessage(chatId, "❌ Khusus Owner.", { parse_mode: "HTML" });
  }

  const db = readProductsDb();
  const products = db.products || [];

  if (products.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada produk di database.", { parse_mode: "HTML" });
  }

  const keyboard = products.map(p => [
    { text: `${p.name} - ${rupiah(p.price)}`, callback_data: `delproduk_pick:${p.id}` }
  ]);
  keyboard.push([{ text: "Batalkan", callback_data: "delproduk_close" }]);

  return bot.sendMessage(
    chatId,
    `<b>🗑️ Menghapus Produk</b>\n\nProduk yang tersedia:`,
    { parse_mode: "HTML", reply_markup: { inline_keyboard: keyboard } }
  );
});

bot.on("callback_query", async (q) => {
  const data = q.data || "";
  const chatId = q.message?.chat?.id;

  if (!data.startsWith("delproduk_")) return;

  try { await bot.answerCallbackQuery(q.id); } catch (_) {}

  if (!chatId) return;

  if (q.from.id !== ownerId) {
    try { await bot.answerCallbackQuery(q.id, { text: "❌ Khusus Owner.", show_alert: true }); } catch (_) {}
    return;
  }

  if (data === "delproduk_close") {
    try { await bot.deleteMessage(chatId, q.message.message_id).catch(() => {}); } catch (_) {}
    return;
  }

  if (data.startsWith("delproduk_pick:")) {
    const id = data.split(":")[1];
    const db = readProductsDb();
    const prod = (db.products || []).find(p => String(p.id) === String(id));

    if (!prod) {
      return bot.editMessageText("❌ Produk tidak ditemukan.", {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML"
      });
    }

    const text =
      `<b>⚠️ Konfirmasi Hapus Produk</b>\n\n` +
      `• ID: <code>${prod.id}</code>\n` +
      `• Nama: <b>${prod.name}</b>\n` +
      `• Harga: <b>${rupiah(prod.price)}</b>\n\n`;

    const markup = {
      inline_keyboard: [
        [{ text: "Hapus", callback_data: `delproduk_yes:${prod.id}` }],
        [{ text: "❌ Batalkan", callback_data: "delproduk_back" }]
      ]
    };

    if (q.message?.caption) {
      return bot.editMessageCaption(text, {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML",
        reply_markup: markup
      });
    }

    return bot.editMessageText(text, {
      chat_id: chatId,
      message_id: q.message.message_id,
      parse_mode: "HTML",
      reply_markup: markup
    });
  }

  if (data === "delproduk_back") {
    const db = readProductsDb();
    const products = db.products || [];

    if (products.length === 0) {
      const text = "⚠️ Tidak ada produk di database.";
      if (q.message?.caption) {
        return bot.editMessageCaption(text, {
          chat_id: chatId,
          message_id: q.message.message_id,
          parse_mode: "HTML"
        });
      }
      return bot.editMessageText(text, {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML"
      });
    }

    const keyboard = products.map(p => [
      { text: `${p.name} - ${rupiah(p.price)}`, callback_data: `delproduk_pick:${p.id}` }
    ]);
    keyboard.push([{ text: "Batalkan", callback_data: "delproduk_close" }]);

    const text = `<b>🗑️ Menghapus Produk</b>\n\nProduk yang tersedia:`;

    if (q.message?.caption) {
      return bot.editMessageCaption(text, {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard }
      });
    }

    return bot.editMessageText(text, {
      chat_id: chatId,
      message_id: q.message.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: keyboard }
    });
  }

  if (data.startsWith("delproduk_yes:")) {
    const id = data.split(":")[1];
    const db = readProductsDb();
    const before = db.products || [];
    const prod = before.find(p => String(p.id) === String(id));

    if (!prod) {
      const text = "❌ Produk tidak ditemukan.";
      if (q.message?.caption) {
        return bot.editMessageCaption(text, {
          chat_id: chatId,
          message_id: q.message.message_id,
          parse_mode: "HTML"
        });
      }
      return bot.editMessageText(text, {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML"
      });
    }

    db.products = before.filter(p => String(p.id) !== String(id));
    writeProductsDb(db);

    const text =
      `✅ <b>Sukses hapus produk</b>\n\n` +
      `• ID: <code>${prod.id}</code>\n` +
      `• Nama: <b>${prod.name}</b>\n` +
      `• Harga: <b>${rupiah(prod.price)}</b>`;

    if (q.message?.caption) {
      return bot.editMessageCaption(text, {
        chat_id: chatId,
        message_id: q.message.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [[{ text: "Kembali", callback_data: "delproduk_back" }]] }
      });
    }

    return bot.editMessageText(text, {
      chat_id: chatId,
      message_id: q.message.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [[{ text: "Kembali", callback_data: "delproduk_back" }]] }
    });
  }
});

bot.onText(/^\/canceladdproduk$/i, async (msg) => {
  delete addProdukSession[msg.from.id];
  return bot.sendMessage(msg.chat.id, "❌ /addproduk dibatalkan.", { parse_mode: "HTML" });
});

bot.on("message", async (msg) => {
  const chatId = msg.chat?.id;
  const userId = msg.from?.id;
  if (!chatId || !userId) return;

  const sess = addProdukSession[userId];
  if (!sess) return;

  if (userId !== ownerId) return;

  if (sess.step === "id") {
    const id = sanitizeId(msg.text || "");
    if (!id) return bot.sendMessage(chatId, "❌ ID tidak valid. Ulangi kirim ID.", { parse_mode: "HTML" });

    const db = readProductsDb();
    const exists = db.products.some(p => String(p.id).toLowerCase() === id);
    if (exists) return bot.sendMessage(chatId, "❌ ID sudah dipakai. Kirim ID lain.", { parse_mode: "HTML" });

    sess.id = id;
    sess.step = "name";
    return bot.sendMessage(chatId, "Kirim <b>Nama Produk</b>:", { parse_mode: "HTML" });
  }

  if (sess.step === "name") {
    const name = String(msg.text || "").trim();
    if (!name) return bot.sendMessage(chatId, "❌ Nama tidak valid. Ulangi.", { parse_mode: "HTML" });

    sess.name = name;
    sess.step = "price";
    return bot.sendMessage(chatId, "Kirim <b>harga</b> produk:\n(Contoh: <code>25000</code>):", { parse_mode: "HTML" });
  }

  if (sess.step === "price") {
    const price = parseInt(String(msg.text || "").replace(/[^\d]/g, ""), 10);
    if (!price || price < 1) return bot.sendMessage(chatId, "❌ Harga tidak valid. Ulangi.", { parse_mode: "HTML" });

    sess.price = price;
    sess.step = "desc";
    return bot.sendMessage(chatId, "Kirim <b>deskripsi</b> produk:\n(Contoh: Script untuk panel)", { parse_mode: "HTML" });
  }

  if (sess.step === "desc") {
    const description = String(msg.text || "").trim();
    if (!description) return bot.sendMessage(chatId, "❌ Deskripsi tidak valid. Ulangi.", { parse_mode: "HTML" });

    sess.description = description;
    sess.step = "file";
    return bot.sendMessage(chatId, "Kirim <b>file .zip</b> sebagai <b>Document:</b>.", { parse_mode: "HTML" });
  }

  if (sess.step === "file") {
    const doc = msg.document;
    if (!doc) return bot.sendMessage(chatId, "❌ Harus kirim file sebagai <b>Document</b>.", { parse_mode: "HTML" });

    const ext = path.extname(doc.file_name || "").toLowerCase();
    if (ext !== ".zip") return bot.sendMessage(chatId, "❌ File harus <b>.zip</b>.", { parse_mode: "HTML" });

    const savePath = path.join(fileDir, `${sess.id}.zip`);
    try {
      await downloadFile(doc.file_id, savePath);
    } catch (e) {
      return bot.sendMessage(chatId, `❌ Gagal simpan file.\n<code>${String(e?.message || e)}</code>`, { parse_mode: "HTML" });
    }

    const db = readProductsDb();
    db.products.push({
      id: sess.id,
      name: sess.name,
      price: sess.price,
      file: savePath.replace(/\\/g, "/"),
      description: sess.description
    });
    writeProductsDb(db);

    delete addProdukSession[userId];

    return bot.sendMessage(
      chatId,
      `✅ <b>Sukses menambahkan produk</b>\n\n` +
        `• ID: <code>${sess.id}</code>\n` +
        `• Nama: <b>${sess.name}</b>\n` +
        `• Harga: <b>${sess.price}</b>\n` +
        `• Path: <code>${savePath.replace(/\\/g, "/")}</code>`,
      { parse_mode: "HTML" }
    );
  }
});

bot.on("callback_query", async (q) => {
  const data = q.data
  const userId = q.from.id

  if (data.startsWith("order_")) return produkOrder(q)
  if (data.startsWith("confirm_")) return produkConfirm(q)

  if (data.startsWith("qris_")) {
  const productId = data.replace("qris_", "")

  const products = readJSON("./database/products.json", { products: [] }).products
  const product = products.find(p => String(p.id) === String(productId))
  if (!product) {
    await bot.answerCallbackQuery(q.id, { text: "❌ Produk tidak ditemukan", show_alert: true })
    return
  }

  // simpan pending
  const pending = readJSON("./database/pending.json", {})
  pending[String(userId)] = {
    product,
    chatId: q.message.chat.id,
    created_at: Date.now(),
    status: "WAITING_PAYMENT"
  }
  writeJSON("./database/pending.json", pending)

  await bot.sendPhoto(q.message.chat.id, qris, {
    caption:
`${bq}🧾 <b>Transaksi QRIS Manual</b>

📦 <code>${product.name}</code>
💰 <code>${rupiah(product.price)}</code>

<i>Silahkan scan QRIS sesuai nominal diatas dan kirim foto bukti transfer.</i>
${ebq}`,
    parse_mode: "HTML"
  })

  return bot.answerCallbackQuery(q.id, { text: "✅ QRIS dikirim. Kirim bukti pembayaran." })
}

  if (data.startsWith("approve_")) {
    if (userId !== ownerId) return

    const targetId = data.replace("approve_", "")
    const pending = readJSON("./database/pending.json", {})

    if (!pending[targetId]) {
      return bot.answerCallbackQuery(q.id, {
        text: "❌ Data tidak ditemukan",
        show_alert: true
      })
    }

    const { product, chatId } = pending[targetId]

    await bot.sendDocument(
      chatId,
      product.file,
      {
        caption: `${bq}📦 <b>${product.name}</b>${ebq}`,
        parse_mode: "HTML"
      }
    )

    delete pending[targetId]
    writeJSON("./database/pending.json", pending)

    return bot.answerCallbackQuery(q.id, {
      text: "✅ Script berhasil dikirim"
    })
  }
    
  if (data.startsWith("reject_")) {
  if (userId !== ownerId) return

  const targetId = String(data.replace("reject_", ""))
  const pending = readJSON("./database/pending.json", {})

  if (!pending[targetId]) {
    return bot.answerCallbackQuery(q.id, {
      text: "❌ Data tidak ditemukan",
      show_alert: true
    })
  }

  const { product, chatId } = pending[targetId]

  pending[targetId].status = "REJECTED"
  pending[targetId].rejected_at = Date.now()
  writeJSON("./database/pending.json", pending)

  // notif ke user
  await bot.sendMessage(
    chatId,
`${bq}❌ <b>Konfirmasi Pembayaran ditolak!</b>

<i>Silahkan kirim ulang foto bukti pembayaran yang valid untuk disetujui.</i>${ebq}`,
    { parse_mode: "HTML" }
  )

  return bot.answerCallbackQuery(q.id, { text: "✅ Bukti ditolak" })
}

  await bot.answerCallbackQuery(q.id)
})

bot.on("photo", async (msg) => {
  const userId = msg.from.id
  const key = String(userId)
  const pending = readJSON("./database/pending.json", {})

  if (!pending[key]) return

  const { product } = pending[key]

  await bot.sendPhoto(
    ownerId,
    msg.photo[msg.photo.length - 1].file_id,
    {
      caption:
`🧾 <b>Konfirmasi Pembayaran</b>
@${settings.dev}

${bq}User ID: <code>${userId}</code>
Script: <b>${product.name}</b>
Username: <b>@${msg.from.username}</b>
${ebq}`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Setujui", callback_data: `approve_${userId}` },
            { text: "Tolak", callback_data: `reject_${userId}` }
          ]
        ]
      }
    }
  )

  await bot.sendMessage(userId, `✅ <i>Bukti transfer diterima! Silahkan menunggu verifikasi owner.</i>`, { parse_mode: "HTML"})
})

bot.onText(/^\/setting(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const input = match[1] ? match[1].trim() : "";

  if (senderId !== ownerId) {
    return bot.sendMessage(chatId, `❌ @${settings.dev} Only!`);
  }

  if (!fs.existsSync(settingFile)) {
    return bot.sendMessage(chatId, "❌ File tidak ditemukan");
  }

  let fileContent = fs.readFileSync(settingFile, "utf8");
  const config = require(settingFile);
  const allowedKeys = Object.keys(config);

  if (!input) {
    const keyboard = [];
    for (let i = 0; i < allowedKeys.length; i += 3) {
      keyboard.push(
        allowedKeys.slice(i, i + 3).map(k => ({
          text: k,
          callback_data: `set_${k}`
        }))
      );
    }

    return bot.sendMessage(
      chatId,
      "🔧 Setting isi file ./settings/config.js:",
      {
        reply_to_message_id: msg.message_id,
        reply_markup: { inline_keyboard: keyboard }
      }
    );
  }

  const updates = input.split(",").map(s => s.trim());
  let updatedKeys = [];
  let errors = [];

  for (const pair of updates) {
    const [key, ...valParts] = pair.split(" ");
    const value = valParts.join(" ").trim();
    
    if (!allowedKeys.includes(key)) {
      errors.push(`"${key}" tidak valid`);
      continue;
    }

    const regex = new RegExp(`(${key}\\s*:\\s*['"\`]).*?(['"\`])`, "g");
    
    if (!regex.test(fileContent)) {
      const newLine = `  ${key}: '${value}',`;
      fileContent = fileContent.replace(
        /module\.exports = \{/,
        `module.exports = {\n${newLine}`
      );
      updatedKeys.push(`${key} → ${value} (ditambahkan)`);
    } else {
      fileContent = fileContent.replace(regex, `$1${value}$2`);
      updatedKeys.push(`${key} → ${value}`);
    }
  }

  if (updatedKeys.length === 0 && errors.length === 0) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada perubahan.");
  }

  fs.writeFileSync(settingFile, fileContent, "utf8");

  delete require.cache[require.resolve(settingFile)];

  const resultText = [];

  if (updatedKeys.length > 0) {
    resultText.push(`✅ ./settings/config.js updated:`);
    resultText.push(`<pre>${updatedKeys.join("\n")}</pre>`);
  }

  if (errors.length > 0) {
    resultText.push(`\n❌ Errors:`);
    resultText.push(`<pre>${errors.join("\n")}</pre>`);
  }

  return bot.sendMessage(
    chatId,
    resultText.join("\n"),
    { parse_mode: "HTML" }
  );
});

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const senderId = query.from.id;
  const data = query.data;

  if (data === "refresh_setting") {
    if (senderId !== ownerId) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Owner only!", show_alert: true });
    }

    delete require.cache[require.resolve(settingFile)];
    
    await bot.answerCallbackQuery(query.id, { text: "✅ Config reloaded" });
    
    const config = require(settingFile);
    const allowedKeys = Object.keys(config);
    
    const keyboard = [];
    for (let i = 0; i < allowedKeys.length; i += 3) {
      keyboard.push(
        allowedKeys.slice(i, i + 3).map(k => ({
          text: k,
          callback_data: `set_${k}`
        }))
      );
    }

    keyboard.push([
      { text: "🔄 Refresh", callback_data: "refresh_setting" },
      { text: "📊 View All", callback_data: "view_all_settings" }
    ]);

    await bot.editMessageReplyMarkup(
      { inline_keyboard: keyboard },
      {
        chat_id: chatId,
        message_id: query.message.message_id
      }
    );
    return;
  }

  if (data === "view_all_settings") {
    if (senderId !== ownerId) {
      return bot.answerCallbackQuery(query.id, { text: "❌ Owner only!", show_alert: true });
    }

    delete require.cache[require.resolve(settingFile)];
    const config = require(settingFile);

    let settingsText = "📋 **ALL SETTINGS**\n\n";
    for (const [key, value] of Object.entries(config)) {
      const valStr = String(value);
      const displayVal = valStr.length > 50 ? valStr.substring(0, 47) + "..." : valStr;
      settingsText += `• <b>${key}:</b> <code>${displayVal}</code>\n`;
    }

    await bot.answerCallbackQuery(query.id);
    
    return bot.sendMessage(
      chatId,
      settingsText,
      { parse_mode: "HTML" }
    );
  }

  if (!data.startsWith("set_")) return;
  if (senderId !== ownerId) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Khusus owner!" });
  }

  const key = data.replace("set_", "");
  
  delete require.cache[require.resolve(settingFile)];
  const config = require(settingFile);
  const allowedKeys = Object.keys(config);

  if (!allowedKeys.includes(key)) {
    return bot.answerCallbackQuery(query.id, { text: "❌ Key tidak valid" });
  }

  const currentValue = config[key];
  
  await bot.answerCallbackQuery(query.id);

  const sent = await bot.sendMessage(
    chatId,
    `🔧 <b>Update Setting: ${key}</b>\n\n` +
    `Current Value: <code>${currentValue}</code>`,
    { 
      parse_mode: "HTML", 
      reply_to_message_id: query.message.message_id 
    }
  );

  const responseHandler = async (msg2) => {
    if (msg2.from.id !== ownerId) return;

    if (msg2.text === "/cancel") {
      await bot.sendMessage(chatId, "❌ Update dibatalkan.", {
        reply_to_message_id: sent.message_id
      });
      bot.removeListener("message", responseHandler);
      return;
    }

    const value = msg2.text.trim();

    if (!fs.existsSync(settingFile)) {
      await bot.sendMessage(chatId, "❌ File tidak ditemukan");
      bot.removeListener("message", responseHandler);
      return;
    }

    let fileContent = fs.readFileSync(settingFile, "utf8");
    
    const backupFile = settingFile + ".backup_" + Date.now();
    fs.copyFileSync(settingFile, backupFile);

    const regex = new RegExp(`(${key}\\s*:\\s*['"\`]).*?(['"\`])`, "g");
    
    if (!regex.test(fileContent)) {
      const newLine = `  ${key}: '${value}',`;
      fileContent = fileContent.replace(
        /module\.exports = \{/,
        `module.exports = {\n${newLine}`
      );
    } else {
      fileContent = fileContent.replace(regex, `$1${value}$2`);
    }

    fs.writeFileSync(settingFile, fileContent, "utf8");

    delete require.cache[require.resolve(settingFile)];

    await bot.sendMessage(
      chatId,
      `✅ <b>${key}</b> berhasil diupdate!\n\n` +
      `Menjadi: <code>${value}</code>`,
      { 
        parse_mode: "HTML", 
        reply_to_message_id: sent.message_id 
      }
    );

    bot.removeListener("message", responseHandler);
  };

  bot.once("message", responseHandler);
});

bot.onText(/^\/(bc|broadcast)(?:\s+([\s\S]+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const senderId = msg.from.id
  
  if (senderId !== ownerId) {
    return bot.sendMessage(chatId, `❌ @${settings.dev} Only!`);
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '❌ Reply pesan')
  }

  const users = getUsers()
  let success = 0
  let failed = 0

  for (const uid of users) {
    try {
      await bot.forwardMessage(
        uid,
        msg.reply_to_message.chat.id,
        msg.reply_to_message.message_id
      )

      success++
    } catch (err) {
      failed++
    }
  }

  bot.sendMessage(
    chatId,
`✅ Sukses: ${success}
Gagal: ${failed}`
  )
})

bot.onText(/^\/(add|del)(?:\s+(\w+))?(?:\s+(\d+))?$/i, (msg, m) => {
  const chatId = msg.chat.id;
  const action = (m[1] || "").toLowerCase();
  const roleInput = (m[2] || "").toLowerCase();
  let id = m[3];

  if (String(msg.from.id) !== String(ownerId) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "❌ Khusus *Owner.*",
    { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
  );
}

  if (!roleInput) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah.\nGunakan: /add <role> [id] atau reply + /add <role>",
      { reply_to_message_id: msg.message_id }
    );
  }

  if (!id && msg.reply_to_message?.from?.id) id = String(msg.reply_to_message.from.id);

  let targetUsername = "-";
  if (msg.reply_to_message?.from) {
    targetUsername = msg.reply_to_message.from.username
      ? `@${msg.reply_to_message.from.username}`
      : "(undefined)";
  }

  if (!id) return bot.sendMessage(chatId, "❌ User ID tidak ditemukan.", { reply_to_message_id: msg.message_id });

  id = String(id);

  const roles =
    roleInput === "pr"
      ? ["prem", "ress"]
      : roleInput === "all"
      ? ["owner", "prem", "ress"]
      : [roleInput];

  const normalizeRole = (r) => {
    if (r === "premium") return "prem";
    if (r === "reseller") return "ress";
    return r;
  };

  const uniqueRoles = Array.from(new Set(roles.map(normalizeRole)));

  const getData = (file) => {
    checkFile(file);
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"));
      return Array.isArray(data) ? data : [];
    } catch {
      return [];
    }
  };

  const setData = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2));

  let invalid = uniqueRoles.find((r) => {
    try {
      getFile(r);
      return false;
    } catch {
      return true;
    }
  });

  if (invalid) {
    return bot.sendMessage(
      chatId,
      `❌ Role tidak dikenali: ${invalid}`,
      { reply_to_message_id: msg.message_id }
    );
  }

  const added = [];
  const existed = [];
  const removed = [];
  const notFound = [];

  for (const r of uniqueRoles) {
    const file = getFile(r);
    const data = getData(file);

    if (action === "add") {
      if (data.includes(id)) {
        existed.push(r);
      } else {
        data.push(id);
        setData(file, data);
        added.push(r);
      }
    } else {
      if (!data.includes(id)) {
        notFound.push(r);
      } else {
        const next = data.filter((x) => String(x) !== id);
        setData(file, next);
        removed.push(r);
      }
    }
  }

  if (action === "add" && added.length === 0) {
    return bot.sendMessage(
      chatId,
      `⚠️ User dengan ID ${id} sudah terdaftar sebagai *${existed.join(", ")}*.`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  if (action === "del" && removed.length === 0) {
    return bot.sendMessage(
      chatId,
      `⚠️ User ID \`${id}\` tidak ditemukan di database *${notFound.join(", ")}*.`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  if (action === "add") {
    const typeLine = [
      added.length ? `Type: <b>${added.join(", ")}</b>` : "",
      existed.length ? `Already: <b>${existed.join(", ")}</b>` : ""
    ].filter(Boolean).join("\n");

    return bot.sendMessage(
      chatId,
      `✅ Sukses Menambahkan!
${bq}Username: <b>${targetUsername}</b>
${typeLine}
User ID: <code>${id}</code>${ebq}
`,
      { reply_to_message_id: msg.message_id, parse_mode: "HTML" }
    );
  }

  const typeLine = [
    removed.length ? `Removed: <b>${removed.join(", ")}</b>` : "",
    notFound.length ? `Not Found: <b>${notFound.join(", ")}</b>` : ""
  ].filter(Boolean).join("\n");

  return bot.sendMessage(
    chatId,
    `🗑️ Sukses Menghapus!
${bq}Username: <b>${targetUsername}</b>
${typeLine}
User ID: <code>${id}</code>${ebq}`,
    { reply_to_message_id: msg.message_id, parse_mode: "HTML" }
  );
});

bot.onText(/^\/addpublic(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const targetIdRaw = (match && match[1]) ? String(match[1]).trim() : ""

  if (String(msg.from.id) !== String(ownerId) && !isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Khusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    )
  }

  let targetId = ""

  if (msg.reply_to_message && msg.reply_to_message.from && msg.reply_to_message.from.id) {
    targetId = String(msg.reply_to_message.from.id)
  } else {
    if (!targetIdRaw || !/^\d+$/.test(targetIdRaw)) {
      return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/addpublic 123456789\nAtau reply user lalu ketik: /addpublic", {
        reply_to_message_id: msg.message_id
      })
    }
    targetId = String(targetIdRaw)
  }

  const targetUser = await bot.getChat(targetId).catch(() => null)
  if (!targetUser) {
    return bot.sendMessage(chatId, "❌ User tidak ditemukan atau bot belum pernah chat dengan user tersebut.", {
      reply_to_message_id: msg.message_id
    })
  }

  const getData = (file) => {
    checkFile(file)
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"))
      return Array.isArray(data) ? data.map(String) : []
    } catch {
      return []
    }
  }

  const ownerFile = getFile("owner")
  const tkFile = getFile("tk")
  const partnerFile = getFile("partner")
  const premFile = getFile("prem")
  const ressFile = getFile("ress")

  const ownerData = getData(ownerFile)
  const tkData = getData(tkFile)
  const partnerData = getData(partnerFile)
  const premData = getData(premFile)
  const ressData = getData(ressFile)

  const ownerMark = ownerData.includes(targetId) ? "✅" : "❌"
  const tkMark = tkData.includes(targetId) ? "✅" : "❌"
  const partnerMark = partnerData.includes(targetId) ? "✅" : "❌"
  const premMark = premData.includes(targetId) ? "✅" : "❌"
  const ressMark = ressData.includes(targetId) ? "✅" : "❌"

  const username = targetUser.username ? `@${targetUser.username}` : "-"
  const name = `${targetUser.first_name || "-"} ${targetUser.last_name || ""}`.trim()

  const textMsg =
    `Username: ${username || name || "-"}\n` +
    `ID: \`${targetId}\`\n` +
    `Type: User Public`

  return bot.sendMessage(chatId, textMsg, {
    parse_mode: "Markdown",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          { text: `${tkMark} Tangan Kanan`, callback_data: `pub_set_tk:${targetId}` },
          { text: `${partnerMark} Partner`, callback_data: `pub_set_pt:${targetId}` }
        ],
        [{ text: `${ownerMark} Owner`, callback_data: `pub_set_owner:${targetId}` }],
        [
          { text: `${premMark} Premium`, callback_data: `pub_set_prem:${targetId}` },
          { text: `${ressMark} Reseller`, callback_data: `pub_set_ress:${targetId}` }
        ]
      ]
    }
  })
})

bot.on("callback_query", async (q) => {
  const data = q.data || ""
  if (!data.startsWith("pub_set_")) return

  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (String(q.from.id) !== String(ownerId) && !isOwner(q.from.id)) {
    return
  }

  const parts = data.split(":")
  const action = parts[0]
  const targetId = String(parts[1] || "").trim()
  if (!/^\d+$/.test(targetId)) return bot.answerCallbackQuery(q.id)

  const getData = (file) => {
    checkFile(file)
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"))
      return Array.isArray(data) ? data.map(String) : []
    } catch {
      return []
    }
  }

  const setData = (file, arr) => fs.writeFileSync(file, JSON.stringify(arr, null, 2))

  let role = null
  let roleLabel = null

  if (action === "pub_set_owner") { role = "owner"; roleLabel = "Owner" }
  if (action === "pub_set_prem") { role = "prem"; roleLabel = "Premium" }
  if (action === "pub_set_ress") { role = "ress"; roleLabel = "Reseller" }
  if (action === "pub_set_tk") { role = "tk"; roleLabel = "Tangan Kanan" }
  if (action === "pub_set_pt") { role = "partner"; roleLabel = "Partner" }

  if (!role) return bot.answerCallbackQuery(q.id)

  const file = getFile(role)
  const arrNow = getData(file)

  const isInDb = arrNow.includes(targetId)
  let next = arrNow

  if (isInDb) {
    next = arrNow.filter((x) => String(x) !== targetId)
  } else {
    next = Array.from(new Set(arrNow.concat([targetId]).map(String)))
  }

  setData(file, next)

  const ownerData = getData(getFile("owner"))
  const tkData = getData(getFile("tk"))
  const partnerData = getData(getFile("partner"))
  const premData = getData(getFile("prem"))
  const ressData = getData(getFile("ress"))

  const ownerMark = ownerData.includes(targetId) ? "✅" : "❌"
  const tkMark = tkData.includes(targetId) ? "✅" : "❌"
  const partnerMark = partnerData.includes(targetId) ? "✅" : "❌"
  const premMark = premData.includes(targetId) ? "✅" : "❌"
  const ressMark = ressData.includes(targetId) ? "✅" : "❌"

  const keyboard = [
    [
      { text: `${tkMark} Tangan Kanan`, callback_data: `pub_set_tk:${targetId}` },
      { text: `${partnerMark} Partner`, callback_data: `pub_set_pt:${targetId}` }
    ],
    [{ text: `${ownerMark} Owner`, callback_data: `pub_set_owner:${targetId}` }],
    [
      { text: `${premMark} Premium`, callback_data: `pub_set_prem:${targetId}` },
      { text: `${ressMark} Reseller`, callback_data: `pub_set_ress:${targetId}` }
    ]
  ]

  await bot.editMessageReplyMarkup(
    { inline_keyboard: keyboard },
    { chat_id: chatId, message_id: messageId }
  ).catch(() => {})

  return bot.answerCallbackQuery(q.id, { text: isInDb ? `❌ ${roleLabel} dihapus` : `✅ ${roleLabel} ditambahkan` })
})


bot.onText(/^\/clear(?:\s+(\w+))?$/i, (msg, m) => {
  const chatId = msg.chat.id
  const roleInput = (m[1] || "").toLowerCase()

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    )
  }

  if (!roleInput) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah.\nGunakan: /clear <role>\nContoh: /clear prem | /clear ress | /clear owner | /clear all | /clear pr",
      { reply_to_message_id: msg.message_id }
    )
  }

  const roles =
    roleInput === "pr"
      ? ["prem", "ress"]
      : roleInput === "all"
      ? ["owner", "prem", "ress"]
      : [roleInput]

  const normalizeRole = (r) => {
    if (r === "premium") return "prem"
    if (r === "reseller") return "ress"
    return r
  }

  const uniqueRoles = Array.from(new Set(roles.map(normalizeRole)))

  const getData = (file) => {
    checkFile(file)
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"))
      return Array.isArray(data) ? data : []
    } catch {
      return []
    }
  }

  const setData = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2))

  let invalid = uniqueRoles.find((r) => {
    try {
      getFile(r)
      return false
    } catch {
      return true
    }
  })

  if (invalid) {
    return bot.sendMessage(
      chatId,
      `❌ Role tidak dikenali: ${invalid}`,
      { reply_to_message_id: msg.message_id }
    )
  }

  let roleBackup = {}
  try {
    if (fs.existsSync(roleFile)) {
      const raw = fs.readFileSync(roleFile, "utf8")
      const obj = JSON.parse(raw)
      roleBackup = obj && typeof obj === "object" ? obj : {}
    }
  } catch {
    roleBackup = {}
  }

  const cleared = []
  const alreadyEmpty = []

  for (const r of uniqueRoles) {
    const file = getFile(r)
    const data = getData(file)

    if (!data.length) {
      alreadyEmpty.push(r)
    } else {
      roleBackup[r] = Array.isArray(data) ? data : []
      setData(file, [])
      cleared.push({ role: r, total: data.length })
    }
  }

  try {
    const dir = path.dirname(roleFile)
    if (dir && dir !== "." && !fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
    fs.writeFileSync(roleFile, JSON.stringify(roleBackup, null, 2))
  } catch {}

  const lines = []
  if (cleared.length) {
    lines.push(`<b>Cleared</b>`)
    cleared.forEach((x) => lines.push(`• ${x.role}: <b>${x.total}</b> ID`))
  }
  if (alreadyEmpty.length) {
    lines.push(`\n<b>Already Empty</b>`)
    alreadyEmpty.forEach((r) => lines.push(`• ${r}`))
  }
  if (cleared.length) lines.push(`\n<i>✅ Save Backup: ${roleFile}</i>`)

  return bot.sendMessage(
    chatId,
    `🧹 <b>Clear Role Database</b>\n${bq}${lines.join("\n")}${ebq}`,
    { reply_to_message_id: msg.message_id, parse_mode: "HTML" }
  )
})

bot.onText(/^\/restore(?:\s+(\w+))?$/i, (msg, m) => {
  const chatId = msg.chat.id
  const roleInput = (m[1] || "").toLowerCase()

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    )
  }

  if (!roleInput) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah.\nGunakan: /restore <role>\nContoh: /restore prem | /restore ress | /restore owner | /restore all | /restore pr",
      { reply_to_message_id: msg.message_id }
    )
  }

  const roles =
    roleInput === "pr"
      ? ["prem", "ress"]
      : roleInput === "all"
      ? ["owner", "prem", "ress"]
      : [roleInput]

  const normalizeRole = (r) => {
    if (r === "premium") return "prem"
    if (r === "reseller") return "ress"
    return r
  }

  const uniqueRoles = Array.from(new Set(roles.map(normalizeRole)))

  let invalid = uniqueRoles.find((r) => {
    try {
      getFile(r)
      return false
    } catch {
      return true
    }
  })

  if (invalid) {
    return bot.sendMessage(
      chatId,
      `❌ Role tidak dikenali: ${invalid}`,
      { reply_to_message_id: msg.message_id }
    )
  }

  let roleBackup = null
  try {
    if (!fs.existsSync(roleFile)) {
      return bot.sendMessage(
        chatId,
        `⚠️ Backup tidak ditemukan.\nFile: ${roleFile}`,
        { reply_to_message_id: msg.message_id }
      )
    }
    const raw = fs.readFileSync(roleFile, "utf8")
    roleBackup = JSON.parse(raw)
  } catch {
    roleBackup = null
  }

  if (!roleBackup || typeof roleBackup !== "object") {
    return bot.sendMessage(
      chatId,
      `⚠️ Backup rusak / tidak valid.\nFile: ${roleFile}`,
      { reply_to_message_id: msg.message_id }
    )
  }

  const getData = (file) => {
    checkFile(file)
    try {
      const data = JSON.parse(fs.readFileSync(file, "utf8"))
      return Array.isArray(data) ? data : []
    } catch {
      return []
    }
  }

  const setData = (file, data) => fs.writeFileSync(file, JSON.stringify(data, null, 2))

  const restored = []
  const noBackup = []
  const alreadySame = []

  for (const r of uniqueRoles) {
    const file = getFile(r)
    const cur = getData(file)
    const bak = Array.isArray(roleBackup[r]) ? roleBackup[r] : null

    if (!bak) {
      noBackup.push(r)
      continue
    }

    const curNorm = cur.map(String).sort()
    const bakNorm = bak.map(String).sort()
    const same = curNorm.length === bakNorm.length && curNorm.every((v, i) => v === bakNorm[i])

    if (same) {
      alreadySame.push(r)
      continue
    }

    setData(file, bak)
    restored.push({ role: r, total: bak.length })
  }

  const lines = []
  if (restored.length) {
    lines.push(`<b>Restored</b>`)
    restored.forEach((x) => lines.push(`• ${x.role}: <b>${x.total}</b> ID`))
  }
  if (alreadySame.length) {
    lines.push(`\n<b>Already Same</b>`)
    alreadySame.forEach((r) => lines.push(`• ${r}`))
  }
  if (noBackup.length) {
    lines.push(`\n<b>No Backup</b>`)
    noBackup.forEach((r) => lines.push(`• ${r}`))
  }

  return bot.sendMessage(
    chatId,
    `♻️ <b>Restore Role Database</b>\n${bq}${lines.join("\n")}${ebq}`,
    { reply_to_message_id: msg.message_id, parse_mode: "HTML" }
  )
})

bot.onText(/^\/info$/, async (msg) => {
  const chatId = msg.chat.id;

  const targetUser = msg.reply_to_message?.from || msg.from;

  const userId = String(targetUser.id);
  const usernameRaw = targetUser.username || null;
  const firstName = targetUser.first_name || "User";

  const own = isOwner(userId);
  const prem = isPremium(userId);
  const ress = isReseller(userId);

  let statusStart = `❌ ${firstName} belum start bot di private chat. dilarang create!`;

  try {
    await bot.sendMessage(userId, "Start untuk cek bot!");
    statusStart = `✅ ${firstName} sudah start bot! silahkan create.`;

    let users = [];
    const allUsersFile = path.resolve("./database/users.json");

    if (fs.existsSync(allUsersFile)) users = JSON.parse(fs.readFileSync(allUsersFile, "utf8"));
    if (!Array.isArray(users)) users = [];
    if (!users.includes(userId)) {
      users.push(userId);
      fs.writeFileSync(allUsersFile, JSON.stringify(users, null, 2));
    }
  } catch (err) {
  }

  const usernameLine = usernameRaw ? `@${usernameRaw}` : "-";

  const txtInfo = `
ID: <code>${userId}</code>
Username: ${usernameLine}
Nama: ${firstName}
<blockquote>
- Owner: ${own ? "✅" : "❌"}
- Premium: ${prem ? "✅" : "❌"}
- Reseller: ${ress ? "✅" : "❌"}
</blockquote>
${statusStart}
`;

  return bot.sendMessage(chatId, txtInfo, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id
  });
});

bot.onText(/^\/list(?:\s+(\w+))?$/i, (msg, m) => {
  const chatId = msg.chat.id;
  const role = (m[1] || "").toLowerCase();

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }
    
  if (!role)
    return bot.sendMessage(chatId, "❌ Format: /list <role>\nContoh: /list prem");

  const file = getFile(role);
  checkFile(file);

  let data;
  try {
    data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!Array.isArray(data)) data = [];
  } catch {
    data = [];
  }

  if (data.length === 0) {
    return bot.sendMessage(
      chatId,
      `📭 List *${role}* kosong.`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  const maxShow = 50;
  const shown = data.slice(0, maxShow);

  const text =
`📋 <b>Daftar ${role.charAt(0).toUpperCase() + role.slice(1)}</b>
${bq}Total: <b>${data.length} User</b>${ebq}

${shown.map((id, i) => `${i + 1}. ${String(id)}`).join("\n")}
${data.length > maxShow ? `\n\n…dan ${data.length - maxShow} lainnya.` : ""}`

  return bot.sendMessage(chatId, text, { reply_to_message_id: msg.message_id, parse_mode: "HTML" });
});

bot.onText(/^\/(listdb|userdb)$/i, (msg) => {
  const chatId = msg.chat.id;
    
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  if (!fs.existsSync(usersFile)) {
    return bot.sendMessage(chatId, "📂 Folder users belum ada.");
  }

  const files = fs.readdirSync(usersFile)
    .filter(f => f.endsWith(".json"));

  if (files.length === 0) {
    return bot.sendMessage(chatId, "📭 Belum ada role yang tersimpan.");
  }

  const roles = files.map(f => {
    const name = f.replace(".json", "");
    return name.charAt(0).toUpperCase() + name.slice(1);
  });

  const text =
`📂 <b>Daftar User DB</b>

${roles.map((r, i) => `${i + 1}. ${r}`).join(".json\n")}
`;

  bot.sendMessage(chatId, text, { reply_to_message_id: msg.message_id, parse_mode: "HTML" });
});

bot.onText(/^\/deldb(?:\s+(\w+))?$/i, (msg, m) => {
  const chatId = msg.chat.id;
  const role = (m[1] || "").toLowerCase();
    
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  if (!role) {
    return bot.sendMessage(chatId, "❌ Format: /deldb <role>");
  }

  const file = path.join(usersFile, `${role}.json`);

  if (!fs.existsSync(file)) {
    return bot.sendMessage(
      chatId,
      `⚠️ *${role}.json* tidak ditemukan.`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  try {
    fs.unlinkSync(file);
    return bot.sendMessage(
      chatId,
      `🗑️ *${role}.json* berhasil dihapus.`,
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  } catch (err) {
    return bot.sendMessage(
      chatId,
      "❌ Gagal menghapus role. Cek permission server."
    );
  }
});

function saveSubdomainFile(data) {
  const content = "module.exports = " + JSON.stringify(data, null, 2) + ";\n"
  fs.writeFileSync(subdoFile, content, "utf8")
}

bot.onText(/^\/addsubdo(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      msg.chat.id,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    )
  }
  
  if (!global.subdomain || typeof global.subdomain !== "object") global.subdomain = {}

  const domainArg = (match[1] || "").trim().toLowerCase()

  addSubdoSession.set(chatId, { step: "domain", domain: "" })

  if (domainArg) {
    addSubdoSession.set(chatId, { step: "zone", domain: domainArg })
    return bot.sendMessage(
      chatId,
      `🌐 Domain: *${domainArg}*\nKirim *Zone ID* Cloudflare:`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    )
  }

  return bot.sendMessage(
    chatId,
    "💬 Kirim *domain* yang mau ditambah.\nContoh: `guntur.my.id`\n\n/cancelsubdo untuk membatalkan.",
    { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
  )
})

bot.onText(/^\/listsubdo(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const page = parseInt(match[1]) || 1;
  
  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      chatId,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    );
  }

  loadSubdomain();

  if (!global.subdomain || Object.keys(global.subdomain).length === 0) {
    return bot.sendMessage(
      chatId,
      "📭 Tidak ada domain di database.",
      { reply_to_message_id: msg.message_id }
    );
  }

  const domains = Object.keys(global.subdomain);
  const totalDomains = domains.length;
  const itemsPerPage = 10;
  const totalPages = Math.ceil(totalDomains / itemsPerPage);
  
  if (page < 1 || page > totalPages) {
    return bot.sendMessage(
      chatId,
      `❌ Halaman tidak valid. Total: ${totalPages}`,
      { reply_to_message_id: msg.message_id }
    );
  }

  const startIndex = (page - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, totalDomains);
  const pageDomains = domains.slice(startIndex, endIndex);

  let messageText = `📋 <b>Subdomain yang tersedia:</b>\n`;
  messageText += `${bq}Total: ${totalDomains} domain${ebq}`;

  const inline_keyboard = [];

  for (let i = 0; i < pageDomains.length; i += 2) {
    const row = [];
    
    const domain1 = pageDomains[i];
    const num1 = startIndex + i + 1;
    row.push({ 
      text: `${num1}. ${domain1}`, 
      callback_data: `subdo_select_${domain1}` 
    });
    
    if (i + 1 < pageDomains.length) {
      const domain2 = pageDomains[i + 1];
      const num2 = startIndex + i + 2;
      row.push({ 
        text: `${num2}. ${domain2}`, 
        callback_data: `subdo_select_${domain2}` 
      });
    }
    
    inline_keyboard.push(row);
  }

  inline_keyboard.push([]);

  const navRow = [];
  if (page > 1) {
    navRow.push({ text: "◀️", callback_data: `subdo_page_${page - 1}` });
  }
  navRow.push({ text: `${page}/${totalPages}`, callback_data: "subdo_page_info" });
  if (page < totalPages) {
    navRow.push({ text: "▶️", callback_data: `subdo_page_${page + 1}` });
  }
  inline_keyboard.push(navRow);

  return bot.sendMessage(
    chatId,
    messageText,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard }
    }
  );
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

  if (userId !== ownerId) {
    try {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "❌ Owner Only!",
        show_alert: true
      });
    } catch (_) {}
    return;
  }

  // Handle pilih domain untuk hapus
  if (data.startsWith("subdo_select_")) {
    const domain = data.replace("subdo_select_", "");
    
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: `Memuat detail ${domain}`,
      show_alert: false
    });

    loadSubdomain();
    
    if (!global.subdomain[domain]) {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: `❌ Domain "${domain}" tidak ditemukan`,
        show_alert: true
      });
      return;
    }

    const config = global.subdomain[domain];
    
    // Tampilkan detail dengan tombol hapus
    const inline_keyboard = [
      [
        { text: "Hapus Domain", callback_data: `subdo_delete_${domain}` }
      ]
    ];

    await bot.editMessageText(
      `<b>${domain}</b>\n\n` +
      `${bq}Zone ID:${ebq}<code>${config.zone || "Tidak ada"}</code>\n` +
      `${bq}API Token:${ebq} <code>${config.apitoken ? "••••••" + config.apitoken.slice(-8) : "Tidak ada"}</code>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard }
      }
    );
    return;
  }

  // Handle navigasi halaman
  if (data.startsWith("subdo_page_")) {
    if (data === "subdo_page_info") {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: "Halaman saat ini",
        show_alert: false
      });
      return;
    }

    const page = parseInt(data.replace("subdo_page_", ""));
    
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: `Memuat halaman ${page}...`,
      show_alert: false
    });

    loadSubdomain();

    if (!global.subdomain || Object.keys(global.subdomain).length === 0) {
      await bot.editMessageText(
        "📭 Tidak ada domain di database.",
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );
      return;
    }

    const domains = Object.keys(global.subdomain);
    const totalDomains = domains.length;
    const itemsPerPage = 10;
    const totalPages = Math.ceil(totalDomains / itemsPerPage);
    
    if (page < 1 || page > totalPages) {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: `❌ Halaman tidak valid`,
        show_alert: true
      });
      return;
    }

    const startIndex = (page - 1) * itemsPerPage;
    const endIndex = Math.min(startIndex + itemsPerPage, totalDomains);
    const pageDomains = domains.slice(startIndex, endIndex);

    let messageText = `<b>📋 Subdomain yang tersedia:</b>\n`;
    messageText += `${bq}Total: ${totalDomains} domain${ebq}`;

    const inline_keyboard = [];

    for (let i = 0; i < pageDomains.length; i += 2) {
      const row = [];
      
      const domain1 = pageDomains[i];
      const num1 = startIndex + i + 1;
      row.push({ 
        text: `${num1}. ${domain1}`, 
        callback_data: `subdo_select_${domain1}` 
      });
      
      if (i + 1 < pageDomains.length) {
        const domain2 = pageDomains[i + 1];
        const num2 = startIndex + i + 2;
        row.push({ 
          text: `${num2}. ${domain2}`, 
          callback_data: `subdo_select_${domain2}` 
        });
      }
      
      inline_keyboard.push(row);
    }

    inline_keyboard.push([]);

    const navRow = [];
    if (page > 1) {
      navRow.push({ text: "◀️", callback_data: `subdo_page_${page - 1}` });
    }
    navRow.push({ text: `${page}/${totalPages}`, callback_data: "subdo_page_info" });
    if (page < totalPages) {
      navRow.push({ text: "▶️", callback_data: `subdo_page_${page + 1}` });
    }
    inline_keyboard.push(navRow);

    await bot.editMessageText(
      messageText,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard }
      }
    );
    return;
  }

  if (data.startsWith("subdo_delete_")) {
    const domainToDelete = data.replace("subdo_delete_", "");
    
    const confirmKeyboard = [
      [
        { text: "Hapus", callback_data: `subdo_confirm_delete_${domainToDelete}` },
        { text: "Batal", callback_data: `subdo_cancel_delete_${domainToDelete}` }
      ]
    ];

    await bot.editMessageText(
      `🗑️ <b>Konfirmasi Hapus</b>\n` +
      `${bq}Subdomain: <b>${domainToDelete}</b>${ebq}\n\n` +
      `<i>Selanjutnya akan dihapus dari database, Lanjut?</i>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: confirmKeyboard }
      }
    );

    await bot.answerCallbackQuery(callbackQuery.id, {
      text: `Konfirmasi hapus ${domainToDelete}`,
      show_alert: false
    });
    return;
  }

  // Handle konfirmasi hapus
  if (data.startsWith("subdo_confirm_delete_")) {
    const domainToDelete = data.replace("subdo_confirm_delete_", "");
    
    try {
      loadSubdomain();
      
      if (!global.subdomain[domainToDelete]) {
        await bot.answerCallbackQuery(callbackQuery.id, {
          text: `❌ Domain "${domainToDelete}" tidak ditemukan`,
          show_alert: true
        });
        return;
      }

      // Simpan data sebelum dihapus
      const deletedZone = global.subdomain[domainToDelete].zone || "Tidak ada";
      const deletedToken = global.subdomain[domainToDelete].apitoken || "Tidak ada";
      
      // Hapus dari object
      delete global.subdomain[domainToDelete];
      
      // Save to file
      saveSubdomainFile(global.subdomain);
      
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: `✅ Domain "${domainToDelete}" berhasil dihapus`,
        show_alert: true
      });

      // Tampilkan pesan sukses
      await bot.editMessageText(
        `✅ <b>Subdomain berhasil dihapus!</b>\n` +
        `<b>${domainToDelete}</b>\n\n` +
        `${bq}Zone ID:${ebq} <code>${deletedZone}</code>\n` +
        `${bq}API Token:${ebq} <code>${deletedToken.substring(0, 15)}...</code>`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );

      // Set timeout untuk kembali ke list
      setTimeout(async () => {
        try {
          await bot.deleteMessage(chatId, messageId);
          await bot.sendMessage(chatId, `/listsubdo`, {
            parse_mode: "HTML"
          });
        } catch (e) {}
      }, 3000);

    } catch (error) {
      await bot.answerCallbackQuery(callbackQuery.id, {
        text: `❌ Gagal menghapus: ${error.message}`,
        show_alert: true
      });
    }
    return;
  }

  // Handle batal hapus
  if (data.startsWith("subdo_cancel_delete_")) {
    const domainToCancel = data.replace("subdo_cancel_delete_", "");
    
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: `❌ Penghapusan dibatalkan`,
      show_alert: true
    });

    // Kembali ke detail domain
    loadSubdomain();
    
    if (!global.subdomain[domainToCancel]) {
      // Jika domain sudah tidak ada, kembali ke list
      await bot.deleteMessage(chatId, messageId);
      await bot.sendMessage(chatId, `Ketik ulang /listsubdo`, {
        parse_mode: "HTML"
      });
      return;
    }

    const config = global.subdomain[domainToCancel];
    
    // Tampilkan detail dengan tombol hapus
    const inline_keyboard = [
      [
        { text: "🗑️ Hapus Domain Ini", callback_data: `subdo_delete_${domainToCancel}` }
      ],
      [
        { text: "📋 Kembali ke List", callback_data: `subdo_back_list_${domainToCancel}` }
      ]
    ];

    await bot.editMessageText(
      `🔍 **Detail Domain**\n\n` +
      `🌐 Domain: <b>${domainToCancel}</b>\n` +
      `🆔 Zone ID: <code>${config.zone || "Tidak ada"}</code>\n` +
      `🔑 API Token: <code>${config.apitoken ? "••••••" + config.apitoken.slice(-8) : "Tidak ada"}</code>\n\n` +
      `Pilih aksi di bawah:`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard }
      }
    );
    return;
  }

  // Handle tombol kembali ke list
  if (data.startsWith("subdo_back_list_")) {
    const domain = data.replace("subdo_back_list_", "");
    
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "Kembali ke daftar",
      show_alert: false
    });

    await bot.deleteMessage(chatId, messageId);
    await bot.sendMessage(chatId, `/listsubdo`, {
      parse_mode: "HTML"
    });
    return;
  }
});

bot.onText(/^\/cancelsubdo$/i, async (msg) => {
  const chatId = msg.chat.id
  
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Akses ditolak!\nKhusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }
    
  addSubdoSession.delete(chatId)
  return bot.sendMessage(chatId, "❌ Proses dibatalkan.", {
    reply_to_message_id: msg.message_id
  })
})

bot.on("message", async (msg) => {
  const chatId = msg.chat.id
  const text = (msg.text || "").trim()
  if (!text) return

  const state = addSubdoSession.get(chatId)
  if (!state) return

  if (text.startsWith("/")) return

  if (state.step === "domain") {
    const domainInput = text.toLowerCase()
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/i.test(domainInput)) {
      return bot.sendMessage(chatId, "❌ Format domain tidak valid.\nContoh: `guntur.my.id`", {
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
      })
    }

    addSubdoSession.set(chatId, { step: "zone", domain: domainInput })
    return bot.sendMessage(chatId, `🌐 Domain: *${domainInput}*\nKirim *Zone ID* Cloudflare:`, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    })
  }

  if (state.step === "zone") {
    const zone = text.replace(/\s+/g, "")
    if (!/^[a-f0-9]{32}$/i.test(zone)) {
      return bot.sendMessage(chatId, "❌ Zone ID tidak valid.\nBiasanya 32 karakter hex.", {
        reply_to_message_id: msg.message_id
      })
    }

    addSubdoSession.set(chatId, { step: "token", domain: state.domain, zone })
    return bot.sendMessage(chatId, "🔑 *API Token* Cloudflare:", {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    })
  }

  if (state.step === "token") {
    const apitoken = text
    if (apitoken.length < 20) {
      return bot.sendMessage(chatId, "❌ API Token tidak valid.", {
        reply_to_message_id: msg.message_id
      })
    }

    const domainKey = state.domain
    global.subdomain[domainKey] = { zone: state.zone, apitoken }

    try {
      saveSubdomainFile(global.subdomain)
    } catch (e) {
      addSubdoSession.delete(chatId)
      return bot.sendMessage(chatId, `❌ Gagal simpan ke file subdomain.js\n${e.message}`, {
        reply_to_message_id: msg.message_id
      })
    }

    addSubdoSession.delete(chatId)

    return bot.sendMessage(
      chatId,
      `✅ <b>Sukses menambahkan Domain!</b>\n${domainKey}\n\n${bq}<b>Zone ID:</b> ${state.zone}${ebq}\n${bq}<b>ApiToken:</b> ${apitoken}${ebq}`,
      { parse_mode: "HTML", reply_to_message_id: msg.message_id }
    )
  }
})

function loadSubdomain() {
  try {
    delete require.cache[require.resolve(subdoFile)]
    global.subdomain = require(subdoFile)
    console.log(chalk.blue(">> Update Subdomain.js"));
  } catch (e) {
    console.error("[GAGAL] reload subdomain.js:", e.message)
  }
}

loadSubdomain()
fs.watch(subdoFile, (eventType) => {
  if (eventType === "change") {
    setTimeout(loadSubdomain, 100)
  }
})

function listSubdoKey(domains) {
  const inline_keyboard = []
  for (let i = 0; i < domains.length; i += 2) {
    inline_keyboard.push(
      domains.slice(i, i + 2).map((d, idx) => ({
        text: d,
        callback_data: `create_domain|${i + idx}`
      }))
    )
  }
  return inline_keyboard
}

bot.onText(/^\/subdo(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Khusus *Owner!*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    )
  }

  if (!global.subdomain || typeof global.subdomain !== "object") {
    return bot.sendMessage(chatId, "❌ Data subdomain belum di-load.", {
      reply_to_message_id: msg.message_id
    })
  }

  const text = match[1]
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /subdo reqname,ipvps", {
      reply_to_message_id: msg.message_id
    })
  }

  if (!text.includes(",")) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: `/subdo reqname,ipvps`", {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    })
  }

  const [hostRaw, ipRaw] = text.split(",").map(i => i.trim())
  const host = hostRaw.toLowerCase()
  const ip = ipRaw

  const domains = Object.keys(global.subdomain)
  if (domains.length === 0) {
    return bot.sendMessage(chatId, "❌ Tidak ada domain yang tersedia saat ini.", {
      reply_to_message_id: msg.message_id
    })
  }

  subdoSession.set(chatId, { host, ip, domains })

  return bot.sendMessage(
    chatId,
    `🌐 <b>Subdomain yang tersedia</b>\nbig thanks from @${settings.dev}\n${bq}ᴛᴏᴛᴀʟ ꜱᴜʙᴅᴏᴍᴀɪɴ: ${domains.length}${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: listSubdoKey(domains) }
    }
  )
})

bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message
  const chatId = msg.chat.id
  const messageId = msg.message_id
  const data = callbackQuery.data || ""
  const parts = data.split("|")
  const session = subdoSession.get(chatId)

  if (parts[0] !== "create_domain") return

  if (!session) {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Session habis, ketik ulang /subdo", show_alert: true }) } catch {}
    return
  }

  const domainIndex = Number(parts[1])
  const { host, ip, domains } = session

  if (!Number.isInteger(domainIndex) || domainIndex < 0 || domainIndex >= domains.length) {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Domain tidak ditemukan!", show_alert: true }) } catch {}
    return
  }

  const tldnya = domains[domainIndex]
  const cfg = global.subdomain[tldnya]

  if (!cfg?.zone || !cfg?.apitoken) {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Config domain tidak lengkap!", show_alert: true }) } catch {}
    return
  }

  try {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "⏳ Memproses...", show_alert: false }) } catch {}
    try { await bot.deleteMessage(chatId, messageId) } catch {}
  } catch {}

  const cleanHost = host.replace(/[^a-z0-9.-]/gi, "")
  const cleanIp = ip.replace(/[^0-9.]/gi, "")
  const fullName = `${cleanHost}.${tldnya}`

  try {
    const response = await axios.post(
      `https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records`,
      {
        type: "A",
        name: fullName,
        content: cleanIp,
        ttl: 1,
        proxied: false
      },
      {
        headers: {
          Authorization: `Bearer ${cfg.apitoken}`,
          "Content-Type": "application/json"
        }
      }
    )

    const res = response.data

    if (res?.success) {
      subdoSession.delete(chatId)

      const teks =
`✅ *Sukses membuat Subdomain!*\n\n🌐 *sᴜʙᴅᴏᴍᴀɪɴ:* \`${res.result?.name || fullName}\`\n📌 *ɪᴘ ᴠᴘs:* \`${res.result?.content || cleanIp}\`\n`

      await bot.sendMessage(chatId, teks, {
        parse_mode: "Markdown"
      })

      return
    }

    const err = res?.errors?.[0]?.message || "Gagal membuat subdomain"
    await bot.sendMessage(chatId, `❌ Gagal membuat subdomain:\n${err}`)
    return
  } catch (e) {
    const errorMsg = e.response?.data?.errors?.[0]?.message || e.message || "Terjadi kesalahan"
    await bot.sendMessage(chatId, `❌ Gagal membuat subdomain:\n${errorMsg}`)
    return
  }
})


function stateKey(msg) {
  return `${msg.chat.id}:${msg.from.id}`;
}

bot.onText(/^\/cekdomain$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  const menuMessage = `🌐 <b>Check Domain - Cloudflare</b>

${bq}ℹ <b>Domain Cek Manual</b>${ebq}
• Cek domain spesifik
• Input Zone ID dan API Token
• Step-by-step handle state

${bq}<b>Choose the Button:</b>${ebq}`;

  const keyboard = [
    [
      { text: "🔎 Check Domain", callback_data: "cekdomain_manual" }
    ],
  ];

  return bot.sendMessage(
    chatId,
    menuMessage,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: keyboard }
    }
  );
});

bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const messageId = cb.message.message_id;
  const data = cb.data;
  const userId = cb.from.id;

  switch (data) {
    case "cekdomain_manual":
      await bot.answerCallbackQuery(cb.id, {
        text: "🔎 Mode manual: kirim nama domain",
        show_alert: false
      });

      cekDomainState.set(`${chatId}:${userId}`, { step: 1, data: {} });

      await bot.editMessageText(
        `🔎 <b>Cek Domain Manual (1/3)</b>\n\nKirim <b>Nama Domain</b>\n(contoh: guntur.my.id)`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "❌ Batalkan", callback_data: "cekdomain_cancel" }]
            ]
          }
        }
      ).catch(() => { });
      break;

    case "cekdomain_cancel":
      await bot.answerCallbackQuery(cb.id, {
        text: "❌ Dibatalkan",
        show_alert: true
      });
      cekDomainState.delete(`${chatId}:${userId}`);
      await bot.deleteMessage(chatId, messageId).catch(() => { });
      break;
  }

  if (data === "recheck_domains") {
    await bot.answerCallbackQuery(cb.id, {
      text: "🔄 Memulai refresh...",
      show_alert: false
    });

    await bot.deleteMessage(chatId, messageId).catch(() => { });
    setTimeout(() => {
      bot.sendMessage(chatId, `/cekdomain`).catch(() => { });
    }, 500);
    return;
  }

  if (data === "delete_error_domains") {
    await bot.answerCallbackQuery(cb.id, {
      text: "🗑️ Konfirmasi penghapusan...",
      show_alert: true
    });

    await bot.editMessageText(
      `🗑️ <b>KONFIRMASI HAPUS DOMAIN ERROR</b>\n\n` +
      `Anda akan menghapus semua domain dengan authentication error dari database.\n\n` +
      `<b>⚠️ PERINGATAN:</b>\n` +
      `• Domain yang dihapus tidak bisa dikembalikan\n` +
      `• Subdomain yang menggunakan domain ini akan error\n` +
      `• Pastikan backup data jika diperlukan\n\n` +
      `Apakah Anda yakin?`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Ya, Hapus Semua", callback_data: "confirm_delete_errors" },
              { text: "❌ Batal", callback_data: "cancel_delete_errors" }
            ]
          ]
        }
      }
    ).catch(() => { });
    return;
  }

  if (data === "confirm_delete_errors") {
    await bot.answerCallbackQuery(cb.id, {
      text: "⏳ Menghapus domain error...",
      show_alert: false
    }).catch(() => { });

    loadSubdomain();
    const domains = Object.keys(global.subdomain);
    let deletedCount = 0;
    let errorResults = [];

    const progressMsg = await bot.sendMessage(
      chatId,
      `🗑️ <b>MEMBERSIHKAN DATABASE DOMAIN</b>\n\n` +
      `🔍 Scanning ${domains.length} domain...\n` +
      `⏳ Mohon tunggu...`,
      {
        parse_mode: "HTML"
      }
    ).catch(() => null);

    for (const domain of domains) {
      const config = global.subdomain[domain];

      if (!config.zone || !config.apitoken) {
        delete global.subdomain[domain];
        deletedCount++;
        errorResults.push({ domain, reason: "Missing Zone/Token" });
        continue;
      }

      try {
        const response = await axios.get(
          `https://api.cloudflare.com/client/v4/zones/${config.zone}`,
          {
            headers: {
              Authorization: `Bearer ${config.apitoken}`,
              "Content-Type": "application/json"
            },
            timeout: 5000
          }
        );

        if (!response.data.success) {
          delete global.subdomain[domain];
          deletedCount++;
          const errorMsg = response.data.errors?.[0]?.message || "Auth failed";
          errorResults.push({ domain, reason: errorMsg });
        }
      } catch (error) {
        delete global.subdomain[domain];
        deletedCount++;
        const errorMsg =
          error.response?.data?.errors?.[0]?.message ||
          error.message ||
          "Unknown";
        errorResults.push({ domain, reason: errorMsg });
      }
    }

    saveSubdomainFile(global.subdomain);

    if (progressMsg) {
      await bot.deleteMessage(chatId, progressMsg.message_id).catch(() => { });
    }

    let resultMessage = `✅ <b>PEMBERSIHAN SELESAI</b>\n\n`;
    resultMessage += `📊 <b>STATISTIK:</b>\n`;
    resultMessage += `• Domain diperiksa: ${domains.length}\n`;
    resultMessage += `• Domain dihapus: ${deletedCount}\n`;
    resultMessage += `• Domain tersisa: ${Object.keys(global.subdomain).length}\n\n`;

    if (deletedCount > 0) {
      resultMessage += `🗑️ <b>DOMAIN YANG DIHAPUS:</b>\n`;
      errorResults.slice(0, 5).forEach((item, index) => {
        resultMessage += `${index + 1}. <code>${item.domain}</code>\n`;
        resultMessage += `   └─ ${item.reason}\n`;
      });

      if (errorResults.length > 5) {
        resultMessage += `\n...dan ${errorResults.length - 5} domain lainnya\n`;
      }

      resultMessage += `\n⚠️ <b>CATATAN:</b>\n`;
      resultMessage += `• Subdomain yang menggunakan domain ini perlu diupdate\n`;
      resultMessage += `• Gunakan /adddomain untuk menambahkan domain baru\n`;
    } else {
      resultMessage += `🎉 <b>Tidak ada domain yang dihapus!</b>\n`;
      resultMessage += `Semua domain valid.`;
    }

    await bot.editMessageText(
      resultMessage,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "🔄 Cek Ulang", callback_data: "recheck_domains" },
              { text: "📋 List Domain", callback_data: "list_domains" }
            ],
            [
              { text: "🏠 Menu Utama", callback_data: "cekdomain_back" }
            ]
          ]
        }
      }
    ).catch(() => { });
    return;
  }

  if (data === "cancel_delete_errors") {
    await bot.answerCallbackQuery(cb.id, {
      text: "❌ Penghapusan dibatalkan",
      show_alert: true
    }).catch(() => { });

    await bot.deleteMessage(chatId, messageId).catch(() => { });
    return;
  }
});

bot.on('message', async (msg) => {
  if (!msg.text || msg.text.startsWith('/')) return;

  const stateKey = `${msg.chat.id}:${msg.from.id}`;
  const state = cekDomainState.get(stateKey);

  if (!state) return;

  const chatId = msg.chat.id;

  try {
    switch (state.step) {
      case 1: // Domain name
        state.data.domain = msg.text.trim();
        state.step = 2;

        await bot.sendMessage(
          chatId,
          `🔎 <b>Cek Domain Manual (2/3)</b>\n\nKirim <b>Zone ID</b> Cloudflare\n(Format: 32 karakter hex)`,
          {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id,
            reply_markup: {
              inline_keyboard: [
                [{ text: "❌ Batalkan", callback_data: "cekdomain_cancel" }]
              ]
            }
          }
        );
        break;

      case 2: // Zone ID
        state.data.zoneId = msg.text.trim();
        state.step = 3;

        await bot.sendMessage(
          chatId,
          `🔎 <b>Cek Domain Manual (3/3)</b>\n\nKirim <b>API Token</b> Cloudflare\n(Permission: Zone:Read)`,
          {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id,
            reply_markup: {
              inline_keyboard: [
                [{ text: "❌ Batalkan", callback_data: "cekdomain_cancel" }]
              ]
            }
          }
        );
        break;

      case 3: // API Token
        state.data.apiToken = msg.text.trim();
        cekDomainState.delete(stateKey);

        // Perform the check
        const progressMsg = await bot.sendMessage(
          chatId,
          `🔍 <b>Memeriksa domain...</b>\n\n` +
          `Domain: <code>${state.data.domain}</code>\n` +
          `Zone ID: <code>${state.data.zoneId.substring(0, 8)}...</code>\n`,
          {
            parse_mode: "HTML",
            reply_to_message_id: msg.message_id
          }
        );

        try {
          const response = await axios.get(
            `https://api.cloudflare.com/client/v4/zones/${state.data.zoneId}`,
            {
              headers: {
                Authorization: `Bearer ${state.data.apiToken}`,
                "Content-Type": "application/json"
              },
              timeout: 10000
            }
          );

          if (response.data.success) {
            const zoneData = response.data.result;

            await bot.editMessageText(
              `✅ <b>Verifikasi Domain!</b>

${bq}<b>Statistik Domain:</b>${ebq}
• Domain: <code>${zoneData.name}</code>
• Status: ${zoneData.status}
• Type: ${zoneData.type} zone
• Development Mode: ${zoneData.development_mode ? 'On' : 'Off'}

${bq}<b>Name Servers:</b>${ebq}
<code>${zoneData.name_servers?.join(', ') || 'N/A'}</code>`,
              {
                chat_id: chatId,
                message_id: progressMsg.message_id,
                parse_mode: "HTML",
                reply_markup: {
                  inline_keyboard: [
                    [{ text: "🔄 Cek Domain", callback_data: "cekdomain_manual" }]
                  ]
                }
              }
            );
          } else {
            throw new Error(response.data.errors?.[0]?.message || "Authentication failed");
          }
        } catch (error) {
          const errorMsg = error.response?.data?.errors?.[0]?.message ||
            error.message ||
            "Unknown error";

          await bot.editMessageText(
            `❌ <b>Verifikasi Denied Domain!</b>\n\n` +
            `${bq}<b>ℹ️ Statistik Error:</b>${ebq}\n` +
            `• Domain: <code>${state.data.domain}</code>\n` +
            `• Error: ${errorMsg}\n\n` +
            `${bq}<b>🔧 Solusi Masalah:</b>${ebq}\n` +
            `1. Pastikan Zone ID sesuai dengan domain\n` +
            `2. API Token memiliki permission Zone:Read\n` +
            `3. Domain sudah terdaftar di Cloudflare\n` +
            `4. Cek API Token di dashboard Cloudflare`,
            {
              chat_id: chatId,
              message_id: progressMsg.message_id,
              parse_mode: "HTML",
              reply_markup: {
                inline_keyboard: [
                  [{ text: "🔄 Coba Lagi", callback_data: "cekdomain_manual" }]
                ]
              }
            }
          );
        }
        break;
    }
  } catch (error) {
    console.error("Error in manual domain check:", error);
    await bot.sendMessage(
      chatId,
      "❌ Terjadi error. Silakan coba lagi.",
      { reply_to_message_id: msg.message_id }
    );
    cekDomainState.delete(stateKey);
  }
});

bot.onText(/^\/cleardns$/, async (msg) => {
  const chatId = msg.chat.id;
  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      msg.chat.id,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    )
  }

  if (!global.subdomain || typeof global.subdomain !== "object") {
    return bot.sendMessage(chatId, "❌ Data subdomain belum di-load");
  }

  const dom = Object.keys(global.subdomain);
  if (dom.length === 0) return bot.sendMessage(chatId, "❌ Tidak ada domain");

  const inline_keyboard = [];
  for (let i = 0; i < dom.length; i += 2) {
    inline_keyboard.push(
      dom.slice(i, i + 2).map((d) => ({
        text: d,
        callback_data: `cleardns|${d}`
      }))
    );
  }

  return bot.sendMessage(chatId, "🧹 Silahkan pilih domain yang mau diclear DNS recordnya:", {
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  });
});

async function cfListRecords(zone, token) {
  const res = await axios.get(
    `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records?per_page=100`,
    { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
  );
  return res.data?.result || [];
}

async function cfDeleteRecord(zone, token, recordId) {
  await axios.delete(
    `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records/${recordId}`,
    { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
  );
}

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = String(callbackQuery.data || "");
  const parts = data.split("|");
    
  if (callbackQuery.data?.startsWith("cleardns") && callbackQuery.from.id !== ownerId) {
  try {
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "❌ Owner Only!",
      show_alert: true
    });
  } catch (_) {}
  return;
}

  if (parts[0] !== "cleardns") {
    try { await bot.answerCallbackQuery(callbackQuery.id); } catch (_) {}
    return;
  }

  const domain = parts[1];
  const cfg = global.subdomain?.[domain];

  if (!cfg?.zone || !cfg?.apitoken) {
    try { await bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Zone/Apitoken tidak valid", show_alert: true }); } catch (_) {}
    return;
  }

  try { await bot.answerCallbackQuery(callbackQuery.id, { text: "⏳ Memproses Clear DNS", show_alert: false }); } catch (_) {}

  let statusMsgId = null;
  const sent = await bot.sendMessage(chatId, `⏳ Memulai Clear DNS: ${domain}\n<pre>memuat record...</pre>`, {
    reply_to_message_id: messageId,
    parse_mode: "HTML"
  }).catch(() => null);
  statusMsgId = sent?.message_id || null;

  const edit = async (txt) => {
    if (!statusMsgId) return;
    await bot.editMessageText(txt, {
      chat_id: chatId,
      message_id: statusMsgId,
      parse_mode: "HTML",
      disable_web_page_preview: true
    }).catch(() => {});
  };

  try {
    const records = await cfListRecords(cfg.zone, cfg.apitoken);
    if (records.length === 0) {
      await edit(`ℹ️ Total DNS Record: ${domain}\n<pre>tidak ada record</pre>`);
      return;
    }

    await edit(`⏳ Memulai Clear DNS: ${domain}\n<pre>Total: ${records.length}</pre>`);

    let deleted = 0;
    for (const r of records) {
      await cfDeleteRecord(cfg.zone, cfg.apitoken, r.id);
      deleted++;
      if (deleted === 1 || deleted % 10 === 0 || deleted === records.length) {
        await edit(`⏳ Memproses Clear DNS:\n${domain}\n<pre>Total: ${records.length}\nHapus: ${deleted}</pre>`);
      }
    }

    await edit(`✅ Sukses Clear DNS:\n${domain}\n<pre>Total: ${records.length}</pre>`);
  } catch (e) {
    const err = e.response?.data?.errors?.[0]?.message || e.message || "error";
    await edit(`❌ Clear DNS: ${domain}\n<pre>${String(err).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}</pre>`);
  }
});

bot.onText(/^\/idgroup$/, async (msg) => {
    const chatId = msg.chat.id;
    await bot.sendMessage(chatId, `This Group ID is: \`${chatId}\``, {
        parse_mode: "Markdown",
        reply_to_message_id: msg.message_id
    });
});

bot.onText(/^\/cekid$/, async (msg) => {
    const chatId = msg.chat.id;
    const user = msg.from;

    try {
        const fullName = `${user.first_name || ''} ${user.last_name || ''}`.trim();
        const username = user.username ? `@${user.username}` : '-';
        const userId = user.id.toString();
        const today = new Date().toISOString().split('T')[0];
        const dcId = (user.id >> 32) % 256;

        let photoUrl = null;
        try {
            const photos = await bot.getUserProfilePhotos(user.id, { limit: 1 });
            if (photos.total_count > 0) {
                const fileId = photos.photos[0][0].file_id;
                const file = await bot.getFile(fileId);
                photoUrl = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`;
            }
        } catch (e) {
            console.log('Gagal ambil foto profil:', e.message);
        }

        const canvas = createCanvas(800, 450);
        const ctx = canvas.getContext('2d');

        // Background gradient
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, '#0a4f44');
        gradient.addColorStop(1, '#128C7E');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Card background
        ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
        ctx.roundRect(40, 40, canvas.width - 80, canvas.height - 80, 20);
        ctx.fill();

        // Title
        ctx.fillStyle = '#0a4f44';
        ctx.font = 'bold 32px Arial';
        ctx.textAlign = 'center';
        ctx.fillText('ID CARD TELEGRAM', canvas.width / 2, 80);

        // Line separator
        ctx.strokeStyle = '#0a4f44';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(50, 100);
        ctx.lineTo(canvas.width - 50, 100);
        ctx.stroke();

        // Profile photo
        if (photoUrl) {
            try {
                const response = await axios.get(photoUrl, { responseType: 'arraybuffer' });
                const avatar = await loadImage(response.data);

                ctx.save();
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.closePath();
                ctx.clip();

                ctx.drawImage(avatar, 80, 150, 140, 140);
                ctx.restore();

                // Circle border
                ctx.strokeStyle = '#0a4f44';
                ctx.lineWidth = 3;
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.stroke();
            } catch (e) {
                console.log('Gagal memuat gambar:', e.message);
                ctx.fillStyle = '#ccc';
                ctx.beginPath();
                ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
                ctx.fill();
            }
        } else {
            ctx.fillStyle = '#ccc';
            ctx.beginPath();
            ctx.arc(150, 220, 70, 0, Math.PI * 2, true);
            ctx.fill();
        }

        // User info
        ctx.textAlign = 'left';
        ctx.fillStyle = '#333';
        ctx.font = 'bold 24px Arial';
        ctx.fillText('Informasi Pengguna:', 280, 150);

        ctx.font = '20px Arial';
        ctx.fillText(`Nama: ${fullName}`, 280, 190);
        ctx.fillText(`User ID: ${userId}`, 280, 220);
        ctx.fillText(`Username: ${username}`, 280, 250);
        ctx.fillText(`Tanggal: ${today}`, 280, 280);
        ctx.fillText(`DC ID: ${dcId}`, 280, 310);

        // Footer
        ctx.textAlign = 'center';
        ctx.font = 'italic 16px Arial';
        ctx.fillStyle = '#666';
        ctx.fillText(`ID Card by Naeri Bot - @${settings.dev}`, canvas.width / 2, canvas.height - 50);

        const buffer = canvas.toBuffer('image/png');

        const caption = `
👤 *Username :* ${username}
🆔️ *User ID      :* \`${userId}\`
   `;

        await bot.sendPhoto(chatId, buffer, {
            caption,
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id,
            reply_markup: {
                inline_keyboard: [
                    [{ text: "ʙᴜʏ ꜱᴄʀɪᴘᴛ", url: `https://t.me/chgunturx` }]
                ]
            }
        });

    } catch (err) {
        console.error('Gagal generate ID card:', err.message);
        bot.sendMessage(chatId, '❌ Gagal generate ID card. Silakan coba lagi.');
    }
});

bot.onText(/^\/pay/, async (msg) => {
    const chatId = msg.chat.id;

    await bot.sendPhoto(chatId, settings.qris, {
        caption: `<blockquote>💳 <b>Metode Pembayaran Qris</b>

Silahkan scan QRIS di atas untuk melakukan pembayaran.

<b>💰 DANA Payment</b>
Nomor: <code>${settings.noDana}</code> (salin)
a/n ${settings.namaDana}

Kirim bukti transfer dan hubungi owner atau pilih metode pembayaran Dana!
</blockquote>`,
        reply_to_message_id: msg.message_id,
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [{ text: "💬 ᴄʜᴀᴛ ᴏᴡɴᴇʀ", url: `https://t.me/${settings.dev}` }]
            ]
        }
    });
});

// Handler untuk pesan teks biasa (tanpa prefix)
bot.on('message', async (msg) => {
    const text = msg.text;
    if (text && text.toLowerCase().trim() === 'ping') {
        const chatId = msg.chat.id;
        
        const sentMsg = await bot.sendMessage(chatId, "⏳ ꜱᴛᴀᴛᴜꜱ ʙᴏᴛ...", {
            parse_mode: "Markdown",
            reply_to_message_id: msg.message_id
        });
        
        // Bot uptime
        const botUptime = process.uptime();
        const botUptimeStr = `${Math.floor(botUptime / 3600)}h ${Math.floor((botUptime % 3600) / 60)}m ${Math.floor(botUptime % 60)}s`;
        
        // VPS uptime
        const vpsUptime = os.uptime();
        const vpsUptimeStr = `${Math.floor(vpsUptime / 86400)}d ${Math.floor((vpsUptime % 86400) / 3600)}h ${Math.floor((vpsUptime % 3600) / 60)}m`;
        
        // CPU
        const cpuModel = os.cpus()[0].model;
        const cpuCores = os.cpus().length;
        
        // RAM
        const totalMem = (os.totalmem() / (1024 ** 3)).toFixed(2);
        const freeMem = (os.freemem() / (1024 ** 3)).toFixed(2);
        
        // SWAP
        let swapTotal = 0;
        let swapFree = 0;
        
        try {
            const meminfo = fs.readFileSync("/proc/meminfo", "utf8");
            const totalMatch = meminfo.match(/SwapTotal:\s+(\d+)/);
            const freeMatch = meminfo.match(/SwapFree:\s+(\d+)/);
            
            if (totalMatch) swapTotal = (parseInt(totalMatch[1]) / 1024 / 1024).toFixed(2);
            if (freeMatch) swapFree = (parseInt(freeMatch[1]) / 1024 / 1024).toFixed(2);
        } catch (err) {
            swapTotal = "N/A";
            swapFree = "N/A";
        }
        
        // Sisa disk
        const { exec } = require('child_process');
        const util = require('util');
        const execPromise = util.promisify(exec);
        
        let diskUsage = "N/A";
        try {
            if (process.platform === 'win32') {
                const { stdout } = await execPromise('wmic logicaldisk where DriveType=3 get DeviceID,Size,FreeSpace');
                const lines = stdout.trim().split('\n');
                for (const line of lines) {
                    if (line.includes('C:')) {
                        const parts = line.trim().split(/\s+/);
                        const free = parseInt(parts[2]) / (1024 ** 3);
                        const total = parseInt(parts[1]) / (1024 ** 3);
                        diskUsage = `${free.toFixed(2)}/${total.toFixed(2)} GB`;
                        break;
                    }
                }
            } else {
                const { stdout } = await execPromise("df -h / | awk 'NR==2 {print $4\"/\"$2\" (\"$5\")\"}'");
                diskUsage = stdout.trim();
            }
        } catch (err) {
            diskUsage = "❌ Gagal";
        }
        
        // Versi Node
        const nodeVersion = process.version;
        
        const msgText = `🏓 𝖯𝗈𝗇𝗀 : ${botUptimeStr}
<blockquote expandable>
↬ 𝖴𝗉𝖳𝗂𝗆𝖾 : ${vpsUptimeStr}
↬ 𝖢𝖯𝖴 : ${cpuModel} (${cpuCores} cores)
↬ 𝖱𝖠𝖬 : ${freeMem} / ${totalMem} GB
↬ 𝖲𝗐𝖺𝗉 : ${swapFree} / ${swapTotal} GB
↬ 𝖣𝗂𝗌𝗄 : ${diskUsage}
↬ 𝖭𝗈𝖽𝖾 : ${nodeVersion}
</blockquote>`;
        
        bot.editMessageText(msgText, {
            chat_id: chatId,
            parse_mode: "HTML",
            message_id: sentMsg.message_id
        });
    }
});

bot.onText(/^\/restart$/, async (msg) => {
  const chatId = msg.chat.id

  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      msg.chat.id,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    )
  }

  const frames = [
    "▰▱▱▱▱▱▱▱▱▱",
    "▰▰▱▱▱▱▱▱▱▱",
    "▰▰▰▱▱▱▱▱▱▱",
    "▰▰▰▰▱▱▱▱▱▱",
    "▰▰▰▰▰▱▱▱▱▱",
    "▰▰▰▰▰▰▱▱▱▱",
    "▰▰▰▰▰▰▰▱▱▱",
    "▰▰▰▰▰▰▰▰▱▱",
    "▰▰▰▰▰▰▰▰▰▱",
    "▰▰▰▰▰▰▰▰▰▰"
  ]

  let m
  try {
    m = await bot.sendMessage(chatId, `🔄 Restarting...\n${frames[0]} 0%`, {
      reply_to_message_id: msg.message_id
    })
  } catch {
    return
  }

  let i = 0
  const total = frames.length

  const tick = async () => {
    i++
    const pct = Math.min(100, Math.round((i / total) * 100))
    const bar = frames[Math.min(i, total - 1)]
    try {
      await bot.editMessageText(`🔄 Restarting...\n${bar} ${pct}%`, {
        chat_id: chatId,
        message_id: m.message_id
      })
    } catch {}

    if (i >= total) {
      try {
        await bot.editMessageText(`✅ Restarting bot...`, {
          chat_id: chatId,
          message_id: m.message_id
        })
      } catch {}
      process.exit(0)
      return
    }

    setTimeout(tick, 450)
  }

  setTimeout(tick, 450)
})

let autoBackupInterval = null;

bot.onText(/^\/setbackup\s+(\d+)([smh])$/i, async (msg, match) => {
  const chatId = msg.chat.id

  if (msg.from.id !== ownerId) {
    return bot.sendMessage(
      chatId,
      `❌ @${settings.dev} Only!`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    )
  }

  const value = parseInt(match[1])
  const unit = match[2].toLowerCase()

  let intervalMs = 0
  let label = ""

  if (unit === "s") {
    intervalMs = value * 1000
    label = `${value} detik`
  } else if (unit === "m") {
    intervalMs = value * 60 * 1000
    label = `${value} menit`
  } else if (unit === "h") {
    intervalMs = value * 60 * 60 * 1000
    label = `${value} jam`
  }

  if (intervalMs < 10_000) {
    return bot.sendMessage(
      chatId,
      "❌ Minimal jeda backup adalah 10 detik.",
      { reply_to_message_id: msg.message_id }
    )
  }

  if (autoBackupInterval) clearInterval(autoBackupInterval)

  autoBackupInterval = setInterval(() => {
    const backupFile = `NAERI_BACKUP_@gunturnaktido.zip`
    const output = fs.createWriteStream(backupFile)
    const archive = archiver("zip", { zlib: { level: 9 } })

    output.on("close", () => {
      bot.sendDocument(chatId, backupFile)
        .then(() => fs.unlinkSync(backupFile))
        .catch(() => {})
    })

    archive.on("error", () => {
      bot.sendMessage(chatId, "❌ Gagal membuat backup!")
    })

    archive.pipe(output)

    const baseDir = process.cwd()
    const ignore = ["node_modules", ".git", backupFile]

    fs.readdirSync(baseDir).forEach((item) => {
      if (ignore.includes(item)) return
      const fullPath = path.join(baseDir, item)
      const stat = fs.statSync(fullPath)

      if (stat.isFile()) archive.file(fullPath, { name: item })
      else if (stat.isDirectory()) archive.directory(fullPath, item)
    })

    archive.finalize()
  }, intervalMs)

  bot.sendMessage(
    chatId,
    `✅ *Auto Backup berhasil diatur*\n\nWaktu: *${label}*\nBackup semua file & folder`,
    { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
  )
})

bot.onText(/\/backup/, (msg) => {
  const chatId = msg.chat.id

  if (msg.from.id !== ownerId) {
    return bot.sendMessage(
      chatId,
      `❌ @${settings.dev} Only!`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    )
  }

  const doBackup = () => {
    const backupFile = `NAERI_BACKUP_@gunturnaktido.zip`
    const output = fs.createWriteStream(backupFile)
    const archive = archiver("zip", { zlib: { level: 9 } })

    output.on("close", () => {
      bot.sendDocument(chatId, backupFile)
        .then(() => fs.unlinkSync(backupFile))
        .catch(() => {})
    })

    archive.on("error", (err) => {
      console.error(err)
      bot.sendMessage(chatId, "❌ Gagal membuat backup!")
    })

    archive.pipe(output)

    const baseDir = process.cwd()
    const ignore = [
      "node_modules",
      ".git",
      backupFile
    ]

    fs.readdirSync(baseDir).forEach((item) => {
      if (ignore.includes(item)) return
      const fullPath = path.join(baseDir, item)
      const stat = fs.statSync(fullPath)

      if (stat.isFile()) {
        archive.file(fullPath, { name: item })
      } else if (stat.isDirectory()) {
        archive.directory(fullPath, item)
      }
    })

    archive.finalize()
  }

  doBackup()

  if (autoBackupInterval) clearInterval(autoBackupInterval)

  autoBackupInterval = setInterval(doBackup, 30 * 60 * 1000)

  bot.sendMessage(
    chatId,
    "✅ _Auto Backup semua file & folder\naktif setiap 30 menit..._",
    { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
  )
})

const foldersToDelete = ['.cache', '.npm'];

function deleteFolderRecursive(folderPath) {
    if (fs.existsSync(folderPath)) {
        fs.rmSync(folderPath, { recursive: true, force: true });
        console.log(`\n📂 "${folderPath}" berhasil dihapus`);
    }
}

foldersToDelete.forEach(folder => {
    const folderPath = path.join(process.cwd(), folder);
    deleteFolderRecursive(folderPath);
});

function getWIBTimestamp() {
  const now = new Date()
  const wib = new Date(now.getTime() + 7 * 60 * 60 * 1000)

  const pad = n => n.toString().padStart(2, '0')

  return `${wib.getUTCFullYear()}-${pad(wib.getUTCMonth() + 1)}-${pad(wib.getUTCDate())}_` +
         `${pad(wib.getUTCHours())}-${pad(wib.getUTCMinutes())}-${pad(wib.getUTCSeconds())}`
}

async function backupSystem(msg) {
  const chatId = ownerId;
  const backupDir = path.join(__dirname, "backup")

  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true })
  }

  const timestamp = getWIBTimestamp()
  const fileName = `NAERIV6_BACKUP.zip`
  const zipPath = path.join(backupDir, fileName)

  const output = fs.createWriteStream(zipPath)
  const archive = archiver("zip", { zlib: { level: 9 } })

  return new Promise((resolve, reject) => {
    output.on("close", async () => {
      try {
        await bot.sendDocument(
          chatId,
          zipPath,
          {
            caption: `${bq}<b>📂 — System Backup</b>${ebq}\n🕒 ${timestamp} WIB`,
            parse_mode: "HTML"
          }
        )

        fs.unlinkSync(zipPath)
        resolve()
      } catch (err) {
        reject(err)
      }
    })

    archive.on("error", err => reject(err))
    archive.pipe(output)

    archive.glob("**/*", {
      cwd: __dirname,
      dot: true,
      ignore: [
        "node_modules/**",
        "backup/**",
        ".env",
        "*.zip"
      ]
    })

    archive.finalize()
  })
}
    
;(async () => {
  try {
    await backupSystem(bot, ownerId)
    console.log('✅ Sukses mengirim Backup!')
  } catch (err) {
    console.error('❌ Backup awal gagal:', err.message)
  }
})()

cron.schedule('*/30 * * * *', async () => {
  try {
    await backupSystem(bot, ownerId)
    console.log('Mengirim Backup dalam 30 menit...')
  } catch (err) {
    console.error('❌ Backup gagal:', err.message)
  }
})

bot.on("message", async (msg) => {
  if (!msg.text) return;
  if (!msg.text.startsWith("/")) return;

  const command = msg.text.split(" ")[0].toLowerCase();
  const userId = msg.from.id;
  const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
  const chatType = msg.chat.type === "private"
    ? "Private"
    : `Public (${msg.chat.title || "Group Tanpa Nama"})`;

  // Format tanggal Indonesia
  const waktu = moment().tz("Asia/Jakarta");
  const tanggal = waktu.format("DD/MMMM/YYYY"); // contoh: 23/September/2025
  const hari = waktu.format("dddd"); // contoh: Senin

  console.log(
    chalk.white.bold("\n⤥ Command: ") + chalk.gray.bold(command) +
    chalk.white.bold("\n⤥ User ID: ") + chalk.cyan.bold(userId) +
    chalk.white.bold("\n⤥ Username: ") + chalk.cyan.bold(username) +
    chalk.white.bold("\n⤥ Chat Type: ") + chalk.gray.bold(chatType) +
    chalk.white.bold("\n⤥ Tanggal: ") + chalk.gray.bold(`${hari}, ${tanggal}\n`)
  );
});

bot.on('polling_error', (error) => {
  console.error('❌', error.code, error.message)
})

process.on("unhandledRejection", err => {
  if (err?.response?.body?.error_code === 429) return
  console.error(err)
})

process.on("unhandledRejection", (err) => {
  console.log("UNHANDLED REJECTION:", err?.response?.body || err);
});
 
/*}
setTimeout(() => {
    initializeBot().catch(err => {
        console.log('System initialization error:', err.message);
        process.exit(1);
    });
}, 1000);*/