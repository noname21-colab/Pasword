 /*
   #--- Credits Script by @naeldev
   Telegram: https:/t.me/naeldev

-- [ ! ] Dilarang keras hapus pesan
   Ada kendala? hubungi kontak diatas!
*/

const chalk = require("chalk");
const fs = require("fs");
const path = require("path");

const settings = {
  token: '8518256433:AAHmN4XmA_owx_kwyfmPK9tnRX995W8G6PE', // token dari @BotFather
  
      ownerId: 5833239531, // user id
  dev: 'gunturnaktido', // username tele
  usnBot: '@CpanelXCvpsGunturbot',
  noDana: '085316792077', // nomer dana
  namaDana: '-', // nama
    
  chUsn: '@chgunturx', // ch tele
  
  exPGroupId: "-100375561310", // id group
  exGroupId: "-100375561310", // id group
    
  hostname: "Guntur", // hostname vps
    
  apiAtlantic: "", // apikey atlantic
    
  apiPakasir: "", // apikey pakasir
  pakasirProject: "qrisall", // nama project
    
  apiDigitalOcean: "",   // apikey DO
  apiDigitalOcean2: "",  // apikey DO 2  
  apiDigitalOcean3: "",  // apikey DO 3
  apiDigitalOcean4: "",  // apikey DO 4
  apiDigitalOcean5: "",  // apikey DO 5
  apiDigitalOcean6: "",  // apikey DO 6
  apiDigitalOcean7: "",  // apikey DO 7
  apiDigitalOcean8: "",  // apikey DO 8
  apiDigitalOcean9: "",  // apikey DO 9
  apiDigitalOcean10: "", // apikey DO 10
  
  pp: 'http://uploader.gunturxhoshino.biz.id/files/1777376881151_4ed2b274.jpg', // link catbox foto
  ppVid: 'https://files.catbox.moe/bm2afx.mp4', // link catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel pterodactyl

  qris: 'https://files.catbox.moe/ckrnpu.jpg', // foto qris
    
  tokeninstall: "revan",
  bash: "bash <(curl https://raw.githubusercontent.com/zerodevxc/revan/refs/heads/main/install.sh)",

  domain: '', // domain public
  plta: '', // ptla panel
  pltc: '', // ptlc panel
    
  domainPriv: '-', // domain private
  pltaPriv: '-', // apikey ptla
  pltcPriv: '-', // apikey ptlc
    
    // PANEL SERVER 2
  domainV2: '', // domain v2
  pltaV2: '', // plta v2
  pltcV2: '', // ptlc v2
    
    // PANEL SERVER 3
  domainV3: '', // domain v3 
  pltaV3: '', // ptla v3
  pltcV3: '', // ptlc v3
    
    // PANEL SERVER 4
  domainV4: '', // domain v4
  pltaV4: '', // ptla v4
  pltcV4: '', // ptlc v4
    
    // PANEL SERVER 5
  domainV5: '', // domain v5
  pltaV5: '', // ptla v5
  pltcV5: '', // ptlc v5
  
  loc: '1', // location id
  eggs: '15', // egg id
    
  bq: '<blockquote>',
  ebq: '</blockquote>',
  bqe: '<blockquote expandable>'
};

module.exports = settings;

let file = require.resolve(__filename);
fs.watchFile(file, (curr, prev) => {
  if (curr.mtime !== prev.mtime) {
    console.log(chalk.blue(">> Update File :"), chalk.black.bgWhite(`${path.basename(__filename)}`));
    console.log(chalk.gray("Config file reloaded..."));
    
    delete require.cache[file];
    
    try {
      const newConfig = require(file);
    } catch (err) {
      console.log(chalk.gray(`❌ Error reloading config: ${err.message}`));
    }
  }
});
