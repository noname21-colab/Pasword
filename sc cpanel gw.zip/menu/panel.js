const fs = require('fs');
const path = require('path');
const { NodeSSH } = require("node-ssh");
const ssh = new NodeSSH();

const usersFile = path.resolve("./database/users");

function isUser(role, id) {
  try {
    const file = path.join(usersFile, `${role}.json`);
    if (!fs.existsSync(file)) return false;

    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!Array.isArray(data)) return false;

    return data.includes(String(id));
  } catch {
    return false;
  }
}

function isOwner(id)  { return isUser("owner", id); }
function isPremium(id)  { return isUser("prem", id); }
function isReseller(id) { return isUser("ress", id); }

const settings = require("../settings/config");
const {
  pp, panel, bq, ebq, dev,
  domain, plta, pltc,
  domainV2, pltaV2, pltcV2,
  domainV3, pltaV3, pltcV3,
  domainV4, pltaV4, pltcV4,
  domainV5, pltaV5, pltcV5,
  eggs, loc
} = require("../settings/config");

module.exports = function (bot) {
    
  const createPanelState = new Map()
  bot.onText(/^\/(1gb|2gb|3gb|4gb|5gb|6gb|7gb|8gb|9gb|10gb)(?:\s+(.+))?$/, async (msg, match) => {
  const chatId = msg.chat.id
  const plan = match[1]
  const text = match[2]
  const fromId = String(msg.from.id)
  
  if (!isReseller(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Reseller.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  if (!text) return bot.sendMessage(chatId, `Contoh: /${plan} namapanel,idtele`)
  const parts = String(text).split(",")
  const username = parts[0] ? String(parts[0]).trim() : ""
  const u = parts[1] ? String(parts[1]).trim() : ""
  if (!username || !u) return bot.sendMessage(chatId, `Usage: /${plan} namapanel,idtele`)

  const specMap = {
    "1gb": { memo: 1024, cpu: 60, disk: 2000 },
    "2gb": { memo: 2048, cpu: 80, disk: 3000 },
    "3gb": { memo: 3072, cpu: 100, disk: 4000 },
    "4gb": { memo: 4096, cpu: 120, disk: 5000 },
    "5gb": { memo: 5120, cpu: 140, disk: 6000 },
    "6gb": { memo: 6144, cpu: 160, disk: 7000 },
    "7gb": { memo: 7168, cpu: 180, disk: 8000 },
    "8gb": { memo: 8192, cpu: 200, disk: 9000 },
    "9gb": { memo: 9216, cpu: 220, disk: 10000 },
    "10gb": { memo: 10240, cpu: 240, disk: 11000 }
  }

  const specs = specMap[plan]
  if (!specs) return bot.sendMessage(chatId, `⚠️ Spesifikasi untuk ${plan} tidak ditemukan.`)

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => {
    const p = PANEL_MAP[id]
    return !!(p && p.domain && String(p.domain).trim() && p.plta && String(p.plta).trim())
  })

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong).", {
      reply_to_message_id: msg.message_id
    })
  }

  createPanelState.set(`${chatId}:${fromId}`, {
    plan,
    username,
    u,
    memo: specs.memo,
    cpu: specs.cpu,
    disk: specs.disk,
    message_id: msg.message_id
  })

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_create:${id}:${fromId}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🖥️ <b>Server List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (!data.startsWith("pick_create:")) return

  const spl = data.split(":")
  const srvId = spl[1]
  const ownerId = spl[2]
  const clickerId = String(q.from.id)

  if (clickerId !== String(ownerId)) {
    return bot.answerCallbackQuery(q.id, { text: "❌ Tombol ini bukan untuk kamu.", show_alert: true })
  }

  const st = createPanelState.get(`${chatId}:${ownerId}`)
  if (!st) {
    return bot.answerCallbackQuery(q.id, { text: "⚠️ Session tidak ditemukan.", show_alert: true })
  }

  const panelCfg = PANEL_MAP[srvId]
  if (!panelCfg || !panelCfg.domain || !panelCfg.plta) {
    await bot.answerCallbackQuery(q.id, { text: "❌ Server tidak valid.", show_alert: true })
    try {
      return await bot.editMessageText("❌ Server tidak valid.", { chat_id: chatId, message_id: messageId })
    } catch {
      return
    }
  }

  await bot.answerCallbackQuery(q.id, { text: "⏳ Memproses..." })

  const domain = String(panelCfg.domain).replace(/\/+$/g, "")
  const plta = String(panelCfg.plta).trim()

  const plan = st.plan
  const username = st.username
  const u = st.u
  const memo = st.memo
  const cpu = st.cpu
  const disk = st.disk

  const name = username + plan
  const email = `${username}@buyer.guntur`
  const password = username + Math.random().toString(36).slice(2, 5)
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}'

  let user, server

  try {
    const res1 = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
        Accept: "application/json"
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: "en",
        password
      })
    })

    const textRes1 = await res1.text()
    if (!textRes1.startsWith("{")) {
      try {
        await bot.editMessageText(`⚠️ Respon bukan JSON dari ${domain}:\n${textRes1.slice(0, 300)}...`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const data1 = JSON.parse(textRes1)
    if (data1.errors) {
      try {
        await bot.editMessageText(`❌ Error user: ${JSON.stringify(data1.errors[0])}`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
    user = data1.attributes

    const res2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
        Accept: "application/json"
      },
      body: JSON.stringify({
        name,
        user: user.id,
        egg: parseInt(eggs),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
        limits: { memory: memo, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 5, backups: 5, allocations: 1 },
        deploy: { locations: [parseInt(settings.loc)], dedicated_ip: false, port_range: [] }
      })
    })

    const textRes2 = await res2.text()
    if (!textRes2.startsWith("{")) {
      try {
        await bot.editMessageText(`⚠️ Respon bukan JSON dari ${domain}:\n${textRes2.slice(0, 300)}...`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const data2 = JSON.parse(textRes2)
    if (data2.errors) {
      try {
        await bot.editMessageText(`❌ Error server: ${JSON.stringify(data2.errors[0])}`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
    server = data2.attributes
  } catch (e) {
    try {
      await bot.editMessageText(`❌ Error: ${e.message}`, { chat_id: chatId, message_id: messageId })
    } catch {}
    return
  }

  if (!user || !server) {
    try {
      await bot.editMessageText("⚠️ Gagal membuat data panel.", { chat_id: chatId, message_id: messageId })
    } catch {}
    return
  }

  try {
    await bot.editMessageText(`✅ Sukses membuat panel ${plan} di Server ${srvId} dan sudah tekirim ke Anda`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML"
    })
  } catch {}

  bot.sendMessage(
    chatId,
    `*- BERIKUT DATA PANEL ${plan} -*\n` +
      `NAMA: ${username}\n` +
      `EMAIL: ${email}\n` +
      `ID: ${user.id}\n` +
      `MEMORY: ${server.limits.memory} MB\n` +
      `DISK: ${server.limits.disk} MB\n` +
      `CPU: ${server.limits.cpu}%`,
    { parse_mode: "Markdown", reply_to_message_id: st.message_id }
  )

  bot.sendPhoto(u, panel, {
    caption:
      `*🔐 Sukses Created Panel ${plan}!*\n` +
      `▸ Name: ${username}\n` +
      `▸ Email: ${email}\n` +
      `▸ ID: ${user.id}\n` +
      `▸ RAM: ${plan}\n\n` +
      `*🌐 Akun Panel*\n` +
      `▸ Username: \`${user.username}\`\n` +
      `▸ Password: \`${password}\`\n\n` +
      `*⚠️ Rules Panel*\n` +
      `▸ Sensor domain\n` +
      `▸ Simpan data akun\n` +
      `▸ Garansi 15 hari`,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Domain", url: domain },
          { text: "Salin Password", switch_inline_query_current_chat: password }
        ]
      ]
    }
  })

  createPanelState.delete(`${chatId}:${ownerId}`)
})
    
  bot.onText(/^\/infoadp$/i, async (msg) => {
  const chatId = msg.chat.id
  const fromId = String(msg.from.id)
  
  if (!isOwner(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Owner.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  const isValidPanel = (p) => {
    const d = p && p.domain && String(p.domain).trim()
    const a = p && p.plta && String(p.plta).trim()
    const c = p && p.pltc && String(p.pltc).trim()
    return d && a && c
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia.", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_infoadp:${id}:${fromId}`
      }))
    )
  }

  return bot.sendMessage(
    chatId,
    `🖥️ <b>Server List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard }
    }
  )
})

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (!data.startsWith("pick_infoadp:")) return

  const parts = data.split(":")
  const srvId = parts[1]
  const ownerId = parts[2]

  if (String(q.from.id) !== String(ownerId)) {
    return bot.answerCallbackQuery(q.id, { text: "Akses ditolak", show_alert: true })
  }

  const panel = PANEL_MAP[srvId]
  if (!panel) {
    await bot.answerCallbackQuery(q.id, { text: "Server tidak valid", show_alert: true })
    return
  }

  await bot.answerCallbackQuery(q.id)

  const domain = panel.domain || "-"
  const plta = panel.plta || "-"
  const pltc = panel.pltc || "-"

  const text =
    `🖥️ <b>Server ${srvId} Detail Admin</b>\n\n` +
    `<b>Domain:</b>\n<code>${domain}</code>\n\n` +
    `<b>PLTA:</b>\n<code>${plta}</code>\n\n` +
    `<b>PLTC:</b>\n<code>${pltc}</code>`

  try {
    return await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML"
    })
  } catch {
    return
  }
})

  const PANEL_MAP = {
    1: { label: "V1", domain, plta, pltc },
    2: { label: "V2", domain: domainV2, plta: pltaV2, pltc: pltcV2 },
    3: { label: "V3", domain: domainV3, plta: pltaV3, pltc: pltcV3 },
    4: { label: "V4", domain: domainV4, plta: pltaV4, pltc: pltcV4 },
    5: { label: "V5", domain: domainV5, plta: pltaV5, pltc: pltcV5 }
  }
  const PANELS = [
    { name: "2", domain: domainV2, plta: pltaV2, pltc: pltcV2 },
    { name: "3", domain: domainV3, plta: pltaV3, pltc: pltcV3 },
    { name: "4", domain: domainV4, plta: pltaV4, pltc: pltcV4 },
    { name: "5", domain: domainV5, plta: pltaV5, pltc: pltcV5 }
  ]
    
  const CADP_SERVERS = {
  1: { domain, token: plta },
  2: { domain: domainV2, token: pltaV2 },
  3: { domain: domainV3, token: pltaV3 },
  4: { domain: domainV4, token: pltaV4 },
  5: { domain: domainV5, token: pltaV5 }
}
  
  const cadpPending = new Map()
  const serverPages = new Map()

  bot.onText(/^\/cadp(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  if (!isPremium(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Premium.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  const rawParams = match && match[1] ? match[1].trim() : ""
  if (!rawParams) return bot.sendMessage(chatId, "❌ Format Salah!\nPenggunaan: /cadp nama,idtele")

  const parts = rawParams.split(",").map((x) => x.trim()).filter(Boolean)
  if (parts.length < 2) return bot.sendMessage(chatId, "❌ Format Salah!\nPenggunaan: /cadp nama,idtele")

  const panelName = parts[0]
  const telegramId = parts[1]
  const password = panelName + Math.random().toString(36).slice(2, 5)

  cadpPending.set(String(userId), { panelName, telegramId, password, at: Date.now() })

  const ids = ["1", "2", "3", "4", "5"].filter((id) => {
    const p = CADP_SERVERS[id]
    return p && p.domain && String(p.domain).trim() && p.token && String(p.token).trim()
  })

  if (!ids.length) {
    cadpPending.delete(String(userId))
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/token kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < ids.length; i += 2) {
    inline_keyboard.push(
      ids.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `cadp_srv_${id}`
      }))
    )
  }

  return bot.sendMessage(
    chatId,
    `🖥️ <b>Server List Option</b>\n${bq}Choose the Server:${ebq}`,
    {
      reply_to_message_id: msg.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard }
    }
  )
})

  bot.on("callback_query", async (cq) => {
  const data = cq.data || ""
  if (!data.startsWith("cadp_srv_")) return

  const chatId = cq.message.chat.id
  const userId = cq.from.id

  try {
    await bot.deleteMessage(chatId, cq.message.message_id)
  } catch {}

  const serverNum = Number(data.replace("cadp_srv_", ""))
  const cfg = CADP_SERVERS[serverNum]
  if (!cfg || !cfg.domain || !String(cfg.domain).trim() || !cfg.token || !String(cfg.token).trim()) return

  const pending = cadpPending.get(String(userId))
  if (!pending) {
    return bot.sendMessage(chatId, "❌ Data /cadp tidak ditemukan. Ketik ulang: /cadp nama,idtele")
  }

  if (Date.now() - pending.at > 2 * 60 * 1000) {
    cadpPending.delete(String(userId))
    return bot.sendMessage(chatId, "❌ Request kadaluarsa. Ketik ulang: /cadp nama,idtele")
  }

  const { panelName, telegramId, password } = pending

  try {
    await bot.editMessageReplyMarkup(
      { inline_keyboard: [] },
      { chat_id: chatId, message_id: cq.message.message_id }
    )
  } catch {}

  try {
    const res = await fetch(`${cfg.domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.token}`
      },
      body: JSON.stringify({
        email: `${panelName}@admin.guntur`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password
      })
    })

    const json = await res.json()
    if (json.errors) {
      return bot.sendMessage(chatId, JSON.stringify(json.errors[0], null, 2))
    }

    const user = json.attributes

    await bot.sendMessage(
      chatId,
      `TYPE: ADMIN PANEL (Server ${serverNum})
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
`,
      { reply_to_message_id: cq.message_id }
    )

    const escapeHtml = (s) =>
      String(s ?? "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")

    const safeCode = (s) => `<code>${escapeHtml(s)}</code>`

    const caption = `🔐 <b>Sukses Created Admin Panel!</b>
(Server ${serverNum})

👤 <b>Username:</b> ${safeCode(user.username)}
🔑 <b>Password:</b> ${safeCode(password)}
🌐 <b>Domain:</b> ${escapeHtml(cfg.domain)}

<blockquote><b>📌 Catatan :</b>
Simpan informasi data ini dengan aman
dan jangan pernah untuk bagikan ke orang lain!
</blockquote>`

    await bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" })

    await bot.sendMessage(
      chatId,
      `✅ Sukses kirim admin panel ke @${cq.from.username || "user"}\n(ID: ${userId})`,
      { reply_to_message_id: cq.message_id }
    )

    cadpPending.delete(String(userId))
  } catch (err) {
    console.error(err)
    return bot.sendMessage(chatId, "❌ Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi.")
  }
})

  const UNLI_SERVERS = {
  1: { domain, token: plta },
  2: { domain: domainV2, token: pltaV2 },
  3: { domain: domainV3, token: pltaV3 },
  4: { domain: domainV4, token: pltaV4 },
  5: { domain: domainV5, token: pltaV5 }
}

  const unliPending = new Map()

  bot.onText(/^\/unli(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id

  if (!isReseller(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus user *Reseller.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  const text = match[1]
  if (!text) return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /unli nama,id")

  const parts = text.split(",").map((x) => x.trim()).filter(Boolean)
  if (parts.length < 2) return bot.sendMessage(chatId, "⚠️ Format: /unli namapanel,idtele")

  const username = parts[0]
  const teleId = parseInt(parts[1], 10)

  try {
    await bot.getChat(teleId)
  } catch (err) {
    return bot.sendMessage(chatId, `❌ User dengan ID ${teleId} tidak ditemukan / belum start bot!`, {
      reply_to_message_id: msg.message_id
    })
  }

  unliPending.set(String(userId), { username, teleId, at: Date.now() })

  const ids = ["1", "2", "3", "4", "5"].filter((id) => {
    const p = UNLI_SERVERS[id]
    return p && p.domain && String(p.domain).trim() && p.token && String(p.token).trim()
  })

  if (!ids.length) {
    unliPending.delete(String(userId))
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/token kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < ids.length; i += 2) {
    inline_keyboard.push(
      ids.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `unli_srv_${id}`
      }))
    )
  }

  return bot.sendMessage(
    chatId,
    `🖥️ <b>Server List Option</b>\n${bq}Choose the Server:${ebq}`,
    {
      reply_to_message_id: msg.message_id,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard }
    }
  )
})

  bot.on("callback_query", async (cq) => {
  const data = cq.data || ""
  if (!data.startsWith("unli_srv_")) return

  const chatId = cq.message.chat.id
  const userId = cq.from.id

  try {
    await bot.deleteMessage(chatId, cq.message.message_id)
  } catch {}

  const serverNum = Number(data.replace("unli_srv_", ""))
  const cfg = UNLI_SERVERS[serverNum]
  if (!cfg || !cfg.domain || !String(cfg.domain).trim() || !cfg.token || !String(cfg.token).trim()) return

  const pending = unliPending.get(String(userId))
  if (!pending) return bot.sendMessage(chatId, "❌ Data /unli tidak ditemukan. Ketik ulang: /unli nama,idtele")

  if (Date.now() - pending.at > 2 * 60 * 1000) {
    unliPending.delete(String(userId))
    return bot.sendMessage(chatId, "❌ Request kadaluarsa. Ketik ulang: /unli nama,idtele")
  }

  const { username, teleId } = pending

  try {
    await bot.editMessageReplyMarkup(
      { inline_keyboard: [] },
      { chat_id: chatId, message_id: cq.message.message_id }
    )
  } catch {}

  const name = username + "unli"
  const egg = eggs
  const loc = settings.loc
  const memo = "0"
  const cpu = "0"
  const disk = "0"
  const email = `${username}@unli.guntur`
  const password = username + Math.random().toString(36).slice(2, 5)
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}'

  try {
    const resUser = await fetch(`${cfg.domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.token}`
      },
      body: JSON.stringify({
        email,
        username,
        first_name: username,
        last_name: username,
        language: "en",
        password
      })
    })

    const dataUser = await resUser.json()
    if (dataUser.errors) {
      return bot.sendMessage(
        chatId,
        `❌ Gagal buat user: ${dataUser.errors[0]?.detail || dataUser.errors[0]?.code || "unknown"}`
      )
    }

    const user = dataUser.attributes

    const resServer = await fetch(`${cfg.domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.token}`
      },
      body: JSON.stringify({
        name,
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start"
        },
        limits: { memory: memo, swap: 0, disk, io: 500, cpu },
        feature_limits: { databases: 5, backups: 5, allocations: 1 },
        deploy: { locations: [parseInt(loc)], dedicated_ip: false, port_range: [] }
      })
    })

    const dataServer = await resServer.json()
    if (dataServer.errors) {
      return bot.sendMessage(
        chatId,
        `❌ Gagal buat server: ${dataServer.errors[0]?.detail || dataServer.errors[0]?.code || "unknown"}`
      )
    }

    const server = dataServer.attributes

    await bot.sendMessage(
      chatId,
      `Type: Panel Unli (Server ${serverNum})
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    )

    await bot.sendPhoto(teleId, panel, {
      caption: `🔐 *Sukses Created Panel!*
▸ Name: ${username}
▸ Email: ${email}
▸ ID: ${user.id}
▸ RAM: Unlimited

🌐 *Akun Panel*
▸ Username: \`${username}\`
▸ Password: \`${password}\`
▸ Login: ${cfg.domain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ No DDOS/Share Free
▸ Garansi 15 hari`,
      parse_mode: "Markdown"
    })

    await bot.sendMessage(
      chatId,
      `✅ Sukses kirim panel ke @${cq.from.username || "user"}\n(ID: ${teleId})`,
      { reply_to_message_id: cq.message_id }
    )

    unliPending.delete(String(userId))
  } catch (err) {
    console.error(err)
    return bot.sendMessage(chatId, "❌ Terjadi kesalahan. Silakan coba lagi.")
  }
})

  bot.onText(/^\/server$/, async (msg) => {
    const chatId = msg.chat.id

    return bot.sendPhoto(chatId, pp, {
      caption: `${bq}╭──✧ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ✧
│ ⤥ Server : 1.0.0
│ ⤥ Type : Public
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /addprem
│ ⤥ /delprem
│ ⤥ /address
│ ⤥ /delress
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ ✧
│ ⤥ /listsrv
│ ⤥ /listsrvoff
│ ⤥ /listadmin
│ ⤥ /deladm
│ ⤥ /delusroff
│ ⤥ /delsrv
│ ⤥ /delsrvoff
│ ⤥ /totalserver
│ ⤥ /servercpu
│ ⤥ /cadp
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /1gb-/10gb
│ ⤥ /unli
╰────────────⧽
${ebq}`,
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Server 2", callback_data: "server_2" },
            { text: "Server 3", callback_data: "server_3" },
            { text: "Server 4", callback_data: "server_4" },
            { text: "Server 5", callback_data: "server_5" }
          ],
          [{ text: "Type Public", url: `https://t.me/${dev}` }]
        ]
      }
    })
  })

  bot.onText(/^\/serverp$/, async (msg) => {
    const chatId = msg.chat.id

    return bot.sendPhoto(chatId, pp, {
      caption: `${bq}╭──✧ ɪɴꜰᴏʀᴍᴀᴛɪᴏɴ ✧
│ ⤥ Server : 1.0.0
│ ⤥ Type : Private
╰────────────⧽

╭──✧ ᴏᴡɴᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /addpremp
│ ⤥ /delpremp
│ ⤥ /addressp
│ ⤥ /delressp
╰────────────⧽

╭──✧ ᴘʀᴇᴍɪᴜᴍ ᴍᴇɴᴜ ✧
│ ⤥ /srvlist
│ ⤥ /srvofflist
│ ⤥ /adminlist
│ ⤥ /admdel
│ ⤥ /usroffdel
│ ⤥ /srvdel
│ ⤥ /srvoffdel
│ ⤥ /totalsrv
│ ⤥ /srvcpu
│ ⤥ /cadmin
╰────────────⧽

╭──✧ ʀᴇꜱᴇʟʟᴇʀ ᴍᴇɴᴜ ✧
│ ⤥ /1gbp-/10gbp
│ ⤥ /cunli
╰────────────⧽
${ebq}`,
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Server 2", callback_data: "server_2" },
            { text: "Server 3", callback_data: "server_3" },
            { text: "Server 4", callback_data: "server_4" },
            { text: "Server 5", callback_data: "server_5" }
          ],
          [{ text: "Type Private", url: `https://t.me/${dev}` }]
        ]
      }
    })
  })

  bot.onText(/^\/totalserver$/i, async (msg) => {
  const chatId = msg.chat.id

  const validServerEntries = Object.entries(PANEL_MAP || {}).filter(([id, p]) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    const pltcOk = !!(p && p.pltc && String(p.pltc).trim())
    return domainOk && pltaOk && pltcOk
  })

  if (!validServerEntries.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang aktif dikonfigurasi (domain/plta/pltc kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const buttons = []
  for (let i = 0; i < validServerEntries.length; i += 2) {
    buttons.push(
      validServerEntries.slice(i, i + 2).map(([id, p]) => ({
        text: `Server ${id}`,
        callback_data: `total_pick:${id}`
      }))
    )
  }

  return bot.sendMessage(
    chatId,
    `📊 <b>Total Server Options</b>\n${bq}<b>Choose the Server:</b>${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: buttons }
    }
  )
})

  async function getPanelStats(panel) {
  let totalServers = 0
  let activeServers = 0
  let offlineServers = 0

  let page = 1
  let totalPages = 1

  do {
    const f = await fetch(`${panel.domain}/api/application/servers?page=${page}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${panel.plta}`,
        Accept: "application/json"
      }
    })

    if (!f.ok) throw new Error("Panel unreachable")

    const res = await f.json()
    if (!res || !res.data) break

    totalPages = res.meta && res.meta.pagination ? res.meta.pagination.total_pages : 1

    for (const srv of res.data) {
      totalServers++

      try {
        const r = await fetch(`${panel.domain}/api/client/servers/${srv.attributes.uuid}/resources`, {
          method: "GET",
          headers: {
            Authorization: `Bearer ${panel.pltc}`,
            Accept: "application/json"
          }
        })

        const data = await r.json()
        const state = data && data.attributes ? data.attributes.current_state : null

        if (state === "running" || state === "starting") activeServers++
        else offlineServers++
      } catch {
        offlineServers++
      }
    }

    page++
  } while (page <= totalPages)

  return { totalServers, activeServers, offlineServers }
}

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data.startsWith("total_pick:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP && PANEL_MAP[srvId]
    if (!panel) {
      return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })
    }

    const domainOk = !!(panel.domain && String(panel.domain).trim())
    const pltaOk = !!(panel.plta && String(panel.plta).trim())
    const pltcOk = !!(panel.pltc && String(panel.pltc).trim())
    if (!domainOk || !pltaOk || !pltcOk) {
      return bot.answerCallbackQuery(q.id, { text: "Konfigurasi server ini belum lengkap." })
    }

    await bot.answerCallbackQuery(q.id, { text: "⏳ Mengambil statistik..." })

    try {
      const st = await getPanelStats(panel)

      return bot.editMessageText(
        `${bq}📊 <b>Statistik Panel Server ${srvId}</b>${ebq}
⤥ Server Aktif (${st.activeServers})
⤥ Server Offline (${st.offlineServers})

${bq}🖥️ Total Server: <b>${st.totalServers}</b>${ebq}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      )
    } catch {
      return bot.editMessageText("⚠️ Gagal mengambil data server.", {
        chat_id: chatId,
        message_id: messageId
      })
    }
  }

  if (data.startsWith("panel_info:")) {
    const name = data.split(":")[1]
    return bot.answerCallbackQuery(q.id, { text: `Panel Server ${name}` })
  }

  if (data === "srv_next" || data === "srv_prev") {
    const st = serverPages.get(chatId)
    if (!st) return bot.answerCallbackQuery(q.id)

    const newPage = data === "srv_next" ? st.page + 1 : st.page - 1
    await bot.answerCallbackQuery(q.id)
    return renderServerPage(chatId, messageId, newPage)
  }

  if (data.startsWith("pick_srv:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "📋 Memuat server..." })

    try {
      let page = 1
      let totalPages = 1
      let servers = []

      do {
        const res = await fetch(`${panel.domain}/api/application/servers?page=${page}`, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${panel.plta}`
          }
        })

        const json = await res.json()
        if (!json || !json.data) break

        servers = servers.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      if (!servers.length) {
        return bot.editMessageText("⚠️ Tidak ada server ditemukan.", {
          chat_id: chatId,
          message_id: messageId
        })
      }

      serverPages.set(chatId, {
        servers,
        page: 1,
        panelLabel: panel.label
      })

      return renderServerPage(chatId, messageId, 1)
    } catch {
      return bot.editMessageText("❌ Gagal mengambil data server.", {
        chat_id: chatId,
        message_id: messageId
      })
    }
  }

  return bot.answerCallbackQuery(q.id)
})

  bot.onText(/^\/listsrv$/, async (msg) => {
  const chatId = msg.chat.id

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    const pltcOk = !!(p && p.pltc && String(p.pltc).trim())
    return domainOk && pltaOk && pltcOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta/pltc kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_srv:${id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🖥️ <b>Server List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  async function renderServerPage(chatId, messageId, page) {
  const data = serverPages.get(chatId)
  if (!data) return

  const { servers, panelLabel, statusMap } = data
  const pageSize = 10
  const totalPage = Math.max(1, Math.ceil(servers.length / pageSize))
  const safePage = Math.max(1, Math.min(page, totalPage))
  if (data.page === safePage) return

  const start = (safePage - 1) * pageSize
  const end = Math.min(start + pageSize, servers.length)

  let text = `📋 <b>Daftar Server ${panelLabel}</b>\n\n`

  for (let i = start; i < end; i++) {
    const s = servers[i].attributes
    const st = statusMap ? statusMap[s.uuid] : null
    const label = st === "online" ? "Online" : "Offline"
    text += `ID: ${s.id}\nNama: ${s.name}\nStatus: ${label}\n\n`
  }

  serverPages.set(chatId, { ...data, page: safePage })

  const keyboard = []
  if (safePage > 1) keyboard.push({ text: "⬅️", callback_data: "srv_prev" })
  keyboard.push({ text: `${safePage}/${totalPage}`, callback_data: "none" })
  if (safePage < totalPage) keyboard.push({ text: "➡️", callback_data: "srv_next" })

  try {
    return await bot.editMessageText(text.trim(), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [keyboard] }
    })
  } catch {}
}

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data.startsWith("panel_info:")) {
    const name = data.split(":")[1]
    return bot.answerCallbackQuery(q.id, { text: `Panel Server ${name}` })
  }

  if (data === "srv_next" || data === "srv_prev") {
    const st = serverPages.get(chatId)
    if (!st) return bot.answerCallbackQuery(q.id)

    const totalPage = Math.max(1, Math.ceil(st.servers.length / 10))
    const newPage = data === "srv_next" ? Math.min(st.page + 1, totalPage) : Math.max(st.page - 1, 1)
    if (newPage === st.page) return bot.answerCallbackQuery(q.id)

    await bot.answerCallbackQuery(q.id)
    return renderServerPage(chatId, messageId, newPage)
  }

  if (data.startsWith("pick_srv:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "📋 Memuat server..." })

    try {
      let page = 1
      let totalPages = 1
      let servers = []

      do {
        const res = await fetch(`${panel.domain}/api/application/servers?page=${page}`, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${panel.plta}`
          }
        })

        const json = await res.json()
        if (!json || !json.data) break

        servers = servers.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      if (!servers.length) {
        try {
          return await bot.editMessageText("⚠️ Tidak ada server ditemukan.", {
            chat_id: chatId,
            message_id: messageId
          })
        } catch {}
        return
      }

      const statusMap = {}
      for (const srv of servers) {
        const uuid = srv.attributes.uuid
        try {
          const r = await fetch(`${panel.domain}/api/client/servers/${uuid}/resources`, {
            method: "GET",
            headers: {
              Authorization: `Bearer ${panel.pltc}`,
              Accept: "application/json"
            }
          })

          const data = await r.json()
          const state = data && data.attributes ? data.attributes.current_state : null
          statusMap[uuid] = state === "running" || state === "starting" ? "online" : "offline"
        } catch {
          statusMap[uuid] = "offline"
        }
      }

      serverPages.set(chatId, {
        servers,
        page: 0,
        panelLabel: panel.label,
        statusMap
      })

      return renderServerPage(chatId, messageId, 1)
    } catch {
      try {
        return await bot.editMessageText("❌ Gagal mengambil data server.", {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
  }

  return bot.answerCallbackQuery(q.id)
})
    
  const serverOffPages = new Map()

  bot.onText(/^\/listsrvoff$/, async (msg) => {
  const chatId = msg.chat.id

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    const pltcOk = !!(p && p.pltc && String(p.pltc).trim())
    return domainOk && pltaOk && pltcOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta/pltc kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_srvoff:${id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🖥️ <b>Server List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  async function renderServerOffPage(chatId, messageId, page) {
  const data = serverOffPages.get(chatId)
  if (!data) return

  const { servers, panelLabel } = data
  const pageSize = 10
  const totalPage = Math.max(1, Math.ceil(servers.length / pageSize))
  const safePage = Math.max(1, Math.min(page, totalPage))
  if (data.page === safePage) return

  const start = (safePage - 1) * pageSize
  const end = Math.min(start + pageSize, servers.length)

  let text = `📋 <b>Daftar Server Offline ${panelLabel}</b>\n\n`

  for (let i = start; i < end; i++) {
    const s = servers[i].attributes
    text += `ID: ${s.id}\nNama: ${s.name}\nStatus: Offline\n\n`
  }

  serverOffPages.set(chatId, { ...data, page: safePage })

  const keyboard = []
  if (safePage > 1) keyboard.push({ text: "⬅️", callback_data: "srvoff_prev" })
  keyboard.push({ text: `${safePage}/${totalPage}`, callback_data: "none" })
  if (safePage < totalPage) keyboard.push({ text: "➡️", callback_data: "srvoff_next" })

  try {
    return await bot.editMessageText(text.trim(), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [keyboard] }
    })
  } catch {}
}

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.message_id ? q.message.chat.id : null : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data === "srvoff_next" || data === "srvoff_prev") {
    const st = serverOffPages.get(chatId)
    if (!st) return bot.answerCallbackQuery(q.id)

    const totalPage = Math.max(1, Math.ceil(st.servers.length / 10))
    const newPage = data === "srvoff_next" ? Math.min(st.page + 1, totalPage) : Math.max(st.page - 1, 1)
    if (newPage === st.page) return bot.answerCallbackQuery(q.id)

    await bot.answerCallbackQuery(q.id)
    return renderServerOffPage(chatId, messageId, newPage)
  }

  if (data.startsWith("pick_srvoff:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "📋 Memuat server offline..." })

    try {
      let page = 1
      let totalPages = 1
      let servers = []

      do {
        const res = await fetch(`${panel.domain}/api/application/servers?page=${page}`, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${panel.plta}`
          }
        })

        const json = await res.json()
        if (!json || !json.data) break

        servers = servers.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      if (!servers.length) {
        try {
          return await bot.editMessageText("⚠️ Tidak ada server ditemukan.", {
            chat_id: chatId,
            message_id: messageId
          })
        } catch {}
        return
      }

      const offlineServers = []

      for (const srv of servers) {
        const uuid = srv.attributes.uuid
        try {
          const r = await fetch(`${panel.domain}/api/client/servers/${uuid}/resources`, {
            method: "GET",
            headers: {
              Authorization: `Bearer ${panel.pltc}`,
              Accept: "application/json"
            }
          })

          const d = await r.json()
          const state = d && d.attributes ? d.attributes.current_state : null
          const isOnline = state === "running" || state === "starting"
          if (!isOnline) offlineServers.push(srv)
        } catch {
          offlineServers.push(srv)
        }
      }

      if (!offlineServers.length) {
        try {
          return await bot.editMessageText(`✅ Semua server di ${panel.label} sedang online.`, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML"
          })
        } catch {}
        return
      }

      serverOffPages.set(chatId, {
        servers: offlineServers,
        page: 0,
        panelLabel: panel.label
      })

      return renderServerOffPage(chatId, messageId, 1)
    } catch (e) {
      try {
        return await bot.editMessageText(`❌ Gagal mengambil data server.\n${e && e.message ? e.message : ""}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
  }

  return bot.answerCallbackQuery(q.id)
})
    
  const adminPages = new Map()

  bot.onText(/^\/listadmin$/, async (msg) => {
  const chatId = msg.chat.id

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    return domainOk && pltaOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_admin:${id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `👤 <b>Admin List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  async function renderAdminPage(chatId, messageId, page) {
  const data = adminPages.get(chatId)
  if (!data) return

  const { admins, panelLabel } = data
  const pageSize = 10
  const totalPage = Math.max(1, Math.ceil(admins.length / pageSize))
  const safePage = Math.max(1, Math.min(page, totalPage))
  if (data.page === safePage) return

  const start = (safePage - 1) * pageSize
  const end = Math.min(start + pageSize, admins.length)

  let text = `👤 <b>Daftar Admin ${panelLabel}</b>\n\n`

  for (let i = start; i < end; i++) {
    const u = admins[i].attributes
    const uname = u.username ? `@${u.username}` : "-"
    const fullName = `${u.first_name || "-"} ${u.last_name || ""}`.trim()
    const email = u.email || "-"
    
    text += `ID: ${u.id}\nUsername: ${uname}\nNama: ${fullName}\nEmail: ${email}\n\n`
  }

  adminPages.set(chatId, { ...data, page: safePage })

  const keyboard = []
  if (safePage > 1) keyboard.push({ text: "⬅️", callback_data: "admin_prev" })
  keyboard.push({ text: `${safePage}/${totalPage}`, callback_data: "none" })
  if (safePage < totalPage) keyboard.push({ text: "➡️", callback_data: "admin_next" })

  try {
    return await bot.editMessageText(text.trim(), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [keyboard] }
    })
  } catch {}
}

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.message_id ? q.message.chat.id : null : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data === "admin_next" || data === "admin_prev") {
    const st = adminPages.get(chatId)
    if (!st) return bot.answerCallbackQuery(q.id)

    const totalPage = Math.max(1, Math.ceil(st.admins.length / 10))
    const newPage = data === "admin_next" ? Math.min(st.page + 1, totalPage) : Math.max(st.page - 1, 1)
    if (newPage === st.page) return bot.answerCallbackQuery(q.id)

    await bot.answerCallbackQuery(q.id)
    return renderAdminPage(chatId, messageId, newPage)
  }

  if (data.startsWith("pick_admin:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "👤 Memuat admin..." })

    try {
      let page = 1
      let totalPages = 1
      let users = []

      do {
        const res = await fetch(`${panel.domain}/api/application/users?page=${page}`, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${panel.plta}`
          }
        })

        const json = await res.json()
        if (!json || !json.data) break

        users = users.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      const admins = users.filter((x) => x && x.attributes && x.attributes.root_admin === true)

      if (!admins.length) {
        try {
          return await bot.editMessageText(`⚠️ Tidak ada admin ditemukan di ${panel.label}.`, {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML"
          })
        } catch {}
        return
      }

      adminPages.set(chatId, {
        admins,
        page: 0,
        panelLabel: panel.label
      })

      return renderAdminPage(chatId, messageId, 1)
    } catch (e) {
      try {
        return await bot.editMessageText(`❌ Gagal mengambil data admin.\n${e && e.message ? e.message : ""}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
  }

  return bot.answerCallbackQuery(q.id)
})
    
    const delAdminPages = new Map()

  bot.onText(/^\/deladmin(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id.toString()
  const targetId = match && match[1] ? match[1].trim() : null
  
  if (!isOwner(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Owner.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  if (!targetId) {
    return bot.sendMessage(chatId, "⚠️ Format salah.\nGunakan: /deladmin ID", {
      reply_to_message_id: msg.message_id
    })
  }

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    return domainOk && pltaOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  delAdminPages.set(chatId, { targetId, ownerUserId: userId })

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_deladmin:${id}:${targetId}:${userId}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🗑️ <b>Menghapus Admin</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (!data.startsWith("pick_deladmin:")) return

  const parts = data.split(":")
  const srvId = parts[1]
  const targetId = parts[2]
  const ownerUserId = parts[3]

  const state = delAdminPages.get(chatId)
  if (!state || String(state.ownerUserId) !== String(ownerUserId)) {
    return bot.answerCallbackQuery(q.id, { text: "Sesi sudah tidak valid." })
  }

  if (String(q.from.id) !== String(ownerUserId)) {
    return bot.answerCallbackQuery(q.id, { text: "Aksi ini bukan untuk kamu." })
  }

  const panel = PANEL_MAP[srvId]
  if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

  await bot.answerCallbackQuery(q.id, { text: "🗑️ Menghapus admin..." })

  try {
    const getRes = await fetch(`${panel.domain}/api/application/users/${targetId}`, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${panel.plta}`
      }
    })

    if (!getRes.ok) {
      let t = ""
      try { t = await getRes.text() } catch {}
      try {
        return await bot.editMessageText(`❌ User ID ${targetId} tidak ditemukan / gagal diambil.\n${t}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const getJson = await getRes.json()
    const u = getJson && getJson.attributes ? getJson.attributes : (getJson && getJson.data && getJson.data.attributes ? getJson.data.attributes : null)

    if (!u) {
      try {
        return await bot.editMessageText(`❌ Gagal membaca data user ID ${targetId}.`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    if (!u.root_admin) {
      try {
        return await bot.editMessageText(`⚠️ User ID ${targetId} bukan admin (root_admin=false).`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const delRes = await fetch(`${panel.domain}/api/application/users/${targetId}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${panel.plta}`
      }
    })

    if (!delRes.ok) {
      let t = ""
      try { t = await delRes.text() } catch {}
      try {
        return await bot.editMessageText(`❌ Gagal menghapus admin ID ${targetId}.\n${t}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    delAdminPages.delete(chatId)

    const uname = u.username ? `@${u.username}` : "-"
    const fullName = `${u.first_name || "-"} ${u.last_name || ""}`.trim()

    try {
      return await bot.editMessageText(
        `✅ *User Admin berhasil dihapus!*\n\nServer: ${panel.label}\nID: ${targetId}\nUsername: *${uname}*\nNama: *${fullName}*`,
        { parse_mode: "Markdown", chat_id: chatId, message_id: messageId }
      )
    } catch {}
    return
  } catch (e) {
    try {
      return await bot.editMessageText(`❌ Gagal menghapus admin.\n${e && e.message ? e.message : ""}`.trim(), {
        chat_id: chatId,
        message_id: messageId
      })
    } catch {}
    return
  }
})
    
  const delServerPages = new Map()

  bot.onText(/^\/delsrv(?:\s+(\d+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id.toString()
  const targetId = match && match[1] ? match[1].trim() : null
  
  if (!isOwner(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Owner.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  if (!targetId) {
    return bot.sendMessage(chatId, "⚠️ Format salah.\nGunakan: /delserver ID", {
      reply_to_message_id: msg.message_id
    })
  }

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    return domainOk && pltaOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  delServerPages.set(chatId, { targetId, ownerUserId: userId })

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_delserver:${id}:${targetId}:${userId}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🗑️ <b>Menghapus Server</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.message_id && q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (!data.startsWith("pick_delserver:")) return

  const parts = data.split(":")
  const srvId = parts[1]
  const targetId = parts[2]
  const ownerUserId = parts[3]

  const state = delServerPages.get(chatId)
  if (!state || String(state.ownerUserId) !== String(ownerUserId)) {
    return bot.answerCallbackQuery(q.id, { text: "Sesi sudah tidak valid." })
  }

  if (String(q.from.id) !== String(ownerUserId)) {
    return bot.answerCallbackQuery(q.id, { text: "Aksi ini bukan untuk kamu." })
  }

  const panel = PANEL_MAP[srvId]
  if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

  await bot.answerCallbackQuery(q.id, { text: "🗑️ Menghapus server..." })

  try {
    const getRes = await fetch(`${panel.domain}/api/application/servers/${targetId}`, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${panel.plta}`
      }
    })

    if (!getRes.ok) {
      let t = ""
      try { t = await getRes.text() } catch {}
      try {
        return await bot.editMessageText(`❌ Server ID ${targetId} tidak ditemukan / gagal diambil.\n${t}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const getJson = await getRes.json()
    const s = getJson && getJson.attributes ? getJson.attributes : (getJson && getJson.data && getJson.data.attributes ? getJson.data.attributes : null)

    if (!s) {
      try {
        return await bot.editMessageText(`❌ Gagal membaca data server ID ${targetId}.`, {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    const delRes = await fetch(`${panel.domain}/api/application/servers/${targetId}`, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${panel.plta}`
      }
    })

    if (!delRes.ok) {
      let t = ""
      try { t = await delRes.text() } catch {}
      try {
        return await bot.editMessageText(`❌ Gagal menghapus server ID ${targetId}.\n${t}`.trim(), {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }

    delServerPages.delete(chatId)

    const owner = s.user ? String(s.user) : (s.user_id ? String(s.user_id) : (s.owner_id ? String(s.owner_id) : "-"))
    const uuid = s.uuid ? s.uuid : (s.identifier ? s.identifier : "-")

    try {
      return await bot.editMessageText(
        `✅ *Server ${targetId} berhasil dihapus!*\n\nPanel: ${panel.label}\nID: ${targetId}\nNama: ${s.name || "-"}\nOwner: ${owner}\nUUID: \`${uuid}\``,
        { parse_mode: "Markdown", chat_id: chatId, message_id: messageId }
      )
    } catch {}
    return
  } catch (e) {
    try {
      return await bot.editMessageText(`❌ Gagal menghapus server.\n${e && e.message ? e.message : ""}`.trim(), {
        chat_id: chatId,
        message_id: messageId
      })
    } catch {}
    return
  }
})
    
  const listUsrPages = new Map()

  bot.onText(/^\/listusr$/i, async (msg) => {
  const chatId = msg.chat.id

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    return domainOk && pltaOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_listusr:${id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `👥 <b>User List Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  async function renderUserPage(chatId, messageId, page) {
  const data = listUsrPages.get(chatId)
  if (!data) return

  const { users, panelLabel } = data
  const pageSize = 10
  const totalPage = Math.max(1, Math.ceil(users.length / pageSize))
  const safePage = Math.max(1, Math.min(page, totalPage))
  if (data.page === safePage) return

  const start = (safePage - 1) * pageSize
  const end = Math.min(start + pageSize, users.length)

  let text = `👥 <b>Daftar User ${panelLabel}</b>\n\n`

  for (let i = start; i < end; i++) {
    const u = users[i].attributes
    const role = u.root_admin ? "Admin 👑" : "User"
    text += `ID: ${u.id}\nUsername: ${u.username || "-"}\nEmail: ${u.email || "-"}\nType: ${role}\n\n`
  }

  listUsrPages.set(chatId, { ...data, page: safePage })

  const keyboard = []
  if (safePage > 1) keyboard.push({ text: "⬅️", callback_data: "usr_prev" })
  keyboard.push({ text: `${safePage}/${totalPage}`, callback_data: "none" })
  if (safePage < totalPage) keyboard.push({ text: "➡️", callback_data: "usr_next" })

  try {
    return await bot.editMessageText(text.trim(), {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: [keyboard] }
    })
  } catch {}
}

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data === "usr_next" || data === "usr_prev") {
    const st = listUsrPages.get(chatId)
    if (!st) return bot.answerCallbackQuery(q.id)

    const totalPage = Math.max(1, Math.ceil(st.users.length / 10))
    const newPage = data === "usr_next" ? Math.min(st.page + 1, totalPage) : Math.max(st.page - 1, 1)
    if (newPage === st.page) return bot.answerCallbackQuery(q.id)

    await bot.answerCallbackQuery(q.id)
    return renderUserPage(chatId, messageId, newPage)
  }

  if (data.startsWith("pick_listusr:")) {
    const srvId = data.split(":")[1]
    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "👥 Memuat user..." })

    try {
      let page = 1
      let totalPages = 1
      let users = []

      do {
        const res = await fetch(`${panel.domain}/api/application/users?page=${page}`, {
          headers: {
            Accept: "application/json",
            Authorization: `Bearer ${panel.plta}`
          }
        })

        const json = await res.json()
        if (!json || !json.data) break

        users = users.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      if (!users.length) {
        try {
          return await bot.editMessageText("⚠️ Tidak ada user ditemukan.", {
            chat_id: chatId,
            message_id: messageId
          })
        } catch {}
        return
      }

      listUsrPages.set(chatId, {
        users,
        page: 0,
        panelLabel: panel.label
      })

      return renderUserPage(chatId, messageId, 1)
    } catch {
      try {
        return await bot.editMessageText("❌ Gagal mengambil data user.", {
          chat_id: chatId,
          message_id: messageId
        })
      } catch {}
      return
    }
  }

  return bot.answerCallbackQuery(q.id)
})
    
  const delUserOff = new Map()
  const delServerOff = new Map()

  bot.onText(/^\/delusroff$/i, async (msg) => {
  const chatId = msg.chat.id
  
  if (!isOwner(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Owner.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    return domainOk && pltaOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_deluseroff:${id}:${msg.from.id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🧹 <b>User Offline Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  bot.onText(/^\/delsrvoff$/i, async (msg) => {
  const chatId = msg.chat.id
  
  if (!isOwner(String(msg.from.id))) {
    return bot.sendMessage(chatId, "❌ Khusus *Owner.*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown"
    })
  }

  const isValidPanel = (p) => {
    const domainOk = !!(p && p.domain && String(p.domain).trim())
    const pltaOk = !!(p && p.plta && String(p.plta).trim())
    const pltcOk = !!(p && p.pltc && String(p.pltc).trim())
    return domainOk && pltaOk && pltcOk
  }

  const availableIds = ["1", "2", "3", "4", "5"].filter((id) => isValidPanel(PANEL_MAP[id]))

  if (!availableIds.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada server yang tersedia (domain/plta/pltc kosong semua).", {
      reply_to_message_id: msg.message_id
    })
  }

  const inline_keyboard = []
  for (let i = 0; i < availableIds.length; i += 2) {
    inline_keyboard.push(
      availableIds.slice(i, i + 2).map((id) => ({
        text: `Server ${id}`,
        callback_data: `pick_delserveroff:${id}:${msg.from.id}`
      }))
    )
  }

  return bot.sendMessage(chatId, `🧹 <b>Server Offline Option</b>\n${bq}<b>Choose the Server:</b>${ebq}`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { inline_keyboard }
  })
})

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  const chatId = q.message && q.message.chat ? q.message.chat.id : null
  const messageId = q.message ? q.message.message_id : null
  if (!chatId || !messageId) return

  if (data === "none") return bot.answerCallbackQuery(q.id)

  if (data.startsWith("pick_deluseroff:")) {
    const parts = data.split(":")
    const srvId = parts[1]
    const ownerTg = parts[2]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "🧹 Memuat data..." })

    try {
      let users = []
      let pageU = 1
      let totalU = 1

      do {
        const resU = await fetch(`${panel.domain}/api/application/users?page=${pageU}`, {
          headers: { Accept: "application/json", Authorization: `Bearer ${panel.plta}` }
        })
        const jsonU = await resU.json()
        if (!jsonU || !jsonU.data) break
        users = users.concat(jsonU.data)
        totalU = jsonU.meta && jsonU.meta.pagination ? jsonU.meta.pagination.total_pages : 1
        pageU++
      } while (pageU <= totalU)

      let servers = []
      let pageS = 1
      let totalS = 1

      do {
        const resS = await fetch(`${panel.domain}/api/application/servers?page=${pageS}`, {
          headers: { Accept: "application/json", Authorization: `Bearer ${panel.plta}` }
        })
        const jsonS = await resS.json()
        if (!jsonS || !jsonS.data) break
        servers = servers.concat(jsonS.data)
        totalS = jsonS.meta && jsonS.meta.pagination ? jsonS.meta.pagination.total_pages : 1
        pageS++
      } while (pageS <= totalS)

      const ownerCount = {}
      for (const s of servers) {
        const a = s.attributes
        const oid = String(a.owner_id)
        ownerCount[oid] = (ownerCount[oid] || 0) + 1
      }

      const deletable = []
      for (const u of users) {
        const a = u.attributes
        const id = String(a.id)
        const isAdmin = !!a.root_admin
        const count = ownerCount[id] || 0
        if (!isAdmin && count === 0) deletable.push(a)
      }

      const preview = deletable.slice(0, 15)
      let text = `🧹 <b>Konfirmasi Hapus User Offline</b>\n\nPanel: <b>${panel.label}</b>\nTotal kandidat: <b>${deletable.length}</b>\n\n`
      if (!deletable.length) {
        text += "✅ Tidak ada user valid yang bisa dihapus."
        try {
          return await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" })
        } catch {}
        return
      }

      for (const a of preview) {
        text += `ID: ${a.id}\nUsername: ${a.username || "-"}\nEmail: ${a.email || "-"}\n\n`
      }
      if (deletable.length > preview.length) text += `...dan ${deletable.length - preview.length} lainnya\n`

      delUserOff.set(`${chatId}:${messageId}`, {
        panelId: srvId,
        panel,
        userId: String(q.from.id),
        ids: deletable.map((x) => x.id)
      })

      return bot.editMessageText(text.trim(), {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Hapus", callback_data: `do_deluseroff:${srvId}:${q.from.id}` },
              { text: "Batal", callback_data: `cancel_deluseroff:${q.from.id}` }
            ]
          ]
        }
      })
    } catch {
      try {
        return await bot.editMessageText("❌ Gagal mengambil data user/server.", { chat_id: chatId, message_id: messageId })
      } catch {}
      return
    }
  }

  if (data.startsWith("do_deluseroff:")) {
    const parts = data.split(":")
    const srvId = parts[1]
    const ownerTg = parts[2]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    const jobKey = `${chatId}:${messageId}`
    const job = delUserOff.get(jobKey)
    if (!job || String(job.panelId) !== String(srvId)) return bot.answerCallbackQuery(q.id, { text: "Data tidak ditemukan" })

    await bot.answerCallbackQuery(q.id, { text: "🧹 Memproses..." })

    let ok = 0
    let fail = 0

    for (const id of job.ids) {
      try {
        const r = await fetch(`${job.panel.domain}/api/application/users/${id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${job.panel.plta}` }
        })
        if (r.status === 204) ok++
        else fail++
      } catch {
        fail++
      }
    }

    delUserOff.delete(jobKey)

    try {
      return await bot.editMessageText(
        `🧹 <b>User Offline dihapus!</b>\n\nServer: <b>${job.panel.label}</b>\nBerhasil: <b>${ok}</b>\nGagal: <b>${fail}</b>`,
        { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }
      )
    } catch {}
    return
  }

  if (data.startsWith("cancel_deluseroff:")) {
    const ownerTg = data.split(":")[1]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    delUserOff.delete(`${chatId}:${messageId}`)
    await bot.answerCallbackQuery(q.id, { text: "Dibatalkan" })
    try {
      return await bot.editMessageText("✅ Dibatalkan.", { chat_id: chatId, message_id: messageId })
    } catch {}
    return
  }

  if (data.startsWith("pick_delserveroff:")) {
    const parts = data.split(":")
    const srvId = parts[1]
    const ownerTg = parts[2]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    const panel = PANEL_MAP[srvId]
    if (!panel) return bot.answerCallbackQuery(q.id, { text: "Server tidak valid" })

    await bot.answerCallbackQuery(q.id, { text: "🧹 Memuat server..." })

    try {
      let servers = []
      let page = 1
      let totalPages = 1

      do {
        const res = await fetch(`${panel.domain}/api/application/servers?page=${page}`, {
          headers: { Accept: "application/json", Authorization: `Bearer ${panel.plta}` }
        })
        const json = await res.json()
        if (!json || !json.data) break
        servers = servers.concat(json.data)
        totalPages = json.meta && json.meta.pagination ? json.meta.pagination.total_pages : 1
        page++
      } while (page <= totalPages)

      if (!servers.length) {
        try {
          return await bot.editMessageText("⚠️ Tidak ada server ditemukan.", { chat_id: chatId, message_id: messageId })
        } catch {}
        return
      }

      const deletable = []
      for (const srv of servers) {
        const a = srv.attributes
        const uuid = a.uuid
        try {
          const r = await fetch(`${panel.domain}/api/client/servers/${uuid}/resources`, {
            method: "GET",
            headers: { Authorization: `Bearer ${panel.pltc}`, Accept: "application/json" }
          })
          const j = await r.json()
          const state = j && j.attributes ? j.attributes.current_state : null
          const isOnline = state === "running" || state === "starting"
          if (state && !isOnline) deletable.push({ id: a.id, name: a.name, state })
        } catch {}
      }

      const preview = deletable.slice(0, 15)
      let text = `🧹 <b>Konfirmasi Hapus Server Offline</b>\n\nPanel: <b>${panel.label}</b>\nTotal kandidat: <b>${deletable.length}</b>\n\n`

      if (!deletable.length) {
        text += "✅ Tidak ada server offline valid yang bisa dihapus."
        try {
          return await bot.editMessageText(text, { chat_id: chatId, message_id: messageId, parse_mode: "HTML" })
        } catch {}
        return
      }

      for (const s of preview) {
        text += `ID: ${s.id}\nNama: ${s.name}\nStatus: Offline\n\n`
      }
      if (deletable.length > preview.length) text += `...dan ${deletable.length - preview.length} lainnya\n`

      delServerOff.set(`${chatId}:${messageId}`, {
        panelId: srvId,
        panel,
        userId: String(q.from.id),
        ids: deletable.map((x) => x.id)
      })

      return bot.editMessageText(text.trim(), {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Hapus", callback_data: `do_delserveroff:${srvId}:${q.from.id}` },
              { text: "Batal", callback_data: `cancel_delserveroff:${q.from.id}` }
            ]
          ]
        }
      })
    } catch {
      try {
        return await bot.editMessageText("❌ Gagal mengambil data server.", { chat_id: chatId, message_id: messageId })
      } catch {}
      return
    }
  }

  if (data.startsWith("do_delserveroff:")) {
    const parts = data.split(":")
    const srvId = parts[1]
    const ownerTg = parts[2]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    const jobKey = `${chatId}:${messageId}`
    const job = delServerOff.get(jobKey)
    if (!job || String(job.panelId) !== String(srvId)) return bot.answerCallbackQuery(q.id, { text: "Data tidak ditemukan" })

    await bot.answerCallbackQuery(q.id, { text: "🧹 Memproses..." })

    let ok = 0
    let fail = 0

    for (const id of job.ids) {
      try {
        const r = await fetch(`${job.panel.domain}/api/application/servers/${id}`, {
          method: "DELETE",
          headers: { Accept: "application/json", Authorization: `Bearer ${job.panel.plta}` }
        })
        if (r.status === 204) ok++
        else fail++
      } catch {
        fail++
      }
    }

    delServerOff.delete(jobKey)

    try {
      return await bot.editMessageText(
        `🧹 <b>Server Offline dihapus!</b>\n\nPanel: <b>${job.panel.label}</b>\nBerhasil: <b>${ok}</b>\nGagal: <b>${fail}</b>`,
        { chat_id: chatId, message_id: messageId, parse_mode: "HTML" }
      )
    } catch {}
    return
  }

  if (data.startsWith("cancel_delserveroff:")) {
    const ownerTg = data.split(":")[1]
    if (String(q.from.id) !== String(ownerTg)) return bot.answerCallbackQuery(q.id, { text: "Akses ditolak" })

    delServerOff.delete(`${chatId}:${messageId}`)
    await bot.answerCallbackQuery(q.id, { text: "Dibatalkan" })
    try {
      return await bot.editMessageText("✅ Dibatalkan.", { chat_id: chatId, message_id: messageId })
    } catch {}
    return
  }

  return bot.answerCallbackQuery(q.id)
})
}