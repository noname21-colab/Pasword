const fs = require('fs');
const path = require('path');

function getFile(role) {
  return path.join(usersFile, `${role}.json`);
}

function checkFile(file) {
  if (!fs.existsSync(usersFile)) fs.mkdirSync(usersFile, { recursive: true });
  if (!fs.existsSync(file)) fs.writeFileSync(file, "[]");
}

const settings = require("../settings/config")
const { panel, bq, ebq } = settings

const {
    loadJsonData,
    saveJsonData,
    addVPS,
    getVPS
} = require("../lib/function");

const usersFile = path.resolve("./database/users");

function isUser(role, id) {
  try {
    const file = path.join(usersFile, `${role}.json`);
    if (!fs.existsSync(file)) return false;

    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (!Array.isArray(data)) return false;

    return data.includes(String(id));
  } catch {
    return false;
  }
}

function isOwner(id)  { return isUser("owner", id); }
function isPremium(id)  { return isUser("prem", id); }
function isRessVPS(id)  { return isUser("rvps", id); }
function isReseller(id) { return isUser("ress", id); }

module.exports = function (bot) {
  const doApis = [
    settings.apiDigitalOcean,
    settings.apiDigitalOcean2,
    settings.apiDigitalOcean3,
    settings.apiDigitalOcean4,
    settings.apiDigitalOcean5,
    settings.apiDigitalOcean6,
    settings.apiDigitalOcean7,
    settings.apiDigitalOcean8,
    settings.apiDigitalOcean9,
    settings.apiDigitalOcean10
  ]

  function getStatusDoMenu() {
    const buttons = []

    doApis.forEach((api, i) => {
      if (api && api !== "") {
        buttons.push({ text: `${i + 1}`, callback_data: `infodo_${i + 1}` })
      }
    })

    if (buttons.length === 0) return null

    const inline_keyboard = []
    for (let i = 0; i < buttons.length; i += 5) {
      inline_keyboard.push(buttons.slice(i, i + 5))
    }

    return inline_keyboard
  }
    
    const vpsSpecs = {
  r1c1:  { size: "s-1vcpu-1gb",        name: "Ram 1GB Core 1",  icon: "📦" },
  r2c2:  { size: "s-2vcpu-2gb",        name: "Ram 2GB Core 2",  icon: "💽" },
  r4c2:  { size: "s-2vcpu-4gb",        name: "Ram 4GB Core 2",  icon: "🖥️" },
  r8c4:  { size: "s-4vcpu-8gb",        name: "Ram 8GB Core 4",  icon: "⚙️" },
  r16c4: { size: "s-4vcpu-16gb-amd",   name: "Ram 16GB Core 4", icon: "🛠️" },
  r16c8: { size: "s-8vcpu-16gb-amd",   name: "Ram 16GB Core 8", icon: "🚀" },
  r32c8: { size: "s-8vcpu-32gb-amd",   name: "Ram 32GB Core 8", icon: "🏆" }
};

    const vpsImages = {
  ubuntu20: { image: "ubuntu-20-04-x64", name: "Ubuntu 20.04 LTS", icon: "🟠" },
  ubuntu22: { image: "ubuntu-22-04-x64", name: "Ubuntu 22.04 LTS", icon: "🔵" },
  ubuntu24: { image: "ubuntu-24-04-x64", name: "Ubuntu 24.04 LTS", icon: "🟣" },
  debian11: { image: "debian-11-x64",   name: "Debian 11", icon: "🔴" },
  debian12: { image: "debian-12-x64",   name: "Debian 12", icon: "⚪" },
  centos9: { image: "centos-stream-9-x64", name: "CentOS Stream 9", icon: "🟢" }
};

    const vpsRegions = {
  sgp1: { name: "Singapore", flag: "🇸🇬", latency: "Tercepat untuk Asia" },
  nyc1: { name: "New York", flag: "🇺🇸", latency: "USA Pantai Timur" },
  sfo3: { name: "San Francisco", flag: "🇺🇸", latency: "USA Pantai Barat" },
  lon1: { name: "London", flag: "🇬🇧", latency: "Eropa Barat" },
  fra1: { name: "Frankfurt", flag: "🇩🇪", latency: "Eropa Tengah" },
  ams3: { name: "Amsterdam", flag: "🇳🇱", latency: "Eropa Barat" },
  tor1: { name: "Toronto", flag: "🇨🇦", latency: "Amerika Utara" },
  blr1: { name: "Bangalore", flag: "🇮🇳", latency: "Asia Selatan" }
};

    async function createVPSDroplet(apiKey, hostname, spec, os, region, password) {
  const dropletData = {
    name: hostname.toLowerCase().trim(),
    region,
    size: vpsSpecs[spec].size,
    image: vpsImages[os].image,
    ssh_keys: null,
    backups: false,
    ipv6: true,
    user_data: `#cloud-config\npassword: ${password}\nchpasswd: { expire: False }\nssh_pwauth: True`,
    private_networking: null,
    volumes: null,
    tags: ["AnggaDev-VPS", "pay-tama.vercel.app", new Date().toISOString().split("T")[0]]
  };

  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    },
    body: JSON.stringify(dropletData)
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to create VPS");
  return data.droplet.id;
}

    async function getDropletIP(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Failed to fetch droplet info");
  return data.droplet.networks.v4.find(net => net.type === "public").ip_address;
}

    async function getDropletInfo(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || `Gagal ambil info VPS (HTTP ${response.status})`);
  }

  return data.droplet;
}
    
    async function deleteVPS(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    method: "DELETE",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message || `Gagal delete VPS (HTTP ${response.status})`);
  }

  return true;
}

    async function getAllVPS(apiKey) {
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });
  const data = await response.json();
  return data.droplets || [];
}

    async function getListVps(apiKey) {
  const response = await fetch("https://api.digitalocean.com/v2/droplets", {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil daftar VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplets || [];
}

    async function getVpsDetail(apiKey, dropletId) {
  const response = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`
    }
  });

  if (!response.ok) {
    throw new Error(`Gagal ambil detail VPS: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();
  return data.droplet;
}

    function formatVPSStatus(status) {
  if (status === "active") return "🟢 Active"
  if (status === "off") return "🔴 Off"
  return "⚪ " + status
}

    function formatUptime(createdAt) {
  const created = new Date(createdAt)
  const now = new Date()
  const diffMs = now - created
  const diffHrs = Math.floor(diffMs / 3600000)
  const diffDays = Math.floor(diffHrs / 24)
  return diffDays > 0 ? `${diffDays}d ${diffHrs % 24}h` : `${diffHrs}h`
}
    
  global.pendingRebuild = {}

  global.pendingRebuild = global.pendingRebuild || {}

  bot.onText(/^\/rebuild (.+)$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const args = match[1].split(",")
  const apiKey = (args[0] || "").trim()
  const dropletId = (args[1] || "").trim()

  if (!apiKey || !dropletId) return bot.sendMessage(chatId, "❌ Format salah\n/rebuild apiKey,idDroplet")

  try {
    const info = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      }
    })

    if (!info.ok) return bot.sendMessage(chatId, "Droplet tidak ditemukan")

    const j = await info.json()
    const d = j.droplet
    const ip4 = d.networks.v4.find(n => n.type === "public")?.ip_address || "-"

    const teks =
`☁️ <b>Cloud VPS Detail</b>

IP VPS: ${ip4}
Droplet ID: ${d.id}
Hostname: ${d.name}
Region: ${d.region.slug}
${d.image.slug}`

    const sessionId = "rb_" + Date.now()

    const keyboard = {
      inline_keyboard: [
        [
          { text: "Ubuntu 24.04", callback_data: sessionId + "|u24" },
          { text: "Ubuntu 22.04", callback_data: sessionId + "|u22" }
        ],
        [
          { text: "Ubuntu 20.04", callback_data: sessionId + "|u20" },
          { text: "Ubuntu 18.04", callback_data: sessionId + "|u18" }
        ],
        [
          { text: "Ubuntu 16.04", callback_data: sessionId + "|u16" }
        ]
      ]
    }

    const sent = await bot.sendMessage(chatId, teks, {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: keyboard
    })

    global.pendingRebuild[sessionId] = { apiKey, dropletId, menuMessageId: sent.message_id }
  } catch (e) {
    bot.sendMessage(chatId, "Error: " + e)
  }
})

  bot.on("callback_query", async (query) => {
  const data = query.data
  const chatId = query.message.chat.id

  if (!data.startsWith("rb_")) return

  const [sessionId, code] = data.split("|")
  const session = global.pendingRebuild[sessionId]

  if (!session) return bot.answerCallbackQuery(query.id, { text: "Session expired" })

  await bot.answerCallbackQuery(query.id)

  try {
    await bot.deleteMessage(chatId, session.menuMessageId || query.message.message_id)
  } catch (e) {}

  const apiKey = session.apiKey
  const dropletId = session.dropletId

  const imageMap = {
    u24: "ubuntu-24-04-x64",
    u22: "ubuntu-22-04-x64",
    u20: "ubuntu-20-04-x64",
    u18: "ubuntu-18-04-x64",
    u16: "ubuntu-16-04-x64"
  }

  const imageSlug = imageMap[code]
  if (!imageSlug) return bot.sendMessage(chatId, "Pilihan image tidak valid.")

  try {
    await bot.sendMessage(chatId, `🔧 Memulai rebuild...\nImage: ${imageSlug}`)

    const rebuild = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}/actions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      },
      body: JSON.stringify({ type: "rebuild", image: imageSlug })
    })

    const r = await rebuild.json()

    if (!rebuild.ok) return bot.sendMessage(chatId, "Gagal rebuild: " + r.message)

    await bot.sendMessage(chatId, "Rebuild dimulai. Tunggu 60 detik...")

    await new Promise(res => setTimeout(res, 60000))

    const info = await fetch(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + apiKey
      }
    })

    const j = await info.json()
    const d = j.droplet
    const ip4 = d.networks.v4.find(n => n.type === "public")?.ip_address || "-"

    const hasil =
`✅ Rebuild selesai
IP VPS: ${ip4}
${d.image.slug}`

    bot.sendMessage(chatId, hasil)

    delete global.pendingRebuild[sessionId]
  } catch (e) {
    bot.sendMessage(chatId, "Error: " + e)
  }
})

  const createVpsState = new Map();
  const setCreateVpsState = (u, d) => createVpsState.set(u, d);
  const getCreateVpsState = (u) => createVpsState.get(u);
  const clearCreateVpsState = (u) => createVpsState.delete(u);

  bot.onText(/^\/createvps$/, async (msg) => {
  if (!isRessVPS(msg.from.id)) {
    return bot.sendMessage(msg.chat.id, "❌ *Khusus Reseller VPS!*", {
      reply_to_message_id: msg.message_id,
      parse_mode: "Markdown",
    });
  }

  const accounts = [
    { id: "1", key: settings.apiDigitalOcean },
    { id: "2", key: settings.apiDigitalOcean2 },
    { id: "3", key: settings.apiDigitalOcean3 },
    { id: "4", key: settings.apiDigitalOcean4 },
    { id: "5", key: settings.apiDigitalOcean5 },
  ];

  const available = accounts.filter((a) =>
    typeof a.key === "string" ? a.key.trim() !== "" : !!a.key
  );

  if (available.length === 0) {
    return bot.sendMessage(msg.chat.id, "❌ Tidak ada API DigitalOcean yang terisi di settings.", {
      reply_to_message_id: msg.message_id,
    });
  }

  clearCreateVpsState(msg.from.id.toString());

  const keyboard = [
    available.map((a) => ({
      text: a.id,
      callback_data: `createvps_${a.id}_${msg.from.id}`,
    })),
  ];

  bot.sendMessage(
    msg.chat.id,
    `📡 <b>Menu Create VPS</b>

${bq}<b>ℹ Statistik:</b>${ebq}
• Droplet Size (CPU, RAM, Storage)
• Region & Datacenter
• Operating System Image

${bq}<b>Choose the Account:</b>${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: keyboard },
    }
  );
});

  bot.on("callback_query", async (cb) => {
  const chatId = cb.message.chat.id;
  const data = cb.data;
  const senderId = cb.from.id.toString();

  if (data.startsWith("createvps_") && data.split("_").length === 3) {
    const accId = data.split("_")[1];
    const cbUserId = data.split("_")[2];
    if (cbUserId !== senderId) return bot.answerCallbackQuery(cb.id).catch(() => {});

    const keyboard = Object.entries(vpsSpecs).map(([id, spec]) => [
      { text: `${spec.name}`, callback_data: `spec_${accId}_${id}_${senderId}` },
    ]);

    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return bot.editMessageText(
      `📡 <b>Menu Create VPS</b>

${bq}<b>ℹ Statistik:</b>${ebq}
• Droplet Size (CPU, RAM, Storage)
• Region & Datacenter
• Operating System Image

${bq}<b>Spesifikasi VPS:</b>${ebq}`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: keyboard },
      }
    );
  }

  if (data.startsWith("spec_") && data.split("_").length === 4) {
    const [_, accId, specId, cbUserId] = data.split("_");
    if (cbUserId !== senderId) return bot.answerCallbackQuery(cb.id).catch(() => {});
    const spec = vpsSpecs[specId];

    const keyboard = Object.entries(vpsImages).map(([id, img]) => [
      { text: `${img.name}`, callback_data: `image_${accId}_${specId}_${id}_${senderId}` },
    ]);

    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return bot.editMessageText(`📦 Spesifikasi VPS\n*${spec.name}*\n\nSekarang pilih OS image:`, {
      chat_id: chatId,
      message_id: cb.message.message_id,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard },
    });
  }

  if (data.startsWith("image_") && data.split("_").length === 5) {
    const [_, accId, specId, imageId, cbUserId] = data.split("_");
    if (cbUserId !== senderId) return bot.answerCallbackQuery(cb.id).catch(() => {});
    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];

    const keyboard = Object.entries(vpsRegions).map(([id, reg]) => [
      { text: `${reg.flag} ${reg.name}`, callback_data: `region_${accId}_${specId}_${imageId}_${id}_${senderId}` },
    ]);

    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return bot.editMessageText(
      `📦 Spesifikasi VPS\n*${spec.name}*\n💿 Image: *${img.name}*\n\nSekarang pilih region:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard },
      }
    );
  }

  if (data.startsWith("region_") && data.split("_").length === 6) {
    const [_, accId, specId, imageId, regionId, cbUserId] = data.split("_");
    if (cbUserId !== senderId) return bot.answerCallbackQuery(cb.id).catch(() => {});

    const spec = vpsSpecs[specId];
    const img = vpsImages[imageId];
    const reg = vpsRegions[regionId];

    let apiKey;
    if (accId === "1") apiKey = settings.apiDigitalOcean;
    if (accId === "2") apiKey = settings.apiDigitalOcean2;
    if (accId === "3") apiKey = settings.apiDigitalOcean3;
    if (accId === "4") apiKey = settings.apiDigitalOcean4;
    if (accId === "5") apiKey = settings.apiDigitalOcean5;

    setCreateVpsState(senderId, {
      step: "hostname",
      chatId,
      msgId: cb.message.message_id,
      specId,
      imageId,
      regionId,
      accId,
    });

    await bot.answerCallbackQuery(cb.id).catch(() => {});
    return bot.editMessageText(
      `✅ Spesifikasi dipilih\n\n📦 *${spec.name}*\n💿 *${img.name}*\n🌍 ${reg.flag} *${reg.name}*\n\nSilahkan ketik hostname:`,
      {
        chat_id: chatId,
        message_id: cb.message.message_id,
        parse_mode: "Markdown",
      }
    );
  }
});

  bot.on("message", async (msg) => {
      const senderId = msg.from?.id?.toString()
      if (!senderId) return

  const state = getCreateVpsState(senderId)
  if (!state) return

  if (!msg.text || msg.text.startsWith("/")) return
  if (state.step !== "hostname") return

  const chatId = state.chatId
  const hostname = msg.text.trim().toLowerCase()

  if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/.test(hostname)) {
    return bot.sendMessage(
      chatId,
      "❌ Hostname tidak valid.\nGunakan huruf/angka/minus, tidak boleh diawali/diakhiri minus.\nContoh: my-vps-01",
      { reply_to_message_id: msg.message_id }
    )
  }

  const spec = vpsSpecs[state.specId]
  const img = vpsImages[state.imageId]
  const reg = vpsRegions[state.regionId]

  let apiKey
  if (state.accId === "1") apiKey = settings.apiDigitalOcean
  if (state.accId === "2") apiKey = settings.apiDigitalOcean2
  if (state.accId === "3") apiKey = settings.apiDigitalOcean3
  if (state.accId === "4") apiKey = settings.apiDigitalOcean4
  if (state.accId === "5") apiKey = settings.apiDigitalOcean5

  clearCreateVpsState(senderId)

  const loadingMsg = await bot.sendMessage(
    chatId,
    `📡 <i>Memulai create VPS...</i>`,
    { parse_mode: "HTML", reply_to_message_id: msg.message_id }
  )

  try {
    const password = Math.random().toString(36).slice(-10)

    const dropletId = await createVPSDroplet(
      apiKey,
      hostname,
      state.specId,
      state.imageId,
      state.regionId,
      password
    )

    const getIpAddress = async () => {
      const droplet = await getDropletInfo(apiKey, dropletId)
      return droplet?.networks?.v4?.find(n => n.type === "public")?.ip_address || null
    }

    let ipAddress = null
    while (!ipAddress) {
      await new Promise(res => setTimeout(res, 5000))
      ipAddress = await getIpAddress()
    }

    addVPS(dropletId, {
      hostname,
      dropletId,
      ip: ipAddress,
      spec: spec.name,
      os: img.name,
      region: `${reg.flag} ${reg.name}`,
      password,
      owner: chatId
    })

    await bot.sendPhoto(chatId, panel, {
      caption: `✅ <b>Sukses create VPS!</b>

<blockquote>☁️ <b>Cloud VPS Detail:</b></blockquote>
IP VPS: <code>${ipAddress}</code>
Password: <code>${password}</code>
Hostname: <code>${hostname}</code>
Droplet: <code>${dropletId}</code>

<blockquote>📡 <b>Statistik VPS Detail:</b></blockquote>
Spec: ${spec.name}
OS: ${img.name}
Region: ${reg.flag} ${reg.name}

<blockquote><code>root@${ipAddress}:22</code></blockquote>`,
      parse_mode: "HTML"
    })

    await bot.deleteMessage(chatId, loadingMsg.message_id)

  } catch (err) {
    await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {})
    await bot.sendMessage(chatId, `❌ Gagal membuat VPS\n\nError: ${err.message}`)
  }
})

  bot.onText(/^\/delvps (.+)$/, async (msg, match) => {
  const chatId = msg.chat.id
  const dropletId = (match[1] || "").trim()
  
  if (!isRessVPS(msg.from.id)) {
    return bot.sendMessage(
      msg.chat.id,
      "❌ *Khusus Reseller VPS!*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  if (!dropletId) {
    return bot.sendMessage(chatId, "❌ ID VPS tidak valid")
  }

  const keyboard = []
  let row = []

  for (let i = 0; i < doApis.length; i++) {
    if (!doApis[i]) continue

    row.push({ text: `${i + 1}`, callback_data: `delvpsacc_${i + 1}_${dropletId}` })

    if (row.length === 3) {
      keyboard.push(row)
      row = []
    }
  }

  if (row.length) keyboard.push(row)

  if (keyboard.length === 0) {
    return bot.sendMessage(chatId, "❌ Tidak ada API DigitalOcean yang aktif")
  }

  bot.sendMessage(chatId, `🗑️ <b>Menu Delete VPS</b>
Droplet ID: <code>${dropletId}</code>

${bq}<b>⚠️ Warning:</b>${ebq}
• Tagihan akan berhenti
• Semua file dan data hilang
• Tidak dapat dikembalikan

${bq}<b>Choose the Account:</b>${ebq}
`, {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: { 
      inline_keyboard: keyboard 
    }
  })
})

  bot.on("callback_query", async (cbq) => {
  const chatId = cbq.message?.chat?.id
  const data = cbq.data || ""
  if (!chatId) return

  if (data.startsWith("delvpsacc_")) {
    const parts = data.split("_")
    const accIndex = parseInt(parts[1], 10)
    const dropletId = parts[2]

    const apiKey = doApis[accIndex - 1]
    if (!apiKey) {
      try { await bot.answerCallbackQuery(cbq.id, { text: "API Key belum diatur!" }) } catch {}
      return
    }

    try {
      const vps = await getDropletInfo(apiKey, dropletId)

      const confirmMsg = [
        `⚠️ *Konfirmasi Delete VPS*`,
        ``,
        `🖥️ Name: *${vps.name}*`,
        `🆔 ID: \`${dropletId}\``,
        `🌐 IP: \`${vps.networks?.v4?.[0]?.ip_address || "No IP"}\``,
        ``,
        `❗ *Warning:*`,
        `• Semua data akan hilang permanen`,
        `• VPS tidak dapat dikembalikan`,
        `• Proses delete tidak bisa dibatalkan`,
        ``,
        `Yakin ingin menghapus VPS ini?`
      ].join("\n")

      bot.sendMessage(chatId, confirmMsg, {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "✅ Ya, Hapus", callback_data: `confirmdel_${accIndex}_${dropletId}` },
              { text: "❌ Batal", callback_data: "canceldelete" }
            ]
          ]
        }
      })
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal ambil info VPS\n\n🧾 Error: ${err.message}`)
    }
  }

  if (data.startsWith("confirmdel_")) {
    const parts = data.split("_")
    const accIndex = parseInt(parts[1], 10)
    const dropletId = parts[2]

    const apiKey = doApis[accIndex - 1]
    if (!apiKey) {
      try { await bot.answerCallbackQuery(cbq.id, { text: "API Key belum diatur!" }) } catch {}
      return
    }

    try {
      await deleteVPS(apiKey, dropletId)
      bot.sendMessage(chatId, `✅ Droplet ID \`${dropletId}\` berhasil dihapus`, { parse_mode: "Markdown" })
    } catch (err) {
      bot.sendMessage(chatId, `❌ Gagal delete VPS\n\n🧾 Error: ${err.message}`)
    }
  }

  if (data === "canceldelete") {
    bot.sendMessage(chatId, "❌ Delete VPS dibatalkan.")
  }

  bot.answerCallbackQuery(cbq.id).catch(() => {})
})

  bot.onText(/^\/listvps$/, async msg => {
  const chatId = msg.chat.id
  
  if (!isRessVPS(msg.from.id)) {
    return bot.sendMessage(
      msg.chat.id,
      "❌ *Khusus Reseller VPS!*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  const keyboard = []
  let row = []

  for (let i = 0; i < doApis.length; i++) {
    if (!doApis[i]) continue

    row.push({ text: `${i + 1}`, callback_data: `listdo_${i + 1}` })

    if (row.length === 3) {
      keyboard.push(row)
      row = []
    }
  }

  if (row.length) keyboard.push(row)

  if (keyboard.length === 0) {
    return bot.sendMessage(chatId, "❌ Tidak ada API DigitalOcean yang aktif")
  }

  await bot.sendMessage(
    chatId,
    `<b>📋 Menu List VPS</b>

${bq}<b>ℹ Statistik:</b>${ebq}
• Menampilkan semua droplet aktif
• Real time data update
• Status, Spesifikasi dan IP

${bq}<b>Choose the Account:</b>${ebq}`,
    {
      parse_mode: "HTML",
      reply_to_message_id: msg.message_id,
      reply_markup: { inline_keyboard: keyboard }
    }
  )
})

  bot.on("callback_query", async query => {
  const chatId = query.message?.chat?.id
  const messageId = query.message?.message_id
  const data = query.data || ""
  if (!chatId || !messageId) return

  if (data.startsWith("listdo_")) {
    const accId = parseInt(data.split("_")[1], 10)
    const apiKey = doApis[accId - 1]

    if (!apiKey) {
      try { await bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!" }) } catch {}
      return
    }

    try {
      await bot.editMessageText("🔍 Mengambil daftar VPS...", {
        chat_id: chatId,
        message_id: messageId
      })

      const droplets = await getListVps(apiKey)

      if (!droplets.length) {
        return bot.editMessageText("📭 Tidak ada VPS.", {
          chat_id: chatId,
          message_id: messageId
        })
      }

      const keyboard = droplets.map(vps => {
        const ip = vps.networks?.v4?.find(n => n.type === "public")?.ip_address || "No IP"
        const region = vpsRegions[vps.region.slug] || { flag: "🏳️", name: "Unknown" }
        const status = formatVPSStatus(vps.status)
        const uptime = formatUptime(vps.created_at)

        return [{
          text: `🖥️ ${vps.name} | ${status} | ${region.flag} ${region.name} | ${ip} | ${uptime}`,
          callback_data: `vpsinfo_${accId}_${vps.id}`
        }]
      })

      await bot.editMessageText(
        `🛰️ *Monitoring Vps*\n\n📊 Total VPS: *${droplets.length}*\nSilahkan klik untuk detail:`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: keyboard }
        }
      )
    } catch (err) {
      console.error("[LIST VPS ERROR]", err)
      bot.sendMessage(chatId, `❌ Gagal ambil daftar VPS\n\n🧾 Error: ${err.message}`)
    }
  }

  if (data.startsWith("vpsinfo_")) {
    const [, accId, dropletId] = data.split("_")
    const apiKey = doApis[accId - 1]

    if (!apiKey) {
      try { await bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!" }) } catch {}
      return
    }

    try {
      const droplet = await getVpsDetail(apiKey, dropletId)

      const ip = droplet?.networks?.v4?.find(n => n.type === "public")?.ip_address || "Belum tersedia"
      const region = vpsRegions[droplet?.region?.slug] || { flag: "🏳️", name: "Unknown" }
      const status = formatVPSStatus(droplet?.status)
      const uptime = droplet?.created_at ? formatUptime(droplet.created_at) : "Belum tersedia"

      const info = [
        `🖥️ *${droplet?.name || "Unknown"}*`,
        ``,
        `🆔 ID: \`${droplet?.id || "???"}\``,
        `🌐 IP: \`${ip}\``,
        `📦 Spec: ${droplet?.size_slug || "???"}`,
        `🖥️ OS: ${droplet?.image?.distribution || "???"} ${droplet?.image?.name || ""}`,
        `🌍 Region: ${region.flag} ${region.name}`,
        `📡 Status: ${status}`,
        `⏱️ Uptime: ${uptime}`
      ].join("\n")

      await bot.sendMessage(chatId, info, { parse_mode: "Markdown" })
    } catch (err) {
      console.error("[VPS DETAIL ERROR]", err)
      bot.sendMessage(chatId, `❌ Gagal ambil detail VPS\n\n🧾 Error: ${err.message}`)
    }
  }

  try { await bot.answerCallbackQuery(query.id) } catch {}
})
    
  bot.onText(/^\/statusdo$/, async (msg) => {
    const chatId = msg.chat.id
    const inline_keyboard = getStatusDoMenu()
    
    if (!isRessVPS(msg.from.id)) {
    return bot.sendMessage(
      msg.chat.id,
      "❌ *Khusus Reseller VPS!*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

    if (!inline_keyboard) {
      return bot.sendMessage(chatId, "❌ Tidak ada API DigitalOcean yang aktif")
    }

    return bot.sendMessage(
     chatId,
      `🌐 <b>Menu Status DO</b>

${bq}<b>ℹ Statistik:</b>${ebq}
• Total droplet aktif
• Limit API Requests
• Status Billing API

${bq}<b>Choose the Account:</b>${ebq}`,
      {
        reply_to_message_id: msg.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard }
      }
    )
  })

  bot.on("callback_query", async (query) => {
    const data = query.data || ""
    const chatId = query.message?.chat?.id
    const messageId = query.message?.message_id
    if (!chatId || !messageId) return
    if (!data.startsWith("infodo_") && data !== "back_statusdo") return

    const safeAnswer = async () => {
      try {
        await bot.answerCallbackQuery(query.id)
      } catch {}
    }

    if (data === "back_statusdo") {
      const keyboard = getStatusDoMenu()
      if (!keyboard) {
        await safeAnswer()
        return bot.editMessageText("❌ Tidak ada API DigitalOcean yang aktif", {
          chat_id: chatId,
          message_id: messageId
        })
      }

      await safeAnswer()
      return bot.editMessageText(
        `🌐 <b>Menu Status DO</b>

${bq}<b>ℹ Statistik:</b>${ebq}
• Total droplet aktif
• Limit API Requests
• Status Billing API

${bq}<b>Choose the Account:</b>${ebq}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: keyboard }
        }
      )
    }

    const n = parseInt(data.split("_")[1], 10)
    const apiKey = Number.isFinite(n) ? doApis[n - 1] : null

    if (!apiKey) {
      try {
        await bot.answerCallbackQuery(query.id, { text: "API Key belum diatur!" })
      } catch {}
      return
    }

    try {
      try {
        await bot.answerCallbackQuery(query.id, { text: "📋 Memuat..." })
      } catch {}

      const [accountRes, dropletRes] = await Promise.all([
        fetch("https://api.digitalocean.com/v2/account", {
          headers: { Authorization: `Bearer ${apiKey}` }
        }),
        fetch("https://api.digitalocean.com/v2/droplets", {
          headers: { Authorization: `Bearer ${apiKey}` }
        })
      ])

      const account = await accountRes.json()
      const droplets = await dropletRes.json()

      if (!account?.account?.email) {
        return bot.editMessageText("❌ API Key tidak valid!", {
          chat_id: chatId,
          message_id: messageId
        })
      }

      const limit = account.account.droplet_limit || 0
      const active = Array.isArray(droplets?.droplets) ? droplets.droplets.length : 0
      const sisa = limit - active

      let msgText = `${bq}🌐 <b>Status Akun: ${account.account.status}</b>${ebq}\n`
      msgText += `Total Droplet: ${limit}\n`
      msgText += `VPS Aktif: ${active}\n`
      msgText += `${bq}💰 Sisa Droplet: <b>${sisa}</b>${ebq}`

      return bot.editMessageText(msgText, {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [[{ text: "Back", callback_data: "back_statusdo" }]]
        }
      })
    } catch {
      return bot.editMessageText("⚠️ Gagal mengambil data dari DigitalOcean", {
        chat_id: chatId,
        message_id: messageId
      })
    }
  })
}