const fs = require("fs");
const { NodeSSH } = require("node-ssh");
const { Client } = require("ssh2");
const path = require("path");
const ssh = new NodeSSH();

const settings = require("../settings/config");
const {
    panel,
    bq,
    ebq
} = settings;

const protectDescriptions = {
  1: {
    title: "Anti Edit Settings",
    desc: [
      "Mengunci menu Settings",
      "Hanya Admin ID 1 yang dapat mengubah konfigurasi panel"
    ]
  },
  2: {
    title: "Anti Edit Users",
    desc: [
      "Mencegah user mengedit data user lain",
      "Proteksi penuh menu Users"
    ]
  },
  3: {
    title: "Anti Intip Locations",
    desc: [
      "Mengunci menu Locations",
      "User selain Admin ID 1 akan diblokir (403)"
    ]
  },
  4: {
    title: "Anti Intip Nodes",
    desc: [
      "Menutup akses menu Nodes",
      "Node hanya terlihat oleh Admin utama"
    ]
  },
  5: {
    title: "Anti Intip Nests",
    desc: [
      "Melindungi menu Nests",
      "User biasa tidak bisa melihat Egg & Nest"
    ]
  },
  6: {
    title: "Anti Edit Panel Settings",
    desc: [
      "Mengunci seluruh menu Settings panel",
      "Mencegah sabotase konfigurasi"
    ]
  },
  7: {
    title: "Anti Akses File Server",
    desc: [
      "Mencegah akses file server orang lain",
      "Anti download, edit, rename file ilegal"
    ]
  },
  8: {
    title: "Anti Intip Server",
    desc: [
      "Server hanya bisa diakses owner",
      "Anti intip detail server user lain"
    ]
  },
  9: {
    title: "Anti Intip Application API",
    desc: [
      "Mengunci menu Application API",
      "Khusus Admin ID 1 create & delete API"
    ]
  },
  10: {
    title: "Anti Create Client API Key",
    desc: [
      "Mencegah user membuat Client API Key",
      "API Key hanya untuk Admin utama"
    ]
  },
  11: {
    title: "Anti Intip Database",
    desc: [
      "Mengunci menu Database",
      "User lain tidak bisa melihat DB Host"
    ]
  },
  12: {
    title: "Anti Intip Mounts",
    desc: [
      "Melindungi menu Mounts",
      "Mount hanya bisa dikelola Admin utama"
    ]
  },
  13: {
    title: "Anti Button Two Factor",
    desc: [
      "Menutup akses pengaturan 2FA",
      "Hanya Admin ID 1 bisa enable / disable"
    ]
  },
  14: {
    title: "Hide Menu Admin",
    desc: [
      "Menyembunyikan menu sensitif Admin",
      "Nodes, Locations, API, DB tidak terlihat user"
    ]
  }
}

const installProtect = {
  1: require("../handlers/installprotect1"),
  2: require("../handlers/installprotect2"),
  3: require("../handlers/installprotect3"),
  4: require("../handlers/installprotect4"),
  5: require("../handlers/installprotect5"),
  6: require("../handlers/installprotect6"),
  7: require("../handlers/installprotect7"),
  8: require("../handlers/installprotect8"),
  9: require("../handlers/installprotect9"),
  10: require("../handlers/installprotect10"),
  11: require("../handlers/installprotect11"),
  12: require("../handlers/installprotect12"),
  13: require("../handlers/installprotect13"),
  14: require("../handlers/installprotect14"),
}

const uninstallProtect = {
  1: require("../handlers/uninstallprotect1")
}

const userStates = new Map();
function isValidIP(ip) {
  if (typeof ip !== "string") return false;
  
  const ipv4Regex = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  return ipv4Regex.test(ip.trim());
}

module.exports = function (bot) {
  const startWingsMs = 2 * 60 * 1000;
    
  function makeLiveStatus(bot, chatId, replyToMessageId) {
  let messageId = null;
  let buffer = "";
  let lastEdit = 0;

  async function start(title) {
    const sent = await bot.sendMessage(
      chatId,
      `${title}\n<pre>Memulai proses...</pre>`,
      {
        reply_to_message_id: replyToMessageId,
        parse_mode: "HTML"
      }
    ).catch(() => null);
    messageId = sent?.message_id || null;
  }

  async function push(line) {
    if (!messageId) return;
    buffer += line + "\n";
    const now = Date.now();
    if (now - lastEdit < 3000) return;
    lastEdit = now;

    await bot.editMessageText(
      `📡 Memulai instalasi panel...\n<pre>${buffer.slice(-3000)}</pre>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    ).catch(() => {});
  }

  async function done(text) {
    if (!messageId) return;
    await bot.editMessageText(
      `${text}\n<pre>${buffer.slice(-3000)}</pre>`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    ).catch(() => {});
  }

  return { start, push, done };
}

  async function installPanel(msg, ip, password, domainpanel) {
  const chatId = msg.chat.id;
    
  const live = makeLiveStatus(bot, chatId, msg.message_id);
    await live.start("📡 Memulai instalasi panel...");
  return new Promise((resolve, reject) => {
    const conn = new Client();
    const rand = Math.floor(1000 + Math.random() * 9000);
    const namaAcak = `admin${rand}`;
    const emailAcak = `admin${rand}@gmail.com`;
    const passPanel = `${rand}`;

    bot.sendMessage(chatId, `🔧 Memulai installasi Panel VPS ${ip} (domain: ${domainpanel}). Silahkan tunggu 10-25 menit.`).catch(()=>{});

    let completed = false;

    conn.on('ready', () => {
      console.log(`[panel][${ip}] SSH connected, starting installer`);
      conn.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
        if (err) {
          console.error(`[panel][${ip}] exec error:`, err);
          conn.end();
          bot.sendMessage(chatId, `❌ Gagal menjalankan installer Panel di ${ip}: ${err.message}`).catch(()=>{});
          return reject(err);
        }

        stream.on('data', (data) => {
          const out = data.toString();
          live.push(data.toString());
         
          try {
            if (out.includes("Input 0-6")) stream.write("0\n");
            if (out.includes("Database name (panel)")) stream.write(`${namaAcak}\n`);
            if (out.includes("Database username (pterodactyl)")) stream.write(`${namaAcak}\n`);
            if (out.includes("Password (press enter")) stream.write("\n");
            if (out.includes("Select timezone")) stream.write("Asia/Jakarta\n");
            if (out.includes("Provide the email address")) stream.write(`${emailAcak}\n`);
            if (out.includes("Email address for the initial admin account")) stream.write(`${emailAcak}\n`);
            if (out.includes("Username for the initial admin account")) stream.write(`${namaAcak}\n`);
            if (out.includes("First name for the initial admin account")) stream.write(`${namaAcak}\n`);
            if (out.includes("Last name for the initial admin account")) stream.write(`${namaAcak}\n`);
            if (out.includes("Password for the initial admin account")) stream.write(`${passPanel}\n`);
            if (out.includes("Set the FQDN")) stream.write(`${domainpanel}\n`);
            if (out.includes("(y/N)")) stream.write("y\n");
            if (out.includes("Enable sending anonymous telemetry")) stream.write("yes\n");
            if (out.includes("(Y)es/(N)o")) stream.write("Y\n");
          } catch (e) {
          }

          process.stdout.write(`[panel:${ip}] ${out}`);
        });

        stream.stderr.on('data', (data) => {
          const out = data.toString();
          process.stderr.write(`[panel:${ip}][ERR] ${out}`);
        });

        stream.on('close', async (code) => {
  completed = true;
  conn.end();

  if (code === 0) {
    await live.done("✅ Instalasi panel selesai");
    await bot.sendMessage(chatId, `📦 *Sukses install Panel!*

*📌 IP VPS:* \`${ip}\`
*🔑 Password:* \`${password}\`
*🌐 Login:* [Klik Disini](https://${domainpanel})

*👤 Admin:* \`${namaAcak}\`
*🔐 Password:* \`${passPanel}\`
*✉ Email:* ${emailAcak}`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id }).catch(()=>{});
    return resolve({ ok: true, ip, type: "panel", domain: domainpanel, user: namaAcak, pass: passPanel });
  } else {
    await live.done("❌ Instalasi panel gagal");
    await bot.sendMessage(chatId, `❌ Installer Panel selesai dengan kode ${code} pada ${ip}.`).catch(()=>{});
    return resolve({ ok: false, ip, type: "panel", code });
  }
});
      });
    }).on('error', (err) => {
      if (!completed) {
        console.error(`[panel][${ip}] SSH connection error:`, err);
        bot.sendMessage(chatId, `❌ Gagal koneksi SSH ke ${ip}: ${err.message}`).catch(()=>{});
        return reject(err);
      }
    }).connect({
      host: ip,
      port: 22,
      username: 'root',
      password: password,
      readyTimeout: 20000
    });
  });
}

  function installWings(msg, ip, password, domainpanel, domainnode) {
  const chatId = msg?.chat?.id || null;
  const messageId = msg?.message_id || null;

  return new Promise((resolve, reject) => {
    const conn = new Client();
    const rand = Math.floor(1000 + Math.random() * 9000);
    const emailAcak = `admin${rand}@gmail.com`;
    const userDB = `dbuser${Math.floor(1000 + Math.random() * 9000)}`;
    const passDB = `${Math.floor(1000 + Math.random() * 9000)}`;

    if (chatId) {
      bot.sendMessage(chatId, `🔧 Memulai instalasi Wings di ${ip} (node: ${domainnode}). Silahkan tunggu 5-15 menit.`).catch(() => {});
    } else {
      console.log(`[wings][${ip}] Memulai instalasi Wings (no chat context)`);
    }

    let completed = false;

    conn.on('ready', () => {
      console.log(`[wings][${ip}] SSH connected, starting installer`);
      conn.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
        if (err) {
          console.error(`[wings][${ip}] exec error:`, err);
          conn.end();
          if (chatId) bot.sendMessage(chatId, `❌ Gagal menjalankan installer Wings di ${ip}: ${err.message}`).catch(() => {});
          return reject(err);
        }

        stream.on('data', (data) => {
          const out = data.toString();
          try {
            if (out.includes("Input 0-6")) stream.write("1\n");
            if (out.includes("(y/N)")) stream.write("y\n");
            if (out.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
            if (out.includes("Database host username")) stream.write(`${userDB}\n`);
            if (out.includes("Database host password")) stream.write(`${passDB}\n`);
            if (out.includes("Set the FQDN to use for Let's Encrypt")) stream.write(`${domainnode}\n`);
            if (out.includes("Enter email address")) stream.write(`${emailAcak}\n`);
          } catch (e) {}

          process.stdout.write(`[wings:${ip}] ${out}`);
        });

        stream.stderr.on('data', (data) => {
          const out = data.toString();
          process.stderr.write(`[wings:${ip}][ERR] ${out}`);
        });

        stream.on('close', (code) => {
          completed = true;
          conn.end();
          if (code === 0) {
            console.log(`[wings][${ip}] installer finished successfully`);
            if (chatId) {
              bot.sendMessage(chatId, `📦 *Sukses install Wings!*

*🛰 Node:* \`${domainnode}\`
*🌐 Login:* https://${domainpanel}

*Silahkan lanjut Create Node!*`, {
                parse_mode: "Markdown",
                reply_to_message_id: messageId
              }).catch(() => {});
            }
            return resolve({ ok: true, ip, type: 'wings', domainnode, email: emailAcak });
          } else {
            console.error(`[wings][${ip}] installer finished with code ${code}`);
            if (chatId) bot.sendMessage(chatId, `❌ Installer Wings selesai dengan kode ${code} pada ${ip}. Cek manual di VPS.`).catch(() => {});
            return resolve({ ok: false, ip, type: 'wings', code });
          }
        });
      });
    })
    .on('error', (err) => {
      if (!completed) {
        console.error(`[wings][${ip}] SSH connection error:`, err);
        if (chatId) bot.sendMessage(chatId, `❌ Gagal koneksi SSH ke ${ip}: ${err.message}`).catch(() => {});
        return reject(err);
      }
    })
    .connect({
      host: ip,
      port: 22,
      username: 'root',
      password: password,
      readyTimeout: 20000
    });
  });
}

  function runCreateNode(chatId, msg, { ipvps, passwd, domainnode, ramvps }) {
  const conn = new Client();
  const connSettings = { host: ipvps, port: 22, username: 'root', password: passwd };
  const command = 'bash <(curl https://raw.githubusercontent.com/iLyxxDev/hosting/main/install.sh)';

  conn.on('ready', () => {
    conn.exec(command, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, '❌ Terjadi kesalahan saat eksekusi perintah.');
        return conn.end();
      }

      stream.on('close', (code, signal) => {
        console.log('Stream closed with code ' + code + ' and signal ' + signal);
        bot.sendMessage(chatId, `
<b>✅ Sukses Create Node!</b>
<blockquote expandable>⚠️ <b>Token Deployment</b>
1. Login panel Pterodactyl
2. Pilih ke node yang baru dibuat
3. Klik tab "Configuration"
4. Auto Generate Token, salin
5. Ketik /swings ipvps,pwvps,token
</blockquote>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        conn.end();
      }).on('data', (data) => {
        stream.write('naelganteng\n');
        stream.write('4\n');
        stream.write('SG\n');
        stream.write('@gunturnaktido\n');
        stream.write(`${domainnode}\n`);
        stream.write('NODE BY GUNTUR\n');
        stream.write(`${ramvps}\n`);
        stream.write(`${ramvps}\n`);
        stream.write('1\n');
        console.log('STDOUT:', data.toString());
      }).stderr.on('data', (data) => {
        console.log('STDERR:', data.toString());
      });
    });
  }).on('error', (err) => {
    console.log('Connection Error:', err);
    bot.sendMessage(chatId, '❌ Katasandi atau IP tidak valid!');
  }).connect(connSettings);
}
  
  function getSessionStore(bot) {
  if (!global.sessions) global.sessions = {}
  if (!bot.sessions) bot.sessions = global.sessions
  return bot.sessions
}

  function getUserSession(bot, userId) {
  const store = getSessionStore(bot)
  return store[String(userId)]
}

  function setUserSession(bot, userId, session) {
  const store = getSessionStore(bot)
  store[String(userId)] = session
  return store[String(userId)]
}

  function deleteUserSession(bot, userId) {
  const store = getSessionStore(bot)
  delete store[String(userId)]
}
   
  const getSessions = () => getSessionStore(bot)
  
  const sessionFile = path.join(__dirname, "../database/vpsSessions.json")
 let sessions = {}

 if (fs.existsSync(sessionFile)) {
  try {
    sessions = JSON.parse(fs.readFileSync(sessionFile, "utf8"))
    console.log("🟢 Session VPS loaded:", Object.keys(sessions).length)
  } catch {
    sessions = {}
  }
}
    
    function protectNotify(msg, type, n) {
  const userId = msg.from.id.toString()
  const chatId = msg.chat.id

  const isInstall = type === "install"
  const title = isInstall ? "Instalasi" : "Uninstall"

  const protect = protectDescriptions[n] || {
    title: "Proteksi Tambahan",
    desc: ["Proteksi sistem Pterodactyl"]
  }

  const descText = protect.desc
    .map(d => `• ${d}`)
    .join("\n")

  return bot.sendMessage(
    chatId,
    `⚠️ *Konfirmasi ${title} Protect ${n}*\n\n` +
    `🔐 *Security:*\n*${protect.title}*\n\n` +
    `${descText}\n` +
    `• ${isInstall ? "Mengaktifkan" : "Menonaktifkan"} Protect ${n}\n` +
    `• Mengubah file inti Pterodactyl\n\n`,
    {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "Lanjut", callback_data: `${type}_p${n}:${userId}` },
            { text: "Batal", callback_data: `cancel_p${n}:${userId}` }
          ]
        ]
      }
    }
  )
}

async function protectCommand(msg, type) {
  const userId = msg.from.id.toString()
  const session = getUserSession(bot, userId)

  if (!sessions[userId]) {
    return bot.sendMessage(
      msg.chat.id,
      "⚠️ Kamu belum login ke VPS!\n`/loginvps ip|password` dahulu.",
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    )
  }

  const text = (msg.text || "").trim()
  const n = Number(text.match(/\d+$/)?.[0])

  if (!n || n < 1 || n > 14) {
    return bot.sendMessage(msg.chat.id, "❌ Protect tidak tersedia.", {
      reply_to_message_id: msg.message_id
    })
  }

  return protectNotify(msg, type, n)
}

    function saveSessions() {
  fs.writeFileSync(sessionFile, JSON.stringify(sessions, null, 2))
}

    function getSession(userId) {
  return (global.sessions || sessions)[userId] || null
}
    
    global.sessions = sessions
bot.sessions = global.sessions
    
    function saveSessions() {
  fs.writeFileSync(sessionFile, JSON.stringify(sessions, null, 2))
  global.sessions = sessions
  bot.sessions = global.sessions
}
    
    bot.onText(/^\/loginvps(?:\s*:?\s*(.*))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const userId = msg.from.id.toString()
  const input = match[1]?.trim()

  if (!input) {
    return bot.sendMessage(
      chatId,
      `ℹ *Contoh Penggunaan:*\n\`/loginvps 123.45.67.89|password\`\n\nSetelah login, kamu bisa pakai:\n\`/installprotect1\` untuk proteksi panel.`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    )
  }
    
  if (sessions[userId]) {
    const { host } = sessions[userId];
    return bot.sendMessage(
      chatId,
      `⚠️ Kamu sudah login ke VPS:\n\n🌐 \`${host}\`\n\nKetik /logoutvps dulu sebelum login ke VPS lain.`,
      { parse_mode: "Markdown" }
    );
  }

  const [ip, password, portRaw] = input.split("|").map((v) => v.trim());
  const port = portRaw ? parseInt(portRaw) : 22;

  if (!ip || !password) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nGunakan:\n`/loginvps ip|password|port(optional)`\n\nContoh:\n`/loginvps 123.45.67.89|mypassword|22`",
      { parse_mode: "Markdown" }
    );
  }

  bot.sendMessage(chatId, "🔌 Menghubungkan ke VPS...");

  try {
    await ssh.connect({ host: ip, username: "root", password, port });
    ssh.dispose();

    sessions[userId] = { host: ip, username: "root", password, port };
    saveSessions();

    await bot.sendMessage(
      chatId,
      `✅ *Sukses Login VPS!*\n\n🌐 IP: \`${ip}\`\n👤 User: root\n🔑 Password: \`${password}\`\n\nUntuk logout VPS ketik /logoutvps.`,
      { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );

    console.log(`🟢 ${userId} berhasil login ke VPS ${ip}`);
  } catch (err) {
    console.error("❌ LOGIN VPS ERROR:", err);
    bot.sendMessage(
      chatId,
      `❌ Gagal login ke VPS.\nPeriksa IP dan password kamu.\n\nError:\n\`${err.message}\``,
      { parse_mode: "Markdown" }
    );
  }
});
    
  bot.onText(/^\/logoutvps$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  if (!sessions[userId]) {
    return bot.sendMessage(chatId, "⚠️ Kamu belum login ke VPS.", {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    });
  }

  const target = sessions[userId];
  delete sessions[userId];
  saveSessions();

  await bot.sendMessage(
    chatId,
    `✅ *Sukses Logout VPS!*\n\n🌐 IP: \`${target.host}\`\n🔑 Password: \`${target.password}\``,
    { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
  );

  console.log(`🔴 ${userId} logout dari VPS ${target.host}`);
}); 
    
  bot.onText(/^\/install$/, async (msg) => {
  const chatId = msg.chat.id;
      
  const chatTypeRaw = msg.chat.type
  let chatTypeLabel = "Unknown"
  if (chatTypeRaw === "private") chatTypeLabel = "Private Chat"
  else if (chatTypeRaw === "group") chatTypeLabel = "Group"
  else if (chatTypeRaw === "supergroup") chatTypeLabel = "Supergroup"
  else if (chatTypeRaw === "channel") chatTypeLabel = "Channel"

  try {
    await bot.sendMessage(
      settings.ownerId,
      `🔔 *Notification Install*\n\n` +
      `User ID: \`${userId}\`\n` +
      `Username: @${msg.from.username || "-"}\n` +
      `Nama: ${msg.from.first_name || "-"} ${msg.from.last_name || ""}\n` +
      `Type: *${chatTypeLabel}*`,
      { parse_mode: "Markdown" }
    )
  } catch (e) {
    console.error("❌ Gagal kirim notif ke owner:", e.message)
  }
    
  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "❌ Khusus *Owner.*",
      { reply_to_message_id: msg.message_id, parse_mode: "Markdown" }
    );
  }

  userStates[chatId] = { step: 'select_type', data: {} };

  const options = {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [{ text: 'Install All (Recommend)', callback_data: 'install_all' }]
      ]
    }
  };

  bot.sendMessage(chatId, `<b>📡 Menu Install Pterodactyl</b>
${bq}Choose the Option:${ebq}

/cancelinstall untuk batal install.`, options );
});  

  bot.onText(/^\/cancelinstall$/, async (msg) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return bot.sendMessage(chatId, "❌ Akses ditolak!\nKhusus *Owner.*", {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id,
    });
  }

  if (!userStates[chatId]) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada proses instalasi yang sedang berjalan.", {
      reply_to_message_id: msg.message_id,
    });
  }

  delete userStates[chatId];

  await bot.sendMessage(chatId, "✅ Instalasi dibatalkan! Ulang dengan perintah /install.", {
    reply_to_message_id: msg.message_id,
  });
});

  bot.on('callback_query', async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  if (!userStates[chatId] || userStates[chatId].step !== 'select_type') {
    try { await bot.answerCallbackQuery(callbackQuery.id); } catch(_) {}
    return;
  }

  if (data === 'install_panel' || data === 'install_wings' || data === 'install_all') {
    userStates[chatId].type = data;
    userStates[chatId].step = 'ip';
    try { await bot.deleteMessage(chatId, callbackQuery.message.message_id); } catch(_) {}
    await bot.sendMessage(chatId, '📌 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:');
    try { await bot.answerCallbackQuery(callbackQuery.id); } catch(_) {}
  } else {
    try { await bot.answerCallbackQuery(callbackQuery.id); } catch(_) {}
  }
});

  bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
    
  if (text === '/cancelinstall') return;
    
  if (!text || text.startsWith('/')) return;
  if (!userStates[chatId]) return;

  const state = userStates[chatId];

  try {
    switch (state.step) {
      case 'ip':
        if (!isValidIP(text)) {
          return bot.sendMessage(chatId, '❌ Format IP tidak valid.');
        }
        state.data.ip = text.trim();
        state.step = 'password';
        return bot.sendMessage(chatId, '🔑 ᴍᴀꜱᴜᴋᴋᴀɴ ᴘᴀꜱꜱᴡᴏʀᴅ ᴠᴘꜱ:');

      case 'password':
        state.data.password = text.trim();
        if (state.type === 'install_panel') {
          state.step = 'domain_panel';
          return bot.sendMessage(chatId, '🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ᴘᴀɴᴇʟ');
        } else if (state.type === 'install_wings') {
          state.step = 'domain_panel_wings';
          return bot.sendMessage(chatId, '🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ᴘᴀɴᴇʟ:');
        } else if (state.type === 'install_all') {
          state.step = 'domain_panel';
          return bot.sendMessage(chatId, '🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ᴘᴀɴᴇʟ:');
        }
        break;

      case 'domain_panel':
        state.data.domainpanel = text.trim();
        if (state.type === 'install_all') {
          state.step = 'domain_node';
          return bot.sendMessage(chatId, '🛰️ ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ɴᴏᴅᴇ:');
        } else {
          
          installPanel(chatId, state.data.ip, state.data.password, state.data.domainpanel)
            .then(res => {
              
            }).catch(e => {
              console.error(e);
              bot.sendMessage(chatId, '❌ Terjadi kesalahan saat instalasi Panel.');
            });
          delete userStates[chatId];
        }
        break;

      case 'domain_panel_wings':
        state.data.domainpanel = text.trim();
        state.step = 'domain_node';
        return bot.sendMessage(chatId, '🛰️ ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ɴᴏᴅᴇ:');

      case 'domain_node':
        state.data.domainnode = text.trim();

        if (state.type === 'install_wings') {
     
          installWings(chatId, state.data.ip, state.data.password, state.data.domainpanel, state.data.domainnode)
            .then(()=>{}).catch(e=>{ console.error(e); bot.sendMessage(chatId,'❌ Terjadi kesalahan saat instalasi Wings.');});
          delete userStates[chatId];
          return;
        }

        if (state.type === 'install_all') {
          try {
            
            const panelResult = await installPanel(msg, state.data.ip, state.data.password, state.data.domainpanel);
            if (!panelResult || !panelResult.ok) {
              await bot.sendMessage(chatId, `❌ Gagal install panel pada ${state.data.ip}. Wings tidak akan dijalankan.\n\nDetail: ${panelResult && panelResult.code ? `kode:${panelResult.code}` : 'lihat VPS'}`);
              delete userStates[chatId];
              return;
            }

            await bot.sendMessage(chatId, `✅ Sukses install Panel di VPS ${state.data.ip}, Silahkan tunggu ${Math.round(startWingsMs/60000)} menit lagi untuk memulai installasi Wings...`);
            await new Promise(r => setTimeout(r, startWingsMs));

            // 3) install wings
            await bot.sendMessage(chatId, '🛰 Memulai instalasi Wings...');
            const wingsResult = await installWings(msg, state.data.ip, state.data.password, state.data.domainpanel, state.data.domainnode);

            // 4) summary
            if (wingsResult && wingsResult.ok) {
  await bot.sendMessage(chatId, `✅ Sukses install Wings di VPS ${state.data.ip}`);

  // auto lanjut create node
  const defaultRAM = "80000000"; // bisa diganti
                
  await bot.sendMessage(chatId, `🛰️ Melanjutkan proses Create Node...`);
  await runCreateNode(chatId, msg, {
    ipvps: state.data.ip,
    passwd: state.data.password,
    domainnode: state.data.domainnode,
    ramvps: defaultRAM
  });
} else {
  await bot.sendMessage(chatId, `⚠️ Wings selesai dengan masalah pada ${state.data.ip}. Cek manual di VPS. ${wingsResult && wingsResult.code ? `kode:${wingsResult.code}` : ''}`);
}

delete userStates[chatId];
          } catch (err) {
            console.error('Error install_all flow:', err);
            bot.sendMessage(chatId, '❌ Terjadi kesalahan saat proses instalasi gabungan. Cek log server.');
            delete userStates[chatId];
          }
        }
        break;
    }
  } catch (err) {
    console.error('Error flow:',err);
    bot.sendMessage(chatId,'❌ Terjadi error internal di flow instalasi. Coba lagi.');
    delete userStates[chatId];
  }
});
    
    const installPanelState = new Map();
    const setState = (u, d) => installPanelState.set(u, d);
    const getState = (u) => installPanelState.get(u);
    const clearState = (u) => installPanelState.delete(u);

  bot.onText(/^\/installv2$/, async (msg) => {
  const chatId = msg.chat.id
  const senderId = msg.from.id
  const userId = senderId.toString()
  
  const chatTypeRaw = msg.chat.type
  let chatTypeLabel = "Unknown"
  if (chatTypeRaw === "private") chatTypeLabel = "Private Chat"
  else if (chatTypeRaw === "group") chatTypeLabel = "Group"
  else if (chatTypeRaw === "supergroup") chatTypeLabel = "Supergroup"
  else if (chatTypeRaw === "channel") chatTypeLabel = "Channel"

  try {
    await bot.sendMessage(
      settings.ownerId,
      `🔔 *Notification Install V2*\n\n` +
      `User ID: \`${userId}\`\n` +
      `Username: @${msg.from.username || "-"}\n` +
      `Nama: ${msg.from.first_name || "-"} ${msg.from.last_name || ""}\n` +
      `Type: *${chatTypeLabel}*`,
      { parse_mode: "Markdown" }
    )
  } catch (e) {
    console.error("❌ Gagal kirim notif ke owner:", e.message)
  }
        
  setState(userId, {
    step: 1,
    chatId,
    data: {}
  })

  bot.sendMessage(
    chatId,
    "(1/5)\nMasukkan IP VPS:\n(Contoh: 123.456.789)"
  )
})

  bot.on("message", async (msg) => {
  const userId = msg.from?.id?.toString();
  if (!installPanelState.has(userId)) return;
  if (!msg.text || msg.text.startsWith("/")) return;

  const state = getState(userId);
  const chatId = state.chatId;

  if (state.step === 1) {
    state.data.ipvps = msg.text.trim();
    state.step = 2;
    setState(userId, state);
    return bot.sendMessage(chatId, "(2/5)\nMasukkan Password VPS:");
  }

  if (state.step === 2) {
    state.data.passwd = msg.text.trim();
    state.step = 3;
    setState(userId, state);
    return bot.sendMessage(chatId, "(3/5)\nMasukkan Domain Panel:\n(Contoh: guntur.my.id)");
  }

  if (state.step === 3) {
    state.data.subdomain = msg.text.trim();
    state.step = 4;
    setState(userId, state);
    return bot.sendMessage(chatId, "(4/5)\nMasukkan Domain Node:\n(Contoh: node.guntur.my.id)");
  }

  if (state.step === 4) {
    state.data.domainnode = msg.text.trim();
    state.step = 5;
    setState(userId, state);
    return bot.sendMessage(chatId, "(5/5)\nMasukkan RAM VPS:\n(Contoh: 1600000)");
  }

  if (state.step === 5) {
    state.data.ramvps = msg.text.trim();
    clearState(userId);
    startInstallPanel(chatId, state.data);
  }
});

  async function startInstallPanel(chatId, data) {
  const { ipvps, passwd, subdomain, domainnode, ramvps } = data;

  console.log("[INSTALL] startInstallPanel:", { chatId, ipvps, subdomain, domainnode, ramvps });

  const conn = new Client();
  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
  };

  const password = "admin";
  const command = "bash <(curl -s https://pterodactyl-installer.se)";
  let lastMsgId = null;

  conn
    .on("ready", async () => {
      console.log("[SSH] ready:", ipvps);

      const m1 = await bot.sendMessage(chatId, `🔧 Memulai installasi Panel VPS ${ipvps} (domain: ${subdomain}) Silahkan tunggu 1-5 menit.`);
      lastMsgId = m1.message_id;

      console.log("[PANEL] exec installer");
      conn.exec(command, (err, stream) => {
        if (err) {
          console.log("[PANEL] exec error:", err);
          return;
        }

        stream.on("close", async (code, signal) => {
          console.log("[PANEL] close:", { code, signal });

          await bot.deleteMessage(chatId, lastMsgId).catch((e) => console.log("[BOT] delete msg error:", e?.message));
          const m2 = await bot.sendMessage(chatId, `🔧 Memulai installasi Wings VPS ${ipvps} (node: ${domainnode}) Silahkan tunggu 1-5 menit.`);
          lastMsgId = m2.message_id;

          installWings(conn, chatId, lastMsgId, subdomain, domainnode, ramvps, password, ipvps, passwd);
        });

        stream.on("exit", (code, signal) => {
          console.log("[PANEL] exit:", { code, signal });
        });

        stream.on("data", (d) => {
          const s = d.toString();
          console.log("[PANEL][STDOUT]", s);
          handlePanel(d, stream, subdomain, password);
        });

        stream.stderr.on("data", (d) => {
          console.log("[PANEL][STDERR]", d.toString());
        });
      });
    })
    .on("error", (e) => {
      console.log("[SSH] error:", e?.message || e);
      bot.sendMessage(chatId, `❌ SSH error: ${e?.message || e}`).catch(() => {});
    })
    .on("end", () => console.log("[SSH] end"))
    .on("close", () => console.log("[SSH] close"))
    .connect(connSettings);
}

  function installWings(conn, chatId, lastMsgId, subdomain, domainnode, ramvps, password, ipvps, passwd) {
  const command = "bash <(curl -s https://pterodactyl-installer.se)";
  console.log("[WINGS] exec installer");

  conn.exec(command, (err, stream) => {
    if (err) {
      console.log("[WINGS] exec error:", err);
      return;
    }

    stream.on("close", async (code, signal) => {
      console.log("[WINGS] close:", { code, signal });

      await bot.deleteMessage(chatId, lastMsgId).catch((e) => console.log("[BOT] delete msg error:", e?.message));
      console.log("[NODE] start create node/location");
      createNode(conn, chatId, subdomain, domainnode, ramvps, password, ipvps, passwd);
    });

    stream.on("exit", (code, signal) => {
      console.log("[WINGS] exit:", { code, signal });
    });

    stream.on("data", (d) => {
      const s = d.toString();
      console.log("[WINGS][STDOUT]", s);
      handleWings(d, stream, domainnode, subdomain);
    });

    stream.stderr.on("data", (d) => {
      console.log("[WINGS][STDERR]", d.toString());
    });
  });
}

  function createNode(conn, chatId, subdomain, domainnode, ramvps, password, ipvps, passwd) {
  console.log("[NODE] exec config.bash");

  conn.exec(settings.bash, (err, stream) => {
    if (err) {
      console.log("[NODE] exec error:", err);
      return;
    }

    stream.on("close", async (code, signal) => {
      console.log("[NODE] close:", { code, signal });

      const cmd = `
cd /var/www/pterodactyl &&
php artisan p:node:configuration 1 > /etc/pterodactyl/config.yml &&
chmod 600 /etc/pterodactyl/config.yml &&
systemctl restart wings
      `;

      console.log("[WINGS] generate config & restart wings");
      conn.exec(cmd, (err2, stream2) => {
        if (err2) {
          console.log("[WINGS] generate/restart error:", err2);
          bot.sendMessage(chatId, `❌ Gagal generate config / restart wings:\n${err2.message}`).catch(() => {});
          return;
        }

        stream2.on("close", (code2, signal2) => {
          console.log("[WINGS] generate/restart close:", { code2, signal2 });
          sendPanelData(chatId, ipvps, passwd, subdomain, password);
          conn.end();
          console.log("[INSTALL] done");
        });

        stream2.on("exit", (code2, signal2) => {
          console.log("[WINGS] generate/restart exit:", { code2, signal2 });
        });

        stream2.on("data", (d2) => console.log("[WINGS][CFG][STDOUT]", d2.toString()));
        stream2.stderr.on("data", (d2) => console.log("[WINGS][CFG][STDERR]", d2.toString()));
      });
    });

    stream.on("exit", (code, signal) => {
      console.log("[NODE] exit:", { code, signal });
    });

    stream.on("data", (d) => {
      console.log("[NODE][STDOUT]", d.toString());
      handleNode(d, stream, domainnode, ramvps);
    });

    stream.stderr.on("data", (d) => {
      console.log("[NODE][STDERR]", d.toString());
    });
  });
}

  function sendPanelData(chatId, ipvps, passwd, subdomain, password) {
  console.log("[BOT] sendPanelData:", { chatId, ipvps, subdomain });

  bot.sendPhoto(chatId, panel, {
    caption: `
<b>Sukses Install Panel</b>

☁️ <b>Cloud VPS Detail:</b>
IP VPS: <code>${ipvps}</code>
Password VPS: <code>${passwd}</code>

🖥️ <b>Data Pterodactyl:</b>
Username: <code>admin</code>
Password: <code>${password}</code>
Domain: <a href="https://${subdomain}">Click Here</a>
`,
    parse_mode: "HTML"
  });
}

  function handlePanel(data, stream, subdomain, password) {
  const s = data.toString();

  if (s.includes("Input")) {
    console.log("[PANEL] detected Input -> sending answers");
    stream.write("0\n\n\n1248\nAsia/Jakarta\nadmin@gmail.com\nadmin@gmail.com\nadmin\nadmin\nadmin\n");
    stream.write(`${password}\n`);
    stream.write(`${subdomain}\n`);
    stream.write("y\ny\ny\ny\ny\n\n1\n");
  }

  if (s.includes("Select the appropriate number")) {
    console.log("[PANEL] select number -> 1");
    stream.write("1\n");
  }

  if (s.includes("Still assume SSL")) {
    console.log("[PANEL] SSL -> y");
    stream.write("y\n");
  }

  if (s.includes("Please read the Terms of Service")) {
    console.log("[PANEL] ToS -> y");
    stream.write("y\n");
  }
}

  function handleWings(data, stream, domainnode, subdomain) {
  const s = data.toString();

  if (s.includes("Input")) {
    console.log("[WINGS] detected Input -> sending answers");
    stream.write("1\ny\ny\ny\n");
    stream.write(`${subdomain}\n`);
    stream.write("y\nuser\n1248\ny\n");
    stream.write(`${domainnode}\n`);
    stream.write("y\nadmin@gmail.com\ny\n");
  }

  if (s.includes("automatically configure HTTPS using Let's Encrypt")) {
    console.log("[WINGS] letsencrypt -> y");
    stream.write("y\n");
  }
}

  function handleNode(data, stream, domainnode, ramvps) {
  const s = data.toString();
  console.log("[NODE] sending node answers");

  stream.write(`${settings.tokeninstall}\n4\nSGP\nAUTO\n`);
  stream.write(`${domainnode}\nNODE\n${ramvps}\n${ramvps}\n1\n`);

  console.log("[NODE][RAW]", s);
}
  
  async function safeEdit(bot, chatId, messageId, text) {
  try {
    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    });
  } catch (e) {
    console.error("Telegram editMessage error:", e.message);
  }
}
    
  bot.onText(/^\/swings(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id

  const text = match[1]
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/swings ipvps,pwvps,token_node,y")
  }

  const t = text.split(",")
  if (t.length < 3) {
    return bot.sendMessage(chatId, "❌ Format salah!\n\nContoh:\n/swings ipvps,pwvps,token_node,y")
  }

  const ipvps = t[0].trim()
  const passwd = t[1].trim()
  const token = t[2].trim()
  const autoYes = (t[3] || "").trim().toLowerCase() === "y"

  let logs = "🚀 Menjalankan proses wings...\n\n"
  const loadingMsg = await bot.sendMessage(chatId, logs)

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
    readyTimeout: 20000
  }

  const conn = new Client()

  function updateLogs(newLine) {
    logs += newLine + "\n"
    safeEdit(bot, chatId, loadingMsg.message_id, "```\n" + logs.slice(-3500) + "\n```")
  }

  conn.on("ready", () => {
    updateLogs("✅ SSH Connected!")

    conn.exec(token, (err, stream) => {
      if (err) {
        updateLogs("❌ Gagal menjalankan token node.")
        return conn.end()
      }

      updateLogs("▶️ Menjalankan token...")

      const handleAutoInput = () => {
        if (autoYes) stream.write("y\n")
      }

      stream.on("data", (data) => {
        const out = data.toString()
        updateLogs(out.trim())

        if (
          autoYes &&
          (out.includes("Override existing configuration file") ||
            /\(y\/N\)/i.test(out) ||
            /Override.*configuration/i.test(out))
        ) {
          handleAutoInput()
        }
      })

      stream.stderr.on("data", (data) => {
        const out = data.toString()
        updateLogs(out.trim())

        if (
          autoYes &&
          (out.includes("Override existing configuration file") ||
            /\(y\/N\)/i.test(out))
        ) {
          handleAutoInput()
        }
      })

      stream.on("close", () => {
        updateLogs("✅ Token selesai, lanjut jalankan wings...")

        conn.exec("sudo systemctl start wings", (err2, stream2) => {
          if (err2) {
            updateLogs("❌ Gagal menjalankan wings.")
            return conn.end()
          }

          stream2.stdout.on("data", (data) => updateLogs(data.toString().trim()))
          stream2.stderr.on("data", (data) => updateLogs(data.toString().trim()))

          stream2.on("close", () => {
            updateLogs("✅ Wings berhasil dijalankan!")
            conn.end()
          })
        })
      })
    })
  })
  .on("error", (err) => updateLogs("❌ Connection Error: " + err.message))
  .on("end", () => updateLogs("🔌 SSH Connection closed"))
  .connect(connSettings)
})
    
  bot.onText(/^\/installcert(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id
  const text = match[1]

  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/installcert ipvps,pwvps,domain,email")
  }

  const t = text.split(",")
  if (t.length < 4) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/installcert ipvps,pwvps,domain,email")
  }

  const ipvps = t[0].trim()
  const passwd = t[1].trim()
  const domain = t[2].trim()
  const email = t[3].trim()

  let logs = "🔐 Install SSL Certificate (Let's Encrypt)...\n\n"
  const loadingMsg = await bot.sendMessage(chatId, logs)

  const conn = new Client()

  function updateLogs(newLine) {
    logs += newLine + "\n"
    safeEdit(bot, chatId, loadingMsg.message_id, "```\n" + logs.slice(-3500) + "\n```")
  }

  const cmd = `
set -e
export DEBIAN_FRONTEND=noninteractive

if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y
  apt-get install -y certbot
elif command -v apt >/dev/null 2>&1; then
  apt update -y
  apt install -y certbot
elif command -v dnf >/dev/null 2>&1; then
  dnf install -y certbot
elif command -v yum >/dev/null 2>&1; then
  yum install -y certbot
fi

certbot certonly --standalone \\
  -d "${domain}" \\
  --non-interactive \\
  --agree-tos \\
  -m "${email}"

ls -la /etc/letsencrypt/live/${domain}
`.trim()

  conn.on("ready", () => {
    updateLogs("✅ SSH Connected!")

    conn.exec(`bash -lc ${JSON.stringify(cmd)}`, (err, stream) => {
      if (err) {
        updateLogs("❌ Gagal menjalankan certbot.")
        return conn.end()
      }

      stream.on("data", d => updateLogs(d.toString().trim()))
      stream.stderr.on("data", d => updateLogs(d.toString().trim()))

      stream.on("close", () => {
        updateLogs("✅ Certificate berhasil dibuat")
        conn.end()
      })
    })
  })
  .on("error", err => updateLogs("❌ Connection Error: " + err.message))
  .connect({
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
    readyTimeout: 20000
  })
})
    bot.onText(/^\/installprotect(\d+)$/i, async (msg) => protectCommand(msg, "install"))
    bot.onText(/^\/uninstallprotect(\d+)$/i, async (msg) => protectCommand(msg, "uninstall"))

  bot.on("callback_query", async (q) => {
  const data = q.data || ""
  if (!data.includes(":")) return

  const userId = q.from.id.toString()
  const chatId = q.message.chat.id
  const messageId = q.message.message_id

  const [action, uid] = data.split(":")
  if (uid !== userId) return

  const m = action.match(/^(install|uninstall|cancel)_p(\d+)$/i)
  if (!m) return

  const type = m[1].toLowerCase()
  const n = Number(m[2])

  if (!n || n < 1 || n > 14) {
    try { await bot.answerCallbackQuery(q.id) } catch {}
    return
  }

  if (type === "cancel") {
    try { await bot.answerCallbackQuery(q.id) } catch {}
    return bot.editMessageText("❌ Proses dibatalkan.", {
      chat_id: chatId,
      message_id: messageId
    })
  }

  const sessions = getSessions()
  const session = sessions[userId]

  if (!session) {
    try { await bot.answerCallbackQuery(q.id) } catch {}
    return bot.editMessageText(
      "❌ Session VPS tidak ditemukan.\nSilakan login ulang.",
      { chat_id: chatId, message_id: messageId }
    )
  }

  const installHandler = installProtect?.[n]
  const uninstallHandler = uninstallProtect?.[n]

  try { await bot.answerCallbackQuery(q.id) } catch {}

  if (type === "install") {
    if (!installHandler) {
      return bot.editMessageText("❌ Handler install tidak tersedia.", { chat_id: chatId, message_id: messageId })
    }
    await bot.editMessageText(`📡 *Memulai instalasi Protect ${n}*\nMohon tunggu...`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    })
    return installHandler(bot, q, session)
  }

  if (type === "uninstall") {
    if (!uninstallHandler) {
      return bot.editMessageText("❌ Handler uninstall tidak tersedia.", { chat_id: chatId, message_id: messageId })
    }
    await bot.editMessageText(`📡 *Memulai uninstalasi Protect ${n}*\nMohon tunggu...`, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    })
    return uninstallHandler(bot, q, session)
  }
})
    
  bot.onText(/^\/uninstall$/, (msg) => {
  const chatId = msg.chat.id;

  const options = {
    parse_mode: "HTML",
    reply_to_message_id: msg.message_id,
    reply_markup: {
      inline_keyboard: [
        [
          { text: 'ᴜɴɪɴꜱᴛᴀʟʟ ᴘᴀɴᴇʟ', callback_data: 'uninstall_panel' },
          { text: 'ᴜɴɪɴꜱᴛᴀʟʟ ᴡɪɴɢꜱ', callback_data: 'uninstall_wings' }
        ],
        [
          { text: 'ᴜɴɪɴꜱᴛᴀʟʟ ᴀʟʟ', callback_data: 'uninstall_all' }
        ],
        [
          { text: '❌ ʙᴀᴛᴀʟ', callback_data: 'cancel_uninstall_menu' }
        ]
      ]
    }
  };

  bot.sendMessage(chatId, `<b>🔧 Menu Uninstall Pterodactyl</b>
${bq}Choose the Option:${ebq}

⚠️ <b>Peringatan:</b>
• Uninstall Panel = Hapus panel & database
• Uninstall Wings = Hapus wings & service
• Uninstall All = Hapus SEMUA data Pterodactyl`, options);
});

  bot.onText(/^\/uninstallpanel$/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (!onlyOwner(msg)) {
    return bot.sendMessage(
      chatId,
      `❌ @${settings.dev} Only!`,
      { reply_to_message_id: msg.message_id }
    );
  }

  userStates[msg.from.id] = { step: 'awaiting_ip_uninstall', type: 'panel' };
  bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
});
    
  bot.onText(/^\/uninstallwings$/, async (msg) => {
  const chatId = msg.chat.id;

  userStates[msg.from.id] = { step: 'awaiting_ip_uninstall', type: 'wings' };
  bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
});

  bot.onText(/^\/uninstallall$/, async (msg) => {
  const chatId = msg.chat.id;

  userStates[msg.from.id] = { step: 'awaiting_ip_uninstall', type: 'all' };
  bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
});

  bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const data = query.data;

  if (data === "uninstall_panel") {
    userStates[userId] = { step: 'awaiting_ip_uninstall', type: 'panel' };
    await bot.answerCallbackQuery(query.id);
    return bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
  }

  if (data === "uninstall_wings") {
    userStates[userId] = { step: 'awaiting_ip_uninstall', type: 'wings' };
    await bot.answerCallbackQuery(query.id);
    return bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
  }

  if (data === "uninstall_all") {
    userStates[userId] = { step: 'awaiting_ip_uninstall', type: 'all' };
    await bot.answerCallbackQuery(query.id);
    return bot.sendMessage(chatId, "🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:");
  }

  if (data === "cancel_uninstall_menu") {
    await bot.answerCallbackQuery(query.id, {
      text: "❌ Menu dibatalkan",
      show_alert: false
    });
    try {
      await bot.deleteMessage(chatId, query.message.message_id);
    } catch (_) {}
    return;
  }
});

  bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = msg.text;

  if (!text || text.startsWith("/")) return;

  const state = userStates[userId];
  if (!state) return;

  if (state.step === 'awaiting_ip_uninstall') {
    if (!isValidIP(text)) {
      return bot.sendMessage(chatId, '❌ Format IP tidak valid.');
    }

    state.ip = text.trim();
    state.step = 'awaiting_password_uninstall';
    return bot.sendMessage(chatId, '🔑 ᴍᴀꜱᴜᴋᴋᴀɴ ᴘᴀꜱꜱᴡᴏʀᴅ ᴠᴘꜱ:');
  }

  if (state.step === 'awaiting_password_uninstall') {
    const password = text.trim();
    const ip = state.ip;
    const type = state.type;

    // Konfirmasi sebelum eksekusi
    let confirmMessage = "";
    let confirmCallback = "";

    if (type === 'panel') {
      confirmMessage = `⚠️ **KONFIRMASI UNINSTALL PANEL**\n\nIP VPS: <code>${ip}</code>\n\nTindakan ini akan menghapus:\n• Database Pterodactyl\n• User database\n• File panel\n• Nginx config\n• SSL certificate`;
      confirmCallback = `confirm_uninstall_panel_${ip}_${password}`;
    } else if (type === 'wings') {
      confirmMessage = `⚠️ **KONFIRMASI UNINSTALL WINGS**\n\nIP VPS: <code>${ip}</code>\n\nTindakan ini akan menghapus:\n• Service wings\n• File wings\n• Daemon data`;
      confirmCallback = `confirm_uninstall_wings_${ip}_${password}`;
    } else if (type === 'all') {
      confirmMessage = `⚠️ **KONFIRMASI UNINSTALL ALL**\n\nIP VPS: <code>${ip}</code>\n\nTindakan ini akan menghapus SEMUA:\n• Panel & database\n• Wings & service\n• Semua file Pterodactyl\n• Database tables\n• System users`;
      confirmCallback = `confirm_uninstall_all_${ip}_${password}`;
    }

    const confirmKeyboard = {
      inline_keyboard: [
        [
          { text: "✅ Ya, Lanjutkan", callback_data: confirmCallback },
          { text: "❌ Batal", callback_data: "cancel_uninstall_process" }
        ]
      ]
    };

    delete userStates[userId];

    return bot.sendMessage(
      chatId,
      confirmMessage,
      {
        parse_mode: "HTML",
        reply_to_message_id: msg.message_id,
        reply_markup: confirmKeyboard
      }
    );
  }
});

  bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = callbackQuery.data;
  const userId = callbackQuery.from.id;

  if (data.startsWith("confirm_uninstall_panel_")) {
    const parts = data.replace("confirm_uninstall_panel_", "").split("_");
    const ip = parts[0];
    const password = parts.slice(1).join("_");

    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "⏳ Memulai uninstall panel...",
      show_alert: false
    });

    await bot.editMessageText(
      `🔄 **UNINSTALL PANEL**\n\nIP: <code>${ip}</code>\nStatus: Menghubungkan...`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );

    await uninstallPanel(chatId, ip, password, messageId);
    return;
  }

  if (data.startsWith("confirm_uninstall_wings_")) {
    const parts = data.replace("confirm_uninstall_wings_", "").split("_");
    const ip = parts[0];
    const password = parts.slice(1).join("_");

    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "⏳ Memulai uninstall wings...",
      show_alert: false
    });

    await bot.editMessageText(
      `🔄 **UNINSTALL WINGS**\n\nIP: <code>${ip}</code>\nStatus: Menghubungkan...`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );

    await uninstallWings(chatId, ip, password, messageId);
    return;
  }

  if (data.startsWith("confirm_uninstall_all_")) {
    const parts = data.replace("confirm_uninstall_all_", "").split("_");
    const ip = parts[0];
    const password = parts.slice(1).join("_");

    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "⏳ Memulai uninstall total...",
      show_alert: false
    });

    await bot.editMessageText(
      `🔄 **UNINSTALL ALL**\n\nIP: <code>${ip}</code>\nStatus: Menghubungkan...`,
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );

    await uninstallAll(chatId, ip, password, messageId);
    return;
  }

  if (data === "cancel_uninstall_process") {
    await bot.answerCallbackQuery(callbackQuery.id, {
      text: "❌ Proses dibatalkan",
      show_alert: true
    });

    await bot.editMessageText(
      "❌ Uninstall dibatalkan.",
      {
        chat_id: chatId,
        message_id: messageId,
        parse_mode: "HTML"
      }
    );
    return;
  }
});

  async function uninstallPanel(chatId, ip, password, messageId) {
  const conn = new Client();
  
  const updateStatus = async (status) => {
    try {
      await bot.editMessageText(
        `🔄 **UNINSTALL PANEL**\n\nIP: <code>${ip}</code>\nStatus: ${status}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );
    } catch (_) {}
  };

  try {
    conn.on("ready", async () => {
      console.log(`[uninstall-panel][${ip}] SSH connected`);
      
      try {
        // 1. Stop service
        await updateStatus("Menghentikan service...");
        await runSSHCommand(conn, "systemctl stop pteroq");
        await runSSHCommand(conn, "systemctl disable pteroq");
        
        // 2. Hapus service
        await updateStatus("Menghapus service...");
        await runSSHCommand(conn, "rm -f /etc/systemd/system/pteroq.service");
        await runSSHCommand(conn, "systemctl daemon-reload");
        
        // 3. Hapus database Pterodactyl
        await updateStatus("Menghapus database...");
        const dbOutput = await runSSHCommand(conn, "mysql -e 'SHOW DATABASES;' 2>/dev/null || echo 'No MySQL'");
        
        if (!dbOutput.includes("No MySQL")) {
          const dbLines = dbOutput.trim().split("\n");
          for (const line of dbLines) {
            const dbName = line.trim();
            if (dbName && (dbName.includes("ptero") || dbName.includes("panel") || dbName.includes("srv"))) {
              await runSSHCommand(conn, `mysql -e "DROP DATABASE IF EXISTS \`${dbName}\`;" 2>/dev/null || true`);
            }
          }
        }
        
        // 4. Hapus user database
        await updateStatus("Menghapus user database...");
        await runSSHCommand(conn, "mysql -e \"SELECT User FROM mysql.user WHERE User LIKE '%ptero%' OR User LIKE '%srv%';\" 2>/dev/null | tail -n +2 | while read user; do mysql -e \"DROP USER IF EXISTS '\$user'@'localhost'; DROP USER IF EXISTS '\$user'@'%';\" 2>/dev/null || true; done");
        await runSSHCommand(conn, "mysql -e 'FLUSH PRIVILEGES;' 2>/dev/null || true");
        
        // 5. Hapus file panel
        await updateStatus("Menghapus file panel...");
        await runSSHCommand(conn, "rm -rf /var/www/pterodactyl");
        await runSSHCommand(conn, "rm -rf /etc/pterodactyl");
        
        // 6. Hapus nginx config
        await updateStatus("Menghapus nginx config...");
        await runSSHCommand(conn, "rm -f /etc/nginx/sites-available/pterodactyl.conf");
        await runSSHCommand(conn, "rm -f /etc/nginx/sites-enabled/pterodactyl.conf");
        await runSSHCommand(conn, "nginx -t && systemctl reload nginx 2>/dev/null || true");
        
        // 7. Hapus SSL
        await updateStatus("Menghapus SSL...");
        await runSSHCommand(conn, "certbot delete --non-interactive --cert-name $(cat /etc/letsencrypt/live/$(hostname -f)/cert.pem 2>/dev/null | openssl x509 -noout -subject | sed 's/.*CN=\\([^/]*\\)/\\1/') 2>/dev/null || true");
        
        // 8. Hapus cron jobs
        await updateStatus("Menghapus cron jobs...");
        await runSSHCommand(conn, "crontab -l | grep -v pterodactyl | crontab -");
        
        // 9. Hapus user system
        await updateStatus("Menghapus user system...");
        await runSSHCommand(conn, "deluser --remove-home pterodactyl 2>/dev/null || true");
        
        await bot.editMessageText(
          `✅ **UNINSTALL PANEL SELESAI**\n\n` +
          `IP: <code>${ip}</code>\n\n` +
          `✅ Service dihentikan\n` +
          `✅ Database dihapus\n` +
          `✅ User database dihapus\n` +
          `✅ File panel dihapus\n` +
          `✅ Nginx config dihapus\n` +
          `✅ SSL dihapus\n` +
          `✅ Cron jobs dihapus\n\n` +
          `Panel telah diuninstall sepenuhnya.`,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML"
          }
        );
        
      } catch (error) {
        console.error(`[uninstall-panel][${ip}] Error:`, error);
        await bot.sendMessage(
          chatId,
          `❌ Error uninstall panel:\n<code>${error.message}</code>`,
          { parse_mode: "HTML" }
        );
      } finally {
        conn.end();
      }
    });
    
    conn.on("error", async (err) => {
      console.error(`[uninstall-panel][${ip}] SSH error:`, err);
      await bot.sendMessage(
        chatId,
        `❌ Gagal koneksi SSH ke ${ip}:\n<code>${err.message}</code>`,
        { parse_mode: "HTML" }
      );
    });
    
    conn.connect({
      host: ip,
      port: 22,
      username: "root",
      password: password,
      readyTimeout: 20000
    });
    
  } catch (error) {
    console.error(`[uninstall-panel][${ip}] Setup error:`, error);
    await bot.sendMessage(
      chatId,
      `❌ Error setup:\n<code>${error.message}</code>`,
      { parse_mode: "HTML" }
    );
  }
}

  async function uninstallWings(chatId, ip, password, messageId) {
  const conn = new Client();
  
  const updateStatus = async (status) => {
    try {
      await bot.editMessageText(
        `🔄 **UNINSTALL WINGS**\n\nIP: <code>${ip}</code>\nStatus: ${status}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );
    } catch (_) {}
  };

  try {
    conn.on("ready", async () => {
      console.log(`[uninstall-wings][${ip}] SSH connected`);
      
      try {
        // 1. Stop service
        await updateStatus("Menghentikan service...");
        await runSSHCommand(conn, "systemctl stop wings");
        await runSSHCommand(conn, "systemctl disable wings");
        
        // 2. Hapus service
        await updateStatus("Menghapus service...");
        await runSSHCommand(conn, "rm -f /etc/systemd/system/wings.service");
        await runSSHCommand(conn, "systemctl daemon-reload");
        
        // 3. Hapus file wings
        await updateStatus("Menghapus file wings...");
        await runSSHCommand(conn, "rm -rf /usr/local/bin/wings");
        await runSSHCommand(conn, "rm -rf /srv/daemon-data");
        await runSSHCommand(conn, "rm -rf /srv/daemon");
        await runSSHCommand(conn, "rm -rf /root/.config/pterodactyl");
        
        // 4. Hapus log files
        await updateStatus("Menghapus log files...");
        await runSSHCommand(conn, "rm -rf /var/log/wings");
        
        // 5. Hapus user system
        await updateStatus("Menghapus user system...");
        await runSSHCommand(conn, "deluser --remove-home wings 2>/dev/null || true");
        
        await bot.editMessageText(
          `✅ **UNINSTALL WINGS SELESAI**\n\n` +
          `IP: <code>${ip}</code>\n\n` +
          `✅ Service dihentikan\n` +
          `✅ File wings dihapus\n` +
          `✅ Daemon data dihapus\n` +
          `✅ Log files dihapus\n` +
          `✅ User system dihapus\n\n` +
          `Wings telah diuninstall sepenuhnya.`,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML"
          }
        );
        
      } catch (error) {
        console.error(`[uninstall-wings][${ip}] Error:`, error);
        await bot.sendMessage(
          chatId,
          `❌ Error uninstall wings:\n<code>${error.message}</code>`,
          { parse_mode: "HTML" }
        );
      } finally {
        conn.end();
      }
    });
    
    conn.on("error", async (err) => {
      console.error(`[uninstall-wings][${ip}] SSH error:`, err);
      await bot.sendMessage(
        chatId,
        `❌ Gagal koneksi SSH ke ${ip}:\n<code>${err.message}</code>`,
        { parse_mode: "HTML" }
      );
    });
    
    conn.connect({
      host: ip,
      port: 22,
      username: "root",
      password: password,
      readyTimeout: 20000
    });
    
  } catch (error) {
    console.error(`[uninstall-wings][${ip}] Setup error:`, error);
    await bot.sendMessage(
      chatId,
      `❌ Error setup:\n<code>${error.message}</code>`,
      { parse_mode: "HTML" }
    );
  }
}

  async function uninstallAll(chatId, ip, password, messageId) {
  const conn = new Client();
  
  const updateStatus = async (status) => {
    try {
      await bot.editMessageText(
        `🔄 **UNINSTALL ALL**\n\nIP: <code>${ip}</code>\nStatus: ${status}`,
        {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "HTML"
        }
      );
    } catch (_) {}
  };

  try {
    conn.on("ready", async () => {
      console.log(`[uninstall-all][${ip}] SSH connected`);
      
      try {
        // 1. Stop semua service
        await updateStatus("Menghentikan semua service...");
        await runSSHCommand(conn, "systemctl stop wings pteroq");
        await runSSHCommand(conn, "systemctl disable wings pteroq");
        
        // 2. Hapus semua service
        await updateStatus("Menghapus service...");
        await runSSHCommand(conn, "rm -f /etc/systemd/system/wings.service /etc/systemd/system/pteroq.service");
        await runSSHCommand(conn, "systemctl daemon-reload");
        
        // 3. Hapus SEMUA database yang berhubungan dengan Pterodactyl
        await updateStatus("Menghapus semua database...");
        const dbOutput = await runSSHCommand(conn, "mysql -e 'SHOW DATABASES;' 2>/dev/null || echo 'No MySQL'");
        
        if (!dbOutput.includes("No MySQL")) {
          const dbLines = dbOutput.trim().split("\n");
          for (const line of dbLines) {
            const dbName = line.trim();
            if (dbName && dbName !== "information_schema" && dbName !== "mysql" && 
                dbName !== "performance_schema" && dbName !== "sys") {
              if (dbName.includes("ptero") || dbName.includes("panel") || dbName.includes("srv") || 
                  dbName.includes("daemon") || dbName.includes("wings")) {
                await runSSHCommand(conn, `mysql -e "DROP DATABASE IF EXISTS \`${dbName}\`;" 2>/dev/null || true`);
              }
            }
          }
          
          // Hapus SEMUA user yang bukan default
          await runSSHCommand(conn, "mysql -e \"SELECT User FROM mysql.user WHERE User NOT IN ('mysql.sys', 'mysql.session', 'mysql.infoschema', 'root', 'debian-sys-maint');\" 2>/dev/null | tail -n +2 | while read user; do mysql -e \"DROP USER IF EXISTS '\$user'@'localhost'; DROP USER IF EXISTS '\$user'@'%';\" 2>/dev/null || true; done");
          await runSSHCommand(conn, "mysql -e 'FLUSH PRIVILEGES;' 2>/dev/null || true");
        }
        
        // 4. Hapus SEMUA file Pterodactyl
        await updateStatus("Menghapus semua file...");
        await runSSHCommand(conn, "rm -rf /var/www/pterodactyl");
        await runSSHCommand(conn, "rm -rf /etc/pterodactyl");
        await runSSHCommand(conn, "rm -rf /usr/local/bin/wings");
        await runSSHCommand(conn, "rm -rf /srv/daemon-data");
        await runSSHCommand(conn, "rm -rf /srv/daemon");
        await runSSHCommand(conn, "rm -rf /root/.config/pterodactyl");
        
        // 5. Hapus semua config
        await updateStatus("Menghapus semua config...");
        await runSSHCommand(conn, "rm -f /etc/nginx/sites-available/pterodactyl.conf");
        await runSSHCommand(conn, "rm -f /etc/nginx/sites-enabled/pterodactyl.conf");
        await runSSHCommand(conn, "nginx -t && systemctl reload nginx 2>/dev/null || true");
        
        // 6. Hapus SSL
        await updateStatus("Menghapus SSL...");
        await runSSHCommand(conn, "certbot delete --non-interactive --cert-name $(hostname -f) 2>/dev/null || true");
        
        // 7. Hapus semua cron jobs yang berhubungan
        await updateStatus("Menghapus cron jobs...");
        await runSSHCommand(conn, "crontab -l | grep -v -E '(ptero|wings|daemon)' | crontab -");
        
        // 8. Hapus semua user system
        await updateStatus("Menghapus user system...");
        await runSSHCommand(conn, "deluser --remove-home pterodactyl 2>/dev/null || true");
        await runSSHCommand(conn, "deluser --remove-home wings 2>/dev/null || true");
        
        // 9. Hapus environment variables
        await updateStatus("Membersihkan environment...");
        await runSSHCommand(conn, "sed -i '/PTERODACTYL_/d' /etc/environment 2>/dev/null || true");
        await runSSHCommand(conn, "sed -i '/DB_/d' /etc/environment 2>/dev/null || true");
        
        // 10. Hapus semua log files
        await updateStatus("Menghapus log files...");
        await runSSHCommand(conn, "rm -f /var/log/pterodactyl/*.log 2>/dev/null || true");
        await runSSHCommand(conn, "rm -rf /var/log/wings 2>/dev/null || true");
        
        await bot.editMessageText(
          `✅ **UNINSTALL ALL SELESAI**\n\n` +
          `IP: <code>${ip}</code>\n\n` +
          `✅ SEMUA service dihentikan\n` +
          `✅ SEMUA database dihapus\n` +
          `✅ SEMUA user database dihapus\n` +
          `✅ SEMUA file Pterodactyl dihapus\n` +
          `✅ SEMUA config dihapus\n` +
          `✅ SSL dihapus\n` +
          `✅ Cron jobs dihapus\n` +
          `✅ User system dihapus\n` +
          `✅ Environment dibersihkan\n` +
          `✅ Log files dihapus\n\n` +
          `VPS sekarang BERSIH dan siap untuk install ulang dari awal.`,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "HTML"
          }
        );
        
      } catch (error) {
        console.error(`[uninstall-all][${ip}] Error:`, error);
        await bot.sendMessage(
          chatId,
          `❌ Error uninstall all:\n<code>${error.message}</code>`,
          { parse_mode: "HTML" }
        );
      } finally {
        conn.end();
      }
    });
    
    conn.on("error", async (err) => {
      console.error(`[uninstall-all][${ip}] SSH error:`, err);
      await bot.sendMessage(
        chatId,
        `❌ Gagal koneksi SSH ke ${ip}:\n<code>${err.message}</code>`,
        { parse_mode: "HTML" }
      );
    });
    
    conn.connect({
      host: ip,
      port: 22,
      username: "root",
      password: password,
      readyTimeout: 20000
    });
    
  } catch (error) {
    console.error(`[uninstall-all][${ip}] Setup error:`, error);
    await bot.sendMessage(
      chatId,
      `❌ Error setup:\n<code>${error.message}</code>`,
      { parse_mode: "HTML" }
    );
  }
}

  function runSSHCommand(conn, command) {
  return new Promise((resolve, reject) => {
    conn.exec(command, (err, stream) => {
      if (err) return reject(err);
      
      let output = "";
      stream.on("data", (data) => {
        output += data.toString();
      });
      
      stream.on("close", (code) => {
        resolve(output);
      });
      
      stream.stderr.on("data", (data) => {
        output += data.toString();
      });
    });
  });
}
    
  bot.onText(/^\/reinstall(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;

  const raw = match && match[1] ? match[1].trim() : "";
  if (!raw || !raw.includes(",")) {
    return bot.sendMessage(chatId, "❌ Format salah\nContoh: /reinstall ipvps,password", {
      reply_to_message_id: msg.message_id
    });
  }

  const parts = raw.split(",").map(v => v.trim());
  if (parts.length < 3) {
  return bot.sendMessage(chatId, "❌ Format salah\nContoh: /reinstall ip,password,domain");
  }

  const [ip, password, domain] = parts;

  const esc = (t) =>
    String(t)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  // ===== live log state =====
  let logBuf = "";
  let lastFlush = 0;
  let pendingFlush = null;

  // kirim message awal untuk diedit
  const startMsg = await bot.sendMessage(chatId, "⏳ Starting reinstall...", {
    reply_to_message_id: msg.message_id
  });
  const logMessageId = startMsg.message_id;

  // throttle flush: max 1x/1000ms, + cut text biar aman
  const flush = async (force = false) => {
    const now = Date.now();
    if (!force && now - lastFlush < 1000) {
      if (!pendingFlush) {
        pendingFlush = setTimeout(() => {
          pendingFlush = null;
          flush(true).catch(() => {});
        }, 1100);
      }
      return;
    }
    lastFlush = now;

    // potong log supaya muat (jaga-jaga)
    // Telegram limit ~4096 chars. Kita sisakan buat header.
    const header = `<b>🔧 Reinstall SSL</b>\nIP: <code>${esc(ip)}</code>\n\n`;
    const maxLogLen = 3500; // aman
    let showLog = logBuf;
    if (showLog.length > maxLogLen) showLog = showLog.slice(-maxLogLen);

    const body = `${header}<pre>${esc(showLog || "…")}</pre>`;
    try {
      await bot.editMessageText(body, {
        chat_id: chatId,
        message_id: logMessageId,
        parse_mode: "HTML",
        disable_web_page_preview: true
      });
    } catch (e) {
      // kalau "message is not modified" / minor -> abaikan
      const desc = e?.response?.body?.description || e?.message || "";
      if (desc.includes("message is not modified")) return;
      // kalau rate limit, tunggu sebentar
      if (desc.includes("Too Many Requests")) {
        await new Promise(r => setTimeout(r, 1500));
        return;
      }
      // selain itu biarkan ketahuan di console (tapi jangan crash)
      console.log("editMessageText error:", e?.response?.body || e);
    }
  };

  const addLog = async (line) => {
    logBuf += (logBuf ? "\n" : "") + line;
    await flush(false);
  };

  const run = async (ssh, cmd, label) => {
    await addLog(`$ ${cmd}`);
    const res = await ssh.execCommand(cmd);
    const out = (res.stdout || "").trim();
    const err = (res.stderr || "").trim();

    if (out) await addLog(out);
    if (err) await addLog(err);

    // tanda sukses/gagal ringkas
    if (res.code && Number(res.code) !== 0) {
      await addLog(`[${label || "cmd"}] exit code: ${res.code}`);
    }
    return res;
  };

  const ssh = new NodeSSH();

  try {
    await addLog("Connecting SSH...");
    await ssh.connect({
      host: ip,
      username: "root",
      password,
      readyTimeout: 20000
    });
    await addLog("✅ SSH connected");

    // 1) stop service + kill certbot
    await addLog("Stopping nginx/certbot & cleaning locks...");
    await run(ssh, "systemctl stop nginx || true", "stop-nginx");
    await run(ssh, "systemctl stop certbot.timer || true", "stop-timer");
    await run(ssh, "systemctl stop certbot || true", "stop-certbot");
    await run(ssh, "pkill -f certbot || true", "kill-certbot");

    // 2) hapus lock
    await run(ssh, "rm -rf /var/lib/letsencrypt/.lock /var/log/letsencrypt/.lock /etc/letsencrypt/.certbot.lock || true", "rm-lock");

    // 3) install certbot kalau belum ada
    await addLog("Ensuring certbot installed...");
    await run(ssh, "command -v certbot >/dev/null 2>&1 || (apt-get update -y && apt-get install -y certbot python3-certbot-nginx)", "install-certbot");

    // 4) domain dari command (lebih akurat)
if (!domain || !domain.includes(".")) {
  await addLog("❌ Domain tidak valid dari command.");
  ssh.dispose();
  await flush(true);
  return bot.editMessageText(
    `<b>❌ Domain tidak valid</b>\nIP: <code>${esc(ip)}</code>\n\n<pre>${esc(logBuf.slice(-3500))}</pre>`,
    { chat_id: chatId, message_id: logMessageId, parse_mode: "HTML" }
  );
}

      await addLog(`✅ Domain from command: ${domain}`);

    // 5) issue ulang cert (standalone) biar port 80 bebas
    await addLog("Issuing SSL certificate (standalone)...");
    await run(
  ssh,
  `certbot certonly --standalone -d ${domain} --non-interactive --agree-tos -m admin@${domain} --keep-until-expiring`,
  "issue-cert"
    );

    // 6) start nginx + reload
    await addLog("Starting nginx & reloading...");
    await run(ssh, "systemctl start nginx || true", "start-nginx");
    await run(ssh, "systemctl reload nginx || true", "reload-nginx");

    // 7) verify
    await addLog("Checking cert status...");
    const check = await run(ssh, `bash -lc "certbot certificates 2>/dev/null | grep -A2 -n '${domain}' || true"`, "check-cert");

    ssh.dispose();

    await addLog("✅ FINISHED");
    await flush(true);

    const tail = logBuf.length > 3500 ? logBuf.slice(-3500) : logBuf;

    return bot.editMessageText(
      `<b>✅ Sukses Reinstall SSL!</b>\nIP: <code>${esc(ip)}</code>\nDomain: <code>${esc(domain)}</code>\n\n<pre>${esc(tail)}</pre>`,
      { chat_id: chatId, message_id: logMessageId, parse_mode: "HTML", disable_web_page_preview: true }
    );

  } catch (err) {
    console.error(err);
    try { ssh.dispose(); } catch {}

    await addLog(`❌ ERROR: ${err.message || err}`);
    await flush(true);

    const tail = logBuf.length > 3500 ? logBuf.slice(-3500) : logBuf;

    return bot.editMessageText(
      `<b>❌ Gagal Reinstall SSL</b>\nIP: <code>${esc(ip)}</code>\n\n<pre>${esc(tail)}</pre>`,
      { chat_id: chatId, message_id: logMessageId, parse_mode: "HTML" }
    );
  }
});
   
  bot.onText(/^\/fixssl(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;

  const raw = match && match[1] ? match[1].trim() : "";
  const parts = raw.split(",").map(v => v.trim()).filter(Boolean);
  if (parts.length < 3) {
    return bot.sendMessage(chatId, "❌ Format salah\nContoh: /fixssl ip,password,domain", {
      reply_to_message_id: msg.message_id
    });
  }

  const [ip, password, domain] = parts;

  const esc = (t) =>
    String(t)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");

  // ===== live log state =====
  let logBuf = "";
  let lastFlush = 0;
  let pendingFlush = null;

  const startMsg = await bot.sendMessage(chatId, "⏳ Starting fixssl...", {
    reply_to_message_id: msg.message_id
  });
  const logMessageId = startMsg.message_id;

  const flush = async (force = false) => {
    const now = Date.now();
    if (!force && now - lastFlush < 1100) {
      if (!pendingFlush) {
        pendingFlush = setTimeout(() => {
          pendingFlush = null;
          flush(true).catch(() => {});
        }, 1200);
      }
      return;
    }
    lastFlush = now;

    const header =
      `<b>🛠 Repairing SSL (Timeout/Connection)</b>\n` +
      `IP: <code>${esc(ip)}</code>\n` +
      `Domain: <code>${esc(domain)}</code>\n\n`;

    const maxLogLen = 3400;
    let showLog = logBuf || "…";
    if (showLog.length > maxLogLen) showLog = showLog.slice(-maxLogLen);

    const body = `${header}<pre>${esc(showLog)}</pre>`;

    try {
      await bot.editMessageText(body, {
        chat_id: chatId,
        message_id: logMessageId,
        parse_mode: "HTML",
        disable_web_page_preview: true
      });
    } catch (e) {
      const desc = e?.response?.body?.description || e?.message || "";
      if (desc.includes("message is not modified")) return;
      if (desc.includes("Too Many Requests")) {
        await new Promise(r => setTimeout(r, 1600));
        return;
      }
      console.log("editMessageText error:", e?.response?.body || e);
    }
  };

  const addLog = async (line) => {
    logBuf += (logBuf ? "\n" : "") + line;
    await flush(false);
  };

  const run = async (ssh, cmd) => {
    await addLog(`$ ${cmd}`);
    const res = await ssh.execCommand(cmd);

    const out = (res.stdout || "").trim();
    const err = (res.stderr || "").trim();

    if (out) await addLog(out);
    if (err) await addLog(err);

    if (res.code && Number(res.code) !== 0) {
      await addLog(`[exit] code=${res.code}`);
    }
    return res;
  };

  const ssh = new NodeSSH();

  try {
    await addLog("Connecting SSH...");
    await ssh.connect({
      host: ip,
      username: "root",
      password,
      readyTimeout: 25000
    });
    await addLog("✅ SSH connected");

    // 0) cek domain resolve dari VPS
    await addLog("Checking DNS resolution from VPS...");
    const dns = await run(ssh, `bash -lc "getent ahosts ${domain} | awk '{print \\$1}' | head -n 3"`);
    const resolved = (dns.stdout || "").trim();

    await addLog(`Resolved IP(s): ${resolved || "(none)"}`);
    if (resolved && !resolved.includes(ip)) {
      await addLog("⚠️ WARNING: Domain tidak resolve ke IP VPS ini.");
      await addLog("→ Fix DNS A record dulu (atau tunggu propagate), kalau tidak certbot pasti gagal.");
    }

    // 1) pastikan nginx & certbot ada
    await addLog("Ensuring nginx/certbot installed...");
    await run(ssh, "apt-get update -y");
    await run(ssh, "apt-get install -y nginx certbot");

    // 2) buka port 80/443 (ufw + iptables) supaya gak timeout
    await addLog("Opening firewall ports 80/443...");
    await run(ssh, "ufw allow 80/tcp || true");
    await run(ssh, "ufw allow 443/tcp || true");
    await run(ssh, "iptables -I INPUT -p tcp --dport 80 -j ACCEPT || true");
    await run(ssh, "iptables -I INPUT -p tcp --dport 443 -j ACCEPT || true");

    // 3) start nginx dulu buat test HTTP
    await addLog("Starting nginx...");
    await run(ssh, "systemctl enable nginx || true");
    await run(ssh, "systemctl restart nginx || true");
    await run(ssh, "systemctl status nginx --no-pager -l | head -n 20 || true");

    // 4) tes port listening lokal
    await addLog("Checking local listening ports...");
    await run(ssh, `bash -lc "ss -lntp | grep -E ':80|:443' || true"`);

    // 5) tes HTTP request dari VPS (ini bukan test dari internet, tapi minimal cek nginx respons)
    await addLog("Testing HTTP response locally (curl)...");
    await run(ssh, `bash -lc "curl -I --max-time 10 http://127.0.0.1 || true"`);
    await run(ssh, `bash -lc "curl -I --max-time 10 http://${domain} || true"`);

    // 6) stop nginx, issue certbot standalone (biar port 80 bebas)
    await addLog("Stopping nginx (standalone certbot needs port 80)...");
    await run(ssh, "systemctl stop nginx || true");

    // bersihin lock certbot juga (sekalian)
    await addLog("Cleaning certbot locks...");
    await run(ssh, "pkill -f certbot || true");
    await run(ssh, "rm -rf /var/lib/letsencrypt/.lock /var/log/letsencrypt/.lock /etc/letsencrypt/.certbot.lock || true");

    // 7) issue cert
    await addLog("Issuing certificate via standalone (port 80)...");
    const issue = await run(
      ssh,
      `bash -lc "certbot certonly --standalone -d ${domain} --non-interactive --agree-tos -m admin@${domain} --keep-until-expiring"`
    );

    // kalau issue gagal, jangan lanjut “ngaco”
    if ((issue.stdout || "").toLowerCase().includes("failed") || (issue.stderr || "").toLowerCase().includes("failed")) {
      await addLog("❌ Certbot terlihat gagal. Cek bagian log di atas.");
      await addLog("Biasanya karena DNS salah / port 80 tidak bisa diakses dari internet.");
    }

    // 8) start nginx lagi
    await addLog("Starting nginx back...");
    await run(ssh, "systemctl start nginx || true");
    await run(ssh, "systemctl reload nginx || true");

    // 9) verify cert
    await addLog("Verifying cert status...");
    await run(ssh, `bash -lc "certbot certificates 2>/dev/null | grep -A3 -n '${domain}' || true"`);

    ssh.dispose();
    await addLog("✅ FINISHED");
    await flush(true);

    const tail = logBuf.length > 3400 ? logBuf.slice(-3400) : logBuf;

    return bot.editMessageText(
      `<b>✅ Sukses Repair SSL!</b>\nIP: <code>${esc(ip)}</code>\nDomain: <code>${esc(domain)}</code>\n\n<pre>${esc(tail)}</pre>`,
      { chat_id: chatId, message_id: logMessageId, parse_mode: "HTML", disable_web_page_preview: true }
    );

  } catch (err) {
    console.error(err);
    try { ssh.dispose(); } catch {}

    await addLog(`❌ ERROR: ${err.message || err}`);
    await flush(true);

    const tail = logBuf.length > 3400 ? logBuf.slice(-3400) : logBuf;

    return bot.editMessageText(
      `<b>❌ FixSSL gagal</b>\nIP: <code>${esc(ip)}</code>\nDomain: <code>${esc(domain)}</code>\n\n<pre>${esc(tail)}</pre>`,
      { chat_id: chatId, message_id: logMessageId, parse_mode: "HTML" }
    );
  }
});
}